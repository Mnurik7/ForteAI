"""
Простой скрипт запуска Telegram бота без конфликтов event loop
"""
import sys
import os
import asyncio

# Добавляем корневую директорию в путь
root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_dir)

# Меняем рабочую директорию на корневую
os.chdir(root_dir)

# Важно: удаляем текущую папку telegram из sys.path перед импортом библиотеки
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir in sys.path:
    sys.path.remove(current_dir)

# Для Windows устанавливаем правильную политику event loop ПЕРЕД импортом telegram
if sys.platform == 'win32':
    try:
        # Для Python 3.8+
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    except AttributeError:
        # Для Python 3.13+ может не быть WindowsSelectorEventLoopPolicy
        pass

# Импортируем модуль bot из папки telegram
import importlib.util
spec = importlib.util.spec_from_file_location("telegram_bot", os.path.join(current_dir, "bot.py"))
telegram_bot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(telegram_bot)

if __name__ == '__main__':
    print("Запуск Telegram бота ForteAI...")
    try:
        telegram_bot.main()
    except KeyboardInterrupt:
        print("\nБот остановлен пользователем")
    except Exception as e:
        print(f"\nКритическая ошибка: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

