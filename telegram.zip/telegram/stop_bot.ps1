# Скрипт для полной остановки Telegram бота ForteAI

Write-Host "=== Полная остановка Telegram бота ForteAI ===" -ForegroundColor Yellow
Write-Host ""

# Шаг 1: Поиск и остановка всех процессов Python, связанных с ботом
Write-Host "[1/3] Поиск процессов бота..." -ForegroundColor Cyan
$botProcesses = @()
Get-Process python -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        $cmdline = (Get-CimInstance Win32_Process -Filter "ProcessId = $($_.Id)").CommandLine
        if ($cmdline -and ($cmdline -like "*run_bot*" -or $cmdline -like "*bot.py*" -or $cmdline -like "*telegram*")) {
            $botProcesses += $_
            Write-Host "  Найден процесс бота: PID=$($_.Id)" -ForegroundColor Gray
        }
    } catch {
        # Игнорируем ошибки
    }
}

# Останавливаем все процессы Python (на всякий случай)
Write-Host "[2/3] Остановка всех процессов Python..." -ForegroundColor Cyan
$allPythonProcesses = Get-Process python -ErrorAction SilentlyContinue
if ($allPythonProcesses) {
    $count = $allPythonProcesses.Count
    $allPythonProcesses | Stop-Process -Force -ErrorAction SilentlyContinue
    Write-Host "  Остановлено процессов: $count" -ForegroundColor Green
    Start-Sleep -Seconds 2
} else {
    Write-Host "  Процессы Python не найдены" -ForegroundColor Gray
}

# Шаг 2: Удаление webhook
Write-Host "[3/3] Удаление webhook..." -ForegroundColor Cyan
$envPath = Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) ".env"
if (Test-Path $envPath) {
    try {
        $content = Get-Content $envPath -Raw
        if ($content -match "TELEGRAM_BOT_TOKEN=([^\r\n]+)") {
            $token = $matches[1]
            $response = Invoke-WebRequest -Uri "https://api.telegram.org/bot$token/deleteWebhook" -Method POST -Body @{drop_pending_updates=$true} -UseBasicParsing -TimeoutSec 5 -ErrorAction SilentlyContinue
            if ($response.StatusCode -eq 200) {
                Write-Host "  Webhook удален успешно" -ForegroundColor Green
            } else {
                Write-Host "  Webhook уже удален или не установлен" -ForegroundColor Gray
            }
        }
    } catch {
        Write-Host "  Не удалось удалить webhook: $($_.Exception.Message)" -ForegroundColor Yellow
    }
} else {
    Write-Host "  Файл .env не найден" -ForegroundColor Yellow
}

# Финальная проверка
Write-Host ""
Write-Host "=== Финальная проверка ===" -ForegroundColor Cyan
Start-Sleep -Seconds 2
$remaining = Get-Process python -ErrorAction SilentlyContinue
if ($remaining) {
    Write-Host "[WARNING] Все еще запущены процессы Python: $($remaining.Count)" -ForegroundColor Yellow
    $remaining | Format-Table Id, ProcessName, StartTime -AutoSize
    Write-Host ""
    Write-Host "Хотите принудительно остановить их? (Y/N): " -ForegroundColor Yellow -NoNewline
    $response = Read-Host
    if ($response -eq "Y" -or $response -eq "y") {
        $remaining | Stop-Process -Force -ErrorAction SilentlyContinue
        Write-Host "Все процессы остановлены." -ForegroundColor Green
    }
} else {
    Write-Host "[SUCCESS] Telegram бот полностью отключен!" -ForegroundColor Green
    Write-Host "Все процессы Python остановлены." -ForegroundColor Green
}

Write-Host ""
Write-Host "Для запуска бота используйте скрипт start_bot.ps1" -ForegroundColor Gray

