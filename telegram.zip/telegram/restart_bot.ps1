# Скрипт для полного перезапуска Telegram бота

Write-Host "=== Остановка всех процессов Python ===" -ForegroundColor Yellow
Get-Process python -ErrorAction SilentlyContinue | ForEach-Object {
    Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
    Write-Host "  Остановлен процесс: $($_.Id)" -ForegroundColor Gray
}

Write-Host "`nОжидание 5 секунд..." -ForegroundColor Yellow
Start-Sleep -Seconds 5

Write-Host "`n=== Удаление webhook ===" -ForegroundColor Yellow
$envPath = Join-Path $PSScriptRoot "..\.env"
if (Test-Path $envPath) {
    $content = Get-Content $envPath
    $tokenLine = $content | Where-Object { $_ -match "TELEGRAM_BOT_TOKEN=(.+)" }
    if ($tokenLine) {
        $token = ($tokenLine -split "=")[1]
        try {
            $response = Invoke-WebRequest -Uri "https://api.telegram.org/bot$token/deleteWebhook" -Method POST -Body @{drop_pending_updates=$true} -UseBasicParsing -TimeoutSec 5
            if ($response.StatusCode -eq 200) {
                Write-Host "  Webhook удален успешно" -ForegroundColor Green
            }
        } catch {
            Write-Host "  Не удалось удалить webhook (возможно уже удален): $_" -ForegroundColor Gray
        }
    }
}

Write-Host "`nОжидание 3 секунды..." -ForegroundColor Yellow
Start-Sleep -Seconds 3

Write-Host "`n=== Запуск бота ===" -ForegroundColor Green
Set-Location $PSScriptRoot
python run_bot.py

