# Скрипт запуска Telegram бота ForteAI
Write-Host "🤖 Запуск ForteAI Telegram бота..." -ForegroundColor Green

# Останавливаем все процессы Python, связанные с ботом
Write-Host "🛑 Остановка старых процессов..." -ForegroundColor Yellow
Get-Process python -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        $cmdline = (Get-CimInstance Win32_Process -Filter "ProcessId = $($_.Id)").CommandLine
        if ($cmdline -like "*run_bot*" -or $cmdline -like "*bot.py*") {
            Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
            Write-Host "  ✓ Остановлен процесс: $($_.Id)"
        }
    } catch {
        # Игнорируем ошибки
    }
}

Start-Sleep -Seconds 2

# Переходим в директорию скрипта
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

Write-Host "🚀 Запуск бота..." -ForegroundColor Green
Write-Host ""

# Запускаем бота
python run_bot.py

