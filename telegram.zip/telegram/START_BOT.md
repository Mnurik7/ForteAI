# 🚀 Запуск Telegram бота ForteAI

## Быстрый запуск

### Вариант 1: Через PowerShell скрипт (рекомендуется)
```powershell
cd D:\Forte.AI\telegram
.\start_bot.ps1
```

### Вариант 2: Напрямую через Python
```powershell
cd D:\Forte.AI\telegram
python run_bot.py
```

### Вариант 3: Из корневой директории
```powershell
cd D:\Forte.AI
python telegram\run_bot.py
```

## Проверка работы бота

### Проверить статус через API:
```powershell
cd D:\Forte.AI
python -c "import httpx; import os; from dotenv import load_dotenv; load_dotenv(); token = os.getenv('TELEGRAM_BOT_TOKEN'); response = httpx.post(f'https://api.telegram.org/bot{token}/getMe'); print(response.json())"
```

### Проверить запущенные процессы:
```powershell
Get-Process python | Format-Table Id, ProcessName, CPU, StartTime
```

## Остановка бота

### Через Task Manager:
1. Откройте Диспетчер задач (Ctrl+Shift+Esc)
2. Найдите процесс `python`
3. Завершите процесс

### Через PowerShell:
```powershell
Get-Process python | Stop-Process -Force
```

## Требования

1. ✅ Python 3.8+
2. ✅ Все зависимости из `requirements.txt` установлены
3. ✅ Файл `.env` создан с переменными:
   - `GEMINI_API_KEY` - ваш ключ Gemini AI
   - `TELEGRAM_BOT_TOKEN` - токен вашего Telegram бота
   - `GEMINI_MODEL` - модель (по умолчанию: gemini-2.5-flash)

## Доступ к боту

Найдите бота в Telegram: **@FortrAiMVP_bot**

### Команды:
- `/start` - Начать работу с ботом
- `/menu` - Показать главное меню
- `/help` - Справка

## Возможности бота

- 🔐 SmartAntiFraud - Анализ мошеннических транзакций
- 📋 AI-Procure - Анализ тендеров и закупок
- 📊 AI-Scrum Master - Управление проектами
- 📝 AI-Business Analyst - Бизнес-аналитика
- 💻 AI-Code Review - Ревью кода
- 📈 Анализ CSV данных с диаграммами
- 🎨 Генерация изображений через Gemini AI

## Устранение проблем

### Ошибка "Conflict: terminated by other getUpdates request"
Это означает, что запущен другой экземпляр бота. Решение:
```powershell
# Остановите все процессы Python
Get-Process python | Stop-Process -Force

# Подождите несколько секунд и запустите заново
Start-Sleep -Seconds 3
cd D:\Forte.AI\telegram
python run_bot.py
```

### Бот не отвечает
1. Проверьте, что бот запущен (см. раздел "Проверка работы бота")
2. Проверьте токен в `.env` файле
3. Проверьте интернет-соединение
4. Посмотрите логи в `bot_output.log`

## Логи

Логи сохраняются в файл: `telegram/bot_output.log`

Для просмотра последних сообщений:
```powershell
Get-Content D:\Forte.AI\telegram\bot_output.log -Tail 20
```

---

**Бот успешно запущен и готов к работе!** 🎉

