"""
Telegram бот для ForteAI с интеграцией всех модулей
Использует Gemini AI для генерации ответов, диаграмм и изображений
"""
import os
import sys
import asyncio
import logging
from datetime import datetime
from io import BytesIO
import json
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Для работы без GUI
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.io import to_image
from PIL import Image
import numpy as np

# Исправляем конфликт имен: папка telegram перекрывает библиотеку python-telegram-bot
# Удаляем текущую директорию из sys.path перед импортом библиотеки
_current_dir = os.path.dirname(os.path.abspath(__file__))
_was_in_path = False
if _current_dir in sys.path:
    sys.path.remove(_current_dir)
    _was_in_path = True

# Импортируем библиотеку telegram
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

# Теперь добавляем корневую директорию в путь (но НЕ текущую папку telegram)
_parent_dir = os.path.dirname(_current_dir)
if _parent_dir not in sys.path:
    sys.path.insert(0, _parent_dir)

import google.generativeai as genai

# Импорт всех модулей из основного приложения
from ml_models.antifraud_model import get_model
from ml_models.antifraud_model_enhanced import get_enhanced_model
from procure_models.tender_analyzer import TenderAnalyzer
from procure_models.supplier_matcher import SupplierMatcher
from procure_models.risk_analyzer import RiskAnalyzer
from procure_models.report_generator import ReportGenerator
from scrum_models.project_manager import ProjectManager
from scrum_models.task_creator import TaskCreator
from business_analyst_models.document_analyzer import DocumentAnalyzer
from code_review_models.code_analyzer import CodeAnalyzer

# Загрузка переменных окружения
load_dotenv()

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Настройка Gemini API
api_key = os.getenv('GEMINI_API_KEY')
if not api_key:
    raise ValueError("GEMINI_API_KEY не найден в .env")
genai.configure(api_key=api_key)
gemini_model = genai.GenerativeModel(os.getenv('GEMINI_MODEL', 'gemini-2.5-flash'))

# Инициализация модулей
tender_analyzer = TenderAnalyzer(gemini_model)
supplier_matcher = SupplierMatcher(gemini_model)
risk_analyzer = RiskAnalyzer(gemini_model)
report_generator = ReportGenerator(gemini_model)
project_manager = ProjectManager(gemini_model)
task_creator = TaskCreator(gemini_model)
document_analyzer = DocumentAnalyzer(gemini_model)
code_analyzer = CodeAnalyzer(gemini_model)

# Путь к CSV файлу (относительно корня проекта)
CSV_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'csv', 'translate.csv')
# Альтернативный путь для транзакций
TRANSACTIONS_CSV = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'csv', 'транзакции в Мобильном интернет Банкинге.csv')

class ForteAIBot:
    def __init__(self, token: str):
        self.application = Application.builder().token(token).build()
        self.setup_handlers()
        self.user_sessions = {}  # Хранение сессий пользователей
        
        # Добавляем обработчик ошибок
        self.application.add_error_handler(self.error_handler)
    
    async def error_handler(self, update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Обработка ошибок"""
        error_msg = str(context.error)
        
        # Игнорируем ошибки Conflict (множественные экземпляры) - просто логируем
        if "Conflict" in error_msg:
            logger.warning(f"Конфликт getUpdates: {error_msg}. Возможно запущено несколько экземпляров бота или webhook активен.")
            return
        
        # Для других ошибок логируем полностью
        logger.error(f"Ошибка при обработке обновления: {context.error}")
        import traceback
        logger.error("".join(traceback.format_tb(context.error.__traceback__)))
        
    def setup_handlers(self):
        """Настройка обработчиков команд и сообщений"""
        # Команды
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("help", self.help_command))
        self.application.add_handler(CommandHandler("menu", self.show_menu))
        
        # Обработчики callback для кнопок
        self.application.add_handler(CallbackQueryHandler(self.handle_callback))
        
        # Обработчик текстовых сообщений
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
        
        # Обработчик файлов
        self.application.add_handler(MessageHandler(filters.Document.ALL, self.handle_file))
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка команды /start"""
        user = update.effective_user
        welcome_text = f"""
🤖 Добро пожаловать в ForteAI Bot, {user.first_name}!

Я ваш AI-ассистент с полным функционалом платформы ForteAI:

🔐 **SmartAntiFraud** - Анализ мошеннических транзакций
📋 **AI-Procure** - Анализ тендеров и закупок
📊 **AI-Scrum Master** - Управление проектами
📝 **AI-Business Analyst** - Бизнес-аналитика
💻 **AI-Code Review** - Ревью кода

Используйте /menu для доступа к функциям или просто напишите мне ваш запрос!
        """
        keyboard = [
            [InlineKeyboardButton("📋 Главное меню", callback_data="menu_main")],
            [InlineKeyboardButton("❓ Помощь", callback_data="help")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(welcome_text, reply_markup=reply_markup, parse_mode='Markdown')
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка команды /help"""
        help_text = """
📖 **Доступные команды:**

/start - Начать работу с ботом
/menu - Показать главное меню
/help - Показать эту справку

**Как использовать:**

1. Выберите модуль через меню
2. Отправьте ваш запрос текстом
3. Загрузите файлы (CSV, документы, код) для анализа
4. Получите AI-анализ с диаграммами и рекомендациями

**Примеры запросов:**
- "Проанализируй транзакцию: сумма 50000, получатель неизвестен"
- "Создай задачи из текста: нужно разработать мобильное приложение"
- "Проверь код на ошибки: [вставьте код]"
        """
        await update.message.reply_text(help_text, parse_mode='Markdown')
    
    async def show_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать главное меню"""
        await self.send_main_menu(update, context)
    
    async def send_main_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Отправить главное меню"""
        keyboard = [
            [
                InlineKeyboardButton("🔐 SmartAntiFraud", callback_data="module_antifraud"),
                InlineKeyboardButton("📋 AI-Procure", callback_data="module_procure")
            ],
            [
                InlineKeyboardButton("📊 AI-Scrum", callback_data="module_scrum"),
                InlineKeyboardButton("📝 Business Analyst", callback_data="module_ba")
            ],
            [
                InlineKeyboardButton("💻 Code Review", callback_data="module_code"),
                InlineKeyboardButton("📈 Анализ CSV", callback_data="module_csv")
            ],
            [InlineKeyboardButton("🎨 Генерация изображений", callback_data="module_image")],
            [InlineKeyboardButton("❓ Помощь", callback_data="help")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        text = "🎯 **Главное меню ForteAI**\n\nВыберите модуль:"
        
        if update.callback_query:
            await update.callback_query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')
        else:
            await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка нажатий на кнопки"""
        query = update.callback_query
        await query.answer()
        
        user_id = query.from_user.id
        
        if query.data == "menu_main":
            await self.send_main_menu(update, context)
        elif query.data == "help":
            await self.help_command(update, context)
        elif query.data.startswith("module_"):
            module = query.data.replace("module_", "")
            self.user_sessions[user_id] = {"module": module}
            await self.show_module_menu(update, context, module)
        elif query.data.startswith("antifraud_"):
            action = query.data.replace("antifraud_", "")
            self.user_sessions[user_id] = {"module": "antifraud", "action": action}
            await query.edit_message_text(f"🔐 SmartAntiFraud - {action}\n\nОтправьте данные транзакции для анализа:")
        elif query.data.startswith("procure_"):
            action = query.data.replace("procure_", "")
            self.user_sessions[user_id] = {"module": "procure", "action": action}
            await query.edit_message_text(f"📋 AI-Procure - {action}\n\nОтправьте текст тендера или описание:")
        elif query.data.startswith("scrum_"):
            action = query.data.replace("scrum_", "")
            self.user_sessions[user_id] = {"module": "scrum", "action": action}
            await query.edit_message_text(f"📊 AI-Scrum - {action}\n\nОтправьте описание задачи или проекта:")
        elif query.data.startswith("ba_"):
            action = query.data.replace("ba_", "")
            self.user_sessions[user_id] = {"module": "ba", "action": action}
            await query.edit_message_text(f"📝 Business Analyst - {action}\n\nОтправьте документ или текст для анализа:")
        elif query.data.startswith("code_"):
            action = query.data.replace("code_", "")
            self.user_sessions[user_id] = {"module": "code", "action": action}
            await query.edit_message_text(f"💻 Code Review - {action}\n\nОтправьте код для анализа:")
        elif query.data == "csv_analyze":
            self.user_sessions[user_id] = {"module": "csv", "action": "analyze"}
            await self.handle_csv_analysis(update, context, "")
        elif query.data == "csv_charts":
            self.user_sessions[user_id] = {"module": "csv", "action": "charts"}
            await self.handle_csv_analysis(update, context, "charts")
        else:
            await query.edit_message_text("Обработка...")
    
    async def show_module_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE, module: str):
        """Показать меню модуля"""
        menus = {
            "antifraud": {
                "text": "🔐 **SmartAntiFraud**\n\nВыберите действие:",
                "buttons": [
                    [InlineKeyboardButton("⚡ Быстрый анализ", callback_data="antifraud_quick")],
                    [InlineKeyboardButton("🔬 Глубокий AI анализ", callback_data="antifraud_deep")],
                    [InlineKeyboardButton("📊 Пакетный анализ", callback_data="antifraud_batch")],
                    [InlineKeyboardButton("📈 Статистика", callback_data="antifraud_stats")],
                    [InlineKeyboardButton("📉 Диаграммы", callback_data="antifraud_charts")],
                    [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
                ]
            },
            "procure": {
                "text": "📋 **AI-Procure**\n\nВыберите действие:",
                "buttons": [
                    [InlineKeyboardButton("📄 Анализ тендера", callback_data="procure_analyze")],
                    [InlineKeyboardButton("🔍 Подбор поставщиков", callback_data="procure_suppliers")],
                    [InlineKeyboardButton("⚠️ Анализ рисков", callback_data="procure_risks")],
                    [InlineKeyboardButton("📊 Отчёт", callback_data="procure_report")],
                    [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
                ]
            },
            "scrum": {
                "text": "📊 **AI-Scrum Master**\n\nВыберите действие:",
                "buttons": [
                    [InlineKeyboardButton("📁 Проекты", callback_data="scrum_projects")],
                    [InlineKeyboardButton("✅ Создать задачи", callback_data="scrum_tasks")],
                    [InlineKeyboardButton("📈 Аналитика", callback_data="scrum_analytics")],
                    [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
                ]
            },
            "ba": {
                "text": "📝 **AI-Business Analyst**\n\nВыберите действие:",
                "buttons": [
                    [InlineKeyboardButton("📄 Анализ документа", callback_data="ba_analyze")],
                    [InlineKeyboardButton("📋 Извлечение требований", callback_data="ba_requirements")],
                    [InlineKeyboardButton("📝 Генерация BRD", callback_data="ba_brd")],
                    [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
                ]
            },
            "code": {
                "text": "💻 **AI-Code Review**\n\nВыберите действие:",
                "buttons": [
                    [InlineKeyboardButton("🔍 Анализ кода", callback_data="code_analyze")],
                    [InlineKeyboardButton("📊 Анализ проекта", callback_data="code_project")],
                    [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
                ]
            },
            "csv": {
                "text": "📈 **Анализ CSV данных**\n\nОтправьте CSV файл или запросите анализ существующего:",
                "buttons": [
                    [InlineKeyboardButton("📊 Анализ транзакций", callback_data="csv_analyze")],
                    [InlineKeyboardButton("📉 Диаграммы", callback_data="csv_charts")],
                    [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
                ]
            },
            "image": {
                "text": "🎨 **Генерация изображений**\n\nОпишите изображение, которое хотите создать:",
                "buttons": [
                    [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
                ]
            }
        }
        
        if module in menus:
            menu = menus[module]
            reply_markup = InlineKeyboardMarkup(menu["buttons"])
            
            # Проверяем, есть ли callback_query (для кнопок) или обычное сообщение
            if update.callback_query:
                await update.callback_query.edit_message_text(menu["text"], reply_markup=reply_markup, parse_mode='Markdown')
            else:
                await update.message.reply_text(menu["text"], reply_markup=reply_markup, parse_mode='Markdown')
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка текстовых сообщений"""
        user_id = update.effective_user.id
        text = update.message.text
        
        # Получаем текущий модуль пользователя
        session = self.user_sessions.get(user_id, {})
        module = session.get("module")
        
        if not module:
            # Если модуль не выбран, используем AI для определения намерения
            await self.handle_ai_query(update, context, text)
        else:
            # Обработка в контексте выбранного модуля
            await self.handle_module_query(update, context, module, text)
    
    async def handle_ai_query(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
        """Обработка запроса с помощью AI для определения намерения"""
        await update.message.reply_text("🤔 Анализирую ваш запрос...")
        
        prompt = f"""Ты AI-ассистент ForteAI. Определи, какой модуль нужен пользователю и обработай запрос.

Доступные модули:
1. SmartAntiFraud - анализ мошеннических транзакций
2. AI-Procure - анализ тендеров и закупок
3. AI-Scrum Master - управление проектами и задачами
4. AI-Business Analyst - бизнес-аналитика
5. AI-Code Review - ревью кода
6. CSV Analysis - анализ данных из CSV

Запрос пользователя: {text}

Предоставь качественный ответ, используя соответствующий модуль. Если нужно, предложи конкретные действия."""
        
        try:
            response = gemini_model.generate_content(prompt)
            answer = response.text if hasattr(response, 'text') else str(response)
            
            # Отправляем ответ
            await update.message.reply_text(answer, parse_mode='Markdown')
            
            # Предлагаем меню
            keyboard = [[InlineKeyboardButton("📋 Меню", callback_data="menu_main")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await update.message.reply_text("Используйте меню для доступа к функциям:", reply_markup=reply_markup)
            
        except Exception as e:
            logger.error(f"Ошибка AI запроса: {e}")
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
    
    async def handle_module_query(self, update: Update, context: ContextTypes.DEFAULT_TYPE, module: str, text: str):
        """Обработка запроса в контексте модуля"""
        await update.message.reply_text("⏳ Обрабатываю запрос...")
        
        try:
            if module == "antifraud":
                await self.handle_antifraud(update, context, text)
            elif module == "procure":
                await self.handle_procure(update, context, text)
            elif module == "scrum":
                await self.handle_scrum(update, context, text)
            elif module == "ba":
                await self.handle_business_analyst(update, context, text)
            elif module == "code":
                await self.handle_code_review(update, context, text)
            elif module == "csv":
                await self.handle_csv_analysis(update, context, text)
            elif module == "image":
                await self.handle_image_generation(update, context, text)
        except Exception as e:
            logger.error(f"Ошибка обработки модуля {module}: {e}")
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
    
    async def handle_antifraud(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
        """Обработка запросов SmartAntiFraud"""
        try:
            enhanced_model = get_enhanced_model()
            
            # Используем AI для извлечения данных транзакции из текста
            prompt = f"""Извлеки данные транзакции из текста и верни JSON:
{text}

Верни JSON с полями: amount, cst_dim_id, direction, и другие релевантные поля."""
            
            ai_response = gemini_model.generate_content(prompt)
            ai_text = ai_response.text if hasattr(ai_response, 'text') else str(ai_response)
            
            # Пытаемся извлечь JSON из ответа
            try:
                # Ищем JSON в ответе
                import re
                json_match = re.search(r'\{[^}]+\}', ai_text)
                if json_match:
                    transaction_data = json.loads(json_match.group())
                else:
                    # Если JSON не найден, создаем базовую структуру
                    transaction_data = {"description": text}
            except:
                transaction_data = {"description": text}
            
            # Анализ транзакции
            result = enhanced_model.predict_fraud_enhanced(transaction_data, return_shap=False)
            
            # Формируем ответ
            response_text = f"""
🔐 **Анализ транзакции**

**Уровень риска:** {result.get('risk_level', 'unknown').upper()}
**Вероятность мошенничества:** {result.get('fraud_probability', 0) * 100:.2f}%
**Оценка риска:** {result.get('risk_score', 0)}/100

**Причины:**
{chr(10).join('- ' + reason for reason in result.get('reasons', []))}

**Рекомендация:** {result.get('recommendation', 'Требуется дополнительный анализ')}
            """
            
            await update.message.reply_text(response_text, parse_mode='Markdown')
            
            # Генерируем диаграмму
            await self.send_risk_chart(update, context, result)
            
        except Exception as e:
            logger.error(f"Ошибка antifraud: {e}")
            await update.message.reply_text(f"❌ Ошибка анализа: {str(e)}")
    
    async def handle_procure(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
        """Обработка запросов AI-Procure"""
        try:
            # Анализ тендера
            tender_params = tender_analyzer.extract_tender_params(text)
            completeness = tender_analyzer.analyze_tender_completeness(tender_params)
            
            response_text = f"""
📋 **Анализ тендера**

**Параметры:**
{json.dumps(tender_params, ensure_ascii=False, indent=2)}

**Полнота информации:** {completeness.get('completeness_score', 0)}%
            """
            
            await update.message.reply_text(response_text, parse_mode='Markdown')
            
            # Подбор поставщиков
            suppliers, summary = supplier_matcher.match_suppliers(tender_params)
            
            suppliers_text = f"""
🔍 **Подобранные поставщики:**

{chr(10).join(f"{i+1}. {s.get('name', 'Unknown')} - Релевантность: {s.get('relevance', 0)}%" for i, s in enumerate(suppliers[:5]))}
            """
            
            await update.message.reply_text(suppliers_text, parse_mode='Markdown')
            
        except Exception as e:
            logger.error(f"Ошибка procure: {e}")
            await update.message.reply_text(f"❌ Ошибка анализа: {str(e)}")
    
    async def handle_scrum(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
        """Обработка запросов AI-Scrum"""
        try:
            # Создание задач из текста
            tasks_data = task_creator.create_tasks_from_text(text, project_id=None)
            
            response_text = f"""
📊 **Созданные задачи:**

{json.dumps(tasks_data, ensure_ascii=False, indent=2)}
            """
            
            await update.message.reply_text(response_text, parse_mode='Markdown')
            
        except Exception as e:
            logger.error(f"Ошибка scrum: {e}")
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
    
    async def handle_business_analyst(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
        """Обработка запросов Business Analyst"""
        try:
            analysis = document_analyzer.analyze_document(text)
            
            response_text = f"""
📝 **Анализ документа**

{analysis.get('raw_analysis', 'Анализ выполнен')}
            """
            
            await update.message.reply_text(response_text, parse_mode='Markdown')
            
        except Exception as e:
            logger.error(f"Ошибка BA: {e}")
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
    
    async def handle_code_review(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
        """Обработка запросов Code Review"""
        try:
            analysis = code_analyzer.analyze_code(text, language="Auto")
            
            response_text = f"""
💻 **Анализ кода**

{analysis.get('analysis', 'Анализ выполнен')}
            """
            
            await update.message.reply_text(response_text, parse_mode='Markdown')
            
        except Exception as e:
            logger.error(f"Ошибка code review: {e}")
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
    
    async def handle_csv_analysis(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
        """Обработка анализа CSV"""
        try:
            # Пробуем найти CSV файл транзакций
            csv_path = TRANSACTIONS_CSV if os.path.exists(TRANSACTIONS_CSV) else CSV_PATH
            
            if not os.path.exists(csv_path):
                # Пробуем найти любой CSV в папке csv
                csv_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'csv')
                csv_files = [f for f in os.listdir(csv_dir) if f.endswith('.csv')] if os.path.exists(csv_dir) else []
                if csv_files:
                    csv_path = os.path.join(csv_dir, csv_files[0])
            
            if os.path.exists(csv_path):
                # Пробуем разные кодировки
                encodings = ['windows-1251', 'cp1251', 'utf-8-sig', 'utf-8']
                df = None
                
                for encoding in encodings:
                    try:
                        df = pd.read_csv(
                            csv_path, 
                            sep=';', 
                            encoding=encoding, 
                            skiprows=1, 
                            on_bad_lines='skip', 
                            low_memory=False
                        )
                        df.columns = df.columns.str.strip()
                        break
                    except:
                        continue
                
                if df is None or df.empty:
                    await update.message.reply_text("❌ Не удалось загрузить CSV файл")
                    return
                
                # Используем AI для анализа данных
                await update.message.reply_text("🤖 Анализирую данные с помощью AI...")
                
                # Базовая статистика
                numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
                stats_summary = {
                    'total_rows': len(df),
                    'total_cols': len(df.columns),
                    'numeric_cols': len(numeric_cols),
                    'columns': df.columns.tolist()[:15]
                }
                
                # AI анализ
                prompt = f"""Проанализируй CSV данные и предоставь качественный анализ:

Статистика:
- Всего записей: {stats_summary['total_rows']}
- Колонок: {stats_summary['total_cols']}
- Числовых колонок: {stats_summary['numeric_cols']}
- Колонки: {', '.join(stats_summary['columns'])}

Первые несколько строк данных:
{df.head(5).to_string()}

Предоставь:
1. Общий анализ данных
2. Выявленные паттерны
3. Потенциальные проблемы
4. Рекомендации по использованию данных"""
                
                ai_response = gemini_model.generate_content(prompt)
                ai_analysis = ai_response.text if hasattr(ai_response, 'text') else "Анализ выполнен"
                
                stats_text = f"""
📈 **Анализ CSV данных**

**Всего записей:** {len(df)}
**Колонок:** {len(df.columns)}
**Числовых колонок:** {len(numeric_cols)}

**AI Анализ:**
{ai_analysis}
                """
                
                await update.message.reply_text(stats_text, parse_mode='Markdown')
                
                # Генерируем диаграммы
                await self.send_advanced_csv_charts(update, context, df)
            else:
                await update.message.reply_text("❌ CSV файл не найден")
                
        except Exception as e:
            logger.error(f"Ошибка CSV анализа: {e}")
            import traceback
            traceback.print_exc()
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
    
    async def handle_image_generation(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
        """Генерация изображений через Gemini"""
        try:
            await update.message.reply_text("🎨 Генерирую изображение с помощью AI...")
            
            # Используем Gemini для создания детального промпта и визуализации
            prompt = f"""Ты эксперт по созданию изображений. Пользователь хочет создать изображение.

Запрос: {text}

Создай:
1. Детальное, профессиональное описание изображения (стиль, цвета, композиция, настроение)
2. Предложи несколько вариантов стилей
3. Опиши технические детали (разрешение, формат, элементы)

Верни структурированный ответ на русском языке."""
            
            response = gemini_model.generate_content(prompt)
            description = response.text if hasattr(response, 'text') else text
            
            # Создаем красивое изображение с описанием
            await self.create_enhanced_image(update, context, description, text)
            
            # Отправляем детальное описание
            await update.message.reply_text(f"""
🎨 **Детальное описание для генерации:**

{description}

💡 *Используйте это описание в генераторах изображений (DALL-E, Midjourney, Stable Diffusion, Gemini)*
            """, parse_mode='Markdown')
            
        except Exception as e:
            logger.error(f"Ошибка генерации изображения: {e}")
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
    
    async def create_enhanced_image(self, update: Update, context: ContextTypes.DEFAULT_TYPE, 
                                    description: str, original_text: str):
        """Создание улучшенного изображения с описанием"""
        try:
            # Создаем красивую визуализацию с использованием matplotlib
            fig = plt.figure(figsize=(14, 10), facecolor='#f0f0f0')
            gs = fig.add_gridspec(2, 1, height_ratios=[1, 3], hspace=0.3)
            
            # Верхняя часть - заголовок
            ax1 = fig.add_subplot(gs[0])
            ax1.axis('off')
            ax1.text(0.5, 0.5, f"🎨 Генерация изображения\n{original_text}", 
                    ha='center', va='center', fontsize=18, fontweight='bold',
                    bbox=dict(boxstyle='round', facecolor='#8B1E2D', alpha=0.9, edgecolor='white', linewidth=3),
                    color='white', family='sans-serif')
            
            # Нижняя часть - описание
            ax2 = fig.add_subplot(gs[1])
            ax2.axis('off')
            
            # Форматируем описание
            lines = []
            words = description.split()
            current_line = ""
            for word in words:
                if len(current_line + " " + word) < 100:
                    current_line += " " + word if current_line else word
                else:
                    lines.append(current_line)
                    current_line = word
            if current_line:
                lines.append(current_line)
            
            formatted_text = "\n".join(lines)
            
            ax2.text(0.05, 0.95, formatted_text, 
                    ha='left', va='top', fontsize=12,
                    bbox=dict(boxstyle='round', facecolor='white', alpha=0.95, edgecolor='#8B1E2D', linewidth=2),
                    family='sans-serif', wrap=True,
                    transform=ax2.transAxes)
            
            plt.tight_layout()
            
            img_buffer = BytesIO()
            plt.savefig(img_buffer, format='png', dpi=200, bbox_inches='tight', 
                       facecolor='#f0f0f0', edgecolor='none')
            img_buffer.seek(0)
            plt.close()
            
            await update.message.reply_photo(photo=img_buffer, 
                                           caption="🎨 Описание для генерации изображения")
            
        except Exception as e:
            logger.error(f"Ошибка создания улучшенного изображения: {e}")
            # Fallback на простую версию
            await self.create_text_image(update, context, description, original_text)
    
    async def create_text_image(self, update: Update, context: ContextTypes.DEFAULT_TYPE, 
                                description: str, original_text: str):
        """Создание простого изображения с текстом описания (fallback)"""
        try:
            fig, ax = plt.subplots(figsize=(12, 8))
            ax.axis('off')
            
            full_text = f"🎨 Генерация изображения\n\n{original_text}\n\n{description}"
            
            ax.text(0.5, 0.5, full_text, 
                   fontsize=11, 
                   ha='center', 
                   va='center',
                   wrap=True,
                   bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8),
                   family='sans-serif')
            
            plt.tight_layout()
            
            img_buffer = BytesIO()
            plt.savefig(img_buffer, format='png', dpi=150, bbox_inches='tight', 
                       facecolor='lightblue', edgecolor='none')
            img_buffer.seek(0)
            plt.close()
            
            await update.message.reply_photo(photo=img_buffer, 
                                           caption="🎨 Описание для генерации изображения")
            
        except Exception as e:
            logger.error(f"Ошибка создания текстового изображения: {e}")
    
    async def handle_file(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка загруженных файлов"""
        file = await context.bot.get_file(update.message.document.file_id)
        file_name = update.message.document.file_name
        
        await update.message.reply_text(f"📥 Загружен файл: {file_name}\n⏳ Обрабатываю...")
        
        try:
            # Скачиваем файл
            file_bytes = BytesIO()
            await file.download_to_memory(file_bytes)
            file_bytes.seek(0)
            
            if file_name.endswith('.csv'):
                # Обработка CSV
                df = pd.read_csv(file_bytes, encoding='utf-8-sig', on_bad_lines='skip')
                await self.handle_csv_data(update, context, df, file_name)
            elif file_name.endswith(('.txt', '.md')):
                # Обработка текстовых файлов
                text = file_bytes.read().decode('utf-8')
                await self.handle_text_file(update, context, text, file_name)
            else:
                await update.message.reply_text("📄 Файл получен. Обрабатываю содержимое...")
                # Используем AI для анализа
                await self.handle_ai_query(update, context, f"Проанализируй файл {file_name}")
                
        except Exception as e:
            logger.error(f"Ошибка обработки файла: {e}")
            await update.message.reply_text(f"❌ Ошибка обработки файла: {str(e)}")
    
    async def handle_csv_data(self, update: Update, context: ContextTypes.DEFAULT_TYPE, df: pd.DataFrame, file_name: str):
        """Обработка CSV данных"""
        try:
            stats = f"""
📊 **Анализ файла {file_name}**

**Записей:** {len(df)}
**Колонок:** {len(df.columns)}
**Колонки:** {', '.join(df.columns.tolist()[:10])}
            """
            
            await update.message.reply_text(stats, parse_mode='Markdown')
            
            # Генерируем диаграммы
            await self.send_csv_charts(update, context, df)
            
        except Exception as e:
            logger.error(f"Ошибка обработки CSV: {e}")
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
    
    async def handle_text_file(self, update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, file_name: str):
        """Обработка текстового файла"""
        try:
            # Определяем тип файла и обрабатываем
            if 'code' in file_name.lower() or any(ext in file_name for ext in ['.py', '.js', '.java', '.cpp']):
                await self.handle_code_review(update, context, text)
            else:
                await self.handle_business_analyst(update, context, text)
                
        except Exception as e:
            logger.error(f"Ошибка обработки текста: {e}")
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")
    
    async def send_risk_chart(self, update: Update, context: ContextTypes.DEFAULT_TYPE, result: dict):
        """Отправка диаграммы риска"""
        try:
            # Создаем простую диаграмму
            fig, ax = plt.subplots(figsize=(8, 6))
            
            risk_level = result.get('risk_level', 'low')
            risk_score = result.get('risk_score', 0)
            
            colors = {'high': 'red', 'medium': 'orange', 'low': 'green'}
            color = colors.get(risk_level, 'gray')
            
            ax.barh(['Риск'], [risk_score], color=color)
            ax.set_xlim(0, 100)
            ax.set_xlabel('Оценка риска')
            ax.set_title(f'Уровень риска: {risk_level.upper()}')
            
            # Сохраняем в BytesIO
            img_buffer = BytesIO()
            plt.savefig(img_buffer, format='png', dpi=100, bbox_inches='tight')
            img_buffer.seek(0)
            plt.close()
            
            await update.message.reply_photo(photo=img_buffer, caption="📊 Диаграмма оценки риска")
            
        except Exception as e:
            logger.error(f"Ошибка создания диаграммы: {e}")
    
    async def send_csv_charts(self, update: Update, context: ContextTypes.DEFAULT_TYPE, df: pd.DataFrame):
        """Отправка диаграмм для CSV данных"""
        try:
            # Ищем числовые колонки
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            
            if not numeric_cols:
                await update.message.reply_text("📊 Нет числовых данных для визуализации")
                return
            
            # Создаем гистограмму для первой числовой колонки
            col = numeric_cols[0]
            fig, ax = plt.subplots(figsize=(10, 6))
            df[col].hist(bins=30, ax=ax)
            ax.set_title(f'Распределение: {col}')
            ax.set_xlabel(col)
            ax.set_ylabel('Частота')
            
            img_buffer = BytesIO()
            plt.savefig(img_buffer, format='png', dpi=100, bbox_inches='tight')
            img_buffer.seek(0)
            plt.close()
            
            await update.message.reply_photo(photo=img_buffer, caption=f"📊 Распределение {col}")
            
        except Exception as e:
            logger.error(f"Ошибка создания диаграммы CSV: {e}")
            await update.message.reply_text(f"❌ Ошибка создания диаграммы: {str(e)}")
    
    async def send_advanced_csv_charts(self, update: Update, context: ContextTypes.DEFAULT_TYPE, df: pd.DataFrame):
        """Отправка продвинутых диаграмм для CSV с использованием Plotly и Matplotlib"""
        try:
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            
            if not numeric_cols:
                await update.message.reply_text("📊 Нет числовых данных для визуализации")
                return
            
            # Создаем комплексную визуализацию с matplotlib
            col = numeric_cols[0]
            fig, axes = plt.subplots(2, 2, figsize=(16, 12))
            fig.suptitle('📊 Комплексный анализ данных', fontsize=18, fontweight='bold', color='#8B1E2D')
            
            # 1. Гистограмма распределения с улучшенным дизайном
            axes[0, 0].hist(df[col].dropna(), bins=30, color='#8B1E2D', edgecolor='white', alpha=0.7)
            axes[0, 0].set_title(f'📈 Распределение: {col}', fontsize=14, fontweight='bold')
            axes[0, 0].set_xlabel(col, fontsize=11)
            axes[0, 0].set_ylabel('Частота', fontsize=11)
            axes[0, 0].grid(True, alpha=0.3, linestyle='--')
            axes[0, 0].set_facecolor('#f8f9fa')
            
            # 2. Box plot
            if len(numeric_cols) > 1:
                bp = axes[0, 1].boxplot([df[c].dropna() for c in numeric_cols[:5]], 
                                        labels=[c[:15] for c in numeric_cols[:5]], 
                                        patch_artist=True)
                for patch in bp['boxes']:
                    patch.set_facecolor('#8B1E2D')
                    patch.set_alpha(0.7)
                axes[0, 1].set_title('📦 Box Plot (первые 5 колонок)', fontsize=14, fontweight='bold')
                axes[0, 1].tick_params(axis='x', rotation=45)
                axes[0, 1].grid(True, alpha=0.3, linestyle='--')
                axes[0, 1].set_facecolor('#f8f9fa')
            else:
                bp = axes[0, 1].boxplot([df[col].dropna()], patch_artist=True)
                bp['boxes'][0].set_facecolor('#8B1E2D')
                bp['boxes'][0].set_alpha(0.7)
                axes[0, 1].set_title(f'📦 Box Plot: {col}', fontsize=14, fontweight='bold')
                axes[0, 1].grid(True, alpha=0.3, linestyle='--')
                axes[0, 1].set_facecolor('#f8f9fa')
            
            # 3. Статистика в красивом формате
            stats_text = f"""📊 Статистика: {col}

• Среднее: {df[col].mean():.2f}
• Медиана: {df[col].median():.2f}
• Мин: {df[col].min():.2f}
• Макс: {df[col].max():.2f}
• Стд. отклонение: {df[col].std():.2f}
• Квартили:
  - Q1: {df[col].quantile(0.25):.2f}
  - Q2: {df[col].quantile(0.5):.2f}
  - Q3: {df[col].quantile(0.75):.2f}
            """
            axes[1, 0].axis('off')
            axes[1, 0].text(0.1, 0.5, stats_text, fontsize=11, verticalalignment='center', 
                           family='monospace', bbox=dict(boxstyle='round', facecolor='white', 
                           edgecolor='#8B1E2D', linewidth=2))
            axes[1, 0].set_facecolor('#f8f9fa')
            
            # 4. Корреляционная матрица (если есть несколько числовых колонок)
            if len(numeric_cols) > 1:
                corr_matrix = df[numeric_cols[:8]].corr()  # Ограничиваем до 8 для читаемости
                im = axes[1, 1].imshow(corr_matrix, cmap='RdYlBu_r', aspect='auto', vmin=-1, vmax=1)
                axes[1, 1].set_title('🔗 Корреляционная матрица', fontsize=14, fontweight='bold')
                axes[1, 1].set_xticks(range(len(numeric_cols[:8])))
                axes[1, 1].set_yticks(range(len(numeric_cols[:8])))
                axes[1, 1].set_xticklabels([c[:10] for c in numeric_cols[:8]], rotation=45, ha='right', fontsize=9)
                axes[1, 1].set_yticklabels([c[:10] for c in numeric_cols[:8]], fontsize=9)
                cbar = plt.colorbar(im, ax=axes[1, 1])
                cbar.set_label('Корреляция', fontsize=10)
                axes[1, 1].set_facecolor('#f8f9fa')
            else:
                axes[1, 1].text(0.5, 0.5, 'Недостаточно данных\nдля корреляции', 
                               ha='center', va='center', fontsize=12,
                               bbox=dict(boxstyle='round', facecolor='white', edgecolor='#8B1E2D'))
                axes[1, 1].axis('off')
                axes[1, 1].set_facecolor('#f8f9fa')
            
            plt.tight_layout()
            
            img_buffer = BytesIO()
            plt.savefig(img_buffer, format='png', dpi=200, bbox_inches='tight', facecolor='white')
            img_buffer.seek(0)
            plt.close()
            
            await update.message.reply_photo(photo=img_buffer, caption="📊 Комплексный анализ данных")
            
            # Дополнительно: временной ряд если есть даты
            date_cols = [col for col in df.columns if 'date' in col.lower() or 'time' in col.lower() or 'дата' in col.lower()]
            if date_cols and numeric_cols:
                await self.send_time_series_chart(update, context, df, date_cols[0], numeric_cols[0])
            
            # Если есть несколько числовых колонок, создаем scatter plot
            if len(numeric_cols) >= 2:
                await self.send_scatter_plot(update, context, df, numeric_cols[0], numeric_cols[1])
            
        except Exception as e:
            logger.error(f"Ошибка создания продвинутых диаграмм: {e}")
            import traceback
            traceback.print_exc()
            # Fallback на простую диаграмму
            await self.send_csv_charts(update, context, df)
    
    async def send_scatter_plot(self, update: Update, context: ContextTypes.DEFAULT_TYPE, 
                               df: pd.DataFrame, col1: str, col2: str):
        """Отправка scatter plot для двух переменных"""
        try:
            fig, ax = plt.subplots(figsize=(12, 8))
            
            # Берем выборку если данных много
            plot_df = df[[col1, col2]].dropna()
            if len(plot_df) > 5000:
                plot_df = plot_df.sample(5000, random_state=42)
            
            ax.scatter(plot_df[col1], plot_df[col2], alpha=0.5, s=20, color='#8B1E2D', edgecolors='white', linewidths=0.5)
            ax.set_xlabel(col1, fontsize=12, fontweight='bold')
            ax.set_ylabel(col2, fontsize=12, fontweight='bold')
            ax.set_title(f'📊 Scatter Plot: {col1} vs {col2}', fontsize=14, fontweight='bold', color='#8B1E2D')
            ax.grid(True, alpha=0.3, linestyle='--')
            ax.set_facecolor('#f8f9fa')
            
            plt.tight_layout()
            
            img_buffer = BytesIO()
            plt.savefig(img_buffer, format='png', dpi=150, bbox_inches='tight', facecolor='white')
            img_buffer.seek(0)
            plt.close()
            
            await update.message.reply_photo(photo=img_buffer, caption=f"📊 Scatter Plot: {col1} vs {col2}")
            
        except Exception as e:
            logger.error(f"Ошибка создания scatter plot: {e}")
    
    async def send_time_series_chart(self, update: Update, context: ContextTypes.DEFAULT_TYPE, 
                                     df: pd.DataFrame, date_col: str, value_col: str):
        """Отправка диаграммы временного ряда"""
        try:
            # Пытаемся преобразовать дату
            df_copy = df.copy()
            df_copy[date_col] = pd.to_datetime(df_copy[date_col], errors='coerce')
            df_copy = df_copy.dropna(subset=[date_col, value_col])
            
            if len(df_copy) == 0:
                return
            
            # Сортируем по дате
            df_copy = df_copy.sort_values(date_col)
            
            # Берем последние 1000 точек для производительности
            if len(df_copy) > 1000:
                df_copy = df_copy.tail(1000)
            
            fig, ax = plt.subplots(figsize=(12, 6))
            ax.plot(df_copy[date_col], df_copy[value_col], linewidth=1.5, color='steelblue')
            ax.set_title(f'Временной ряд: {value_col}')
            ax.set_xlabel(date_col)
            ax.set_ylabel(value_col)
            ax.grid(True, alpha=0.3)
            plt.xticks(rotation=45)
            
            plt.tight_layout()
            
            img_buffer = BytesIO()
            plt.savefig(img_buffer, format='png', dpi=150, bbox_inches='tight')
            img_buffer.seek(0)
            plt.close()
            
            await update.message.reply_photo(photo=img_buffer, caption=f"📈 Временной ряд: {value_col}")
            
        except Exception as e:
            logger.error(f"Ошибка создания временного ряда: {e}")
    
    def run(self):
        """Запуск бота"""
        logger.info("Запуск ForteAI Telegram бота...")
        
        # Запускаем polling - он сам удалит webhook при необходимости
        # drop_pending_updates=True очистит pending updates
        self.application.run_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=True
        )

def main():
    """Главная функция"""
    token = os.getenv('TELEGRAM_BOT_TOKEN')
    if not token:
        raise ValueError("TELEGRAM_BOT_TOKEN не найден в .env")
    
    try:
        bot = ForteAIBot(token)
        bot.run()
    except KeyboardInterrupt:
        logger.info("Бот остановлен пользователем")
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}", exc_info=True)
        raise

if __name__ == '__main__':
    main()

