# 🚀 Финальная инструкция по запуску Telegram бота ForteAI

## Проблема
Бот запускается, но сразу отключается из-за ошибки "Conflict: terminated by other getUpdates request". Это означает, что уже запущен другой экземпляр бота.

## Решение

### Шаг 1: Остановите все процессы Python
```powershell
Get-Process python -ErrorAction SilentlyContinue | Stop-Process -Force
```

### Шаг 2: Подождите 5 секунд
```powershell
Start-Sleep -Seconds 5
```

### Шаг 3: Запустите бота
```powershell
cd D:\Forte.AI\telegram
python run_bot.py
```

## Альтернативный способ (автоматический)

Используйте скрипт `restart_bot.ps1`:
```powershell
cd D:\Forte.AI\telegram
.\restart_bot.ps1
```

Этот скрипт автоматически:
1. Остановит все процессы Python
2. Удалит webhook
3. Подождет несколько секунд
4. Запустит бота

## Проверка работы бота

После запуска проверьте:
```powershell
cd D:\Forte.AI\telegram
python check_bot_status.py
```

Если вы видите:
```
[OK] БОТ РАБОТАЕТ!
Имя: ForteAi
Username: @FortrAiMVP_bot
```

Значит бот работает!

## Если бот не запускается

1. Убедитесь, что все процессы Python остановлены:
   ```powershell
   Get-Process python -ErrorAction SilentlyContinue
   ```

2. Проверьте, нет ли активного webhook:
   ```powershell
   cd D:\Forte.AI
   python -c "import os; from dotenv import load_dotenv; load_dotenv(); import httpx; token = os.getenv('TELEGRAM_BOT_TOKEN'); r = httpx.get(f'https://api.telegram.org/bot{token}/getWebhookInfo'); print(r.json())"
   ```

3. Удалите webhook вручную:
   ```powershell
   cd D:\Forte.AI
   python -c "import os; from dotenv import load_dotenv; load_dotenv(); import httpx; token = os.getenv('TELEGRAM_BOT_TOKEN'); r = httpx.delete(f'https://api.telegram.org/bot{token}/deleteWebhook', params={'drop_pending_updates': True}); print('Webhook deleted:', r.status_code)"
   ```

4. Перезапустите бота

## Важно

- **Убедитесь, что запущен только ОДИН экземпляр бота**
- Бот должен работать постоянно в фоне
- Для остановки бота используйте Ctrl+C или остановите процесс Python

---

**Бот готов к работе! Найдите его в Telegram: @FortrAiMVP_bot**

