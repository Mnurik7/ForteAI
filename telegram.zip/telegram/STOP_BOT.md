# 🛑 Остановка Telegram бота ForteAI

## Быстрая остановка

### Способ 1: Использовать скрипт (рекомендуется)
```powershell
cd D:\Forte.AI\telegram
.\stop_bot.ps1
```

### Способ 2: Вручную через PowerShell
```powershell
# Остановить все процессы Python
Get-Process python -ErrorAction SilentlyContinue | Stop-Process -Force

# Проверить, что все остановлено
Get-Process python -ErrorAction SilentlyContinue
```

### Способ 3: Через диспетчер задач
1. Откройте Диспетчер задач (Ctrl+Shift+Esc)
2. Найдите процессы `python.exe`
3. Завершите их

## Проверка статуса

После остановки проверьте:
```powershell
Get-Process python -ErrorAction SilentlyContinue
```

Если ничего не выводится - бот полностью остановлен!

## Что делает скрипт stop_bot.ps1

1. ✅ Находит все процессы Python, связанные с ботом
2. ✅ Останавливает все процессы Python
3. ✅ Удаляет webhook бота (если установлен)
4. ✅ Проверяет, что все процессы остановлены

## Запуск бота обратно

После остановки для запуска используйте:
```powershell
cd D:\Forte.AI\telegram
python run_bot.py
```

Или:
```powershell
cd D:\Forte.AI\telegram
.\start_bot.ps1
```

---

**Бот успешно отключен!** ✅

