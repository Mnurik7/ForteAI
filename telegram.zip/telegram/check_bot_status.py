"""
Скрипт для проверки статуса Telegram бота
"""
import os
import sys
import httpx
from dotenv import load_dotenv

# Устанавливаем UTF-8 кодировку для Windows
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')

load_dotenv()

token = os.getenv('TELEGRAM_BOT_TOKEN')

if not token:
    print("[ERROR] TELEGRAM_BOT_TOKEN не найден в .env")
    exit(1)

try:
    response = httpx.post(
        f'https://api.telegram.org/bot{token}/getMe',
        timeout=5
    )
    data = response.json()
    
    if data.get('ok'):
        bot_info = data.get('result', {})
        print("[OK] БОТ РАБОТАЕТ!")
        print(f"Имя: {bot_info.get('first_name')}")
        print(f"Username: @{bot_info.get('username')}")
        print(f"ID: {bot_info.get('id')}")
        print(f"Может присоединяться к группам: {bot_info.get('can_join_groups')}")
    else:
        print("[ERROR] Ошибка при получении информации о боте")
        print(f"Ответ: {data}")
        
except Exception as e:
    print(f"[ERROR] Ошибка: {e}")

