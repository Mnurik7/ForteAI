"""
Консольная программа для имитации системы антифрода для переводов
Классифицирует переводы на RED (мошенничество), YELLOW (подозрительный), GREEN (обычный)
"""

import json
from datetime import datetime
from typing import Dict, List, Tuple, Optional


# Константы
YELLOW_THRESHOLD = 3  # Порог количества YELLOW-переводов для блокировки
CURRENCY_DEFAULT = "KZT"

# Триггеры для RED (мошенничество)
RED_TRIGGERS = [
    "мы из банка",
    "служба безопасности банка",
    "с вашей карты пытаются списать деньги",
    "подтвердите перевод",
    "переведите на безопасный счет",
    "переведите на безопасный счёт",
    "банк требует подтверждения",
    "срочно подтвердите",
    "ваша карта заблокирована",
    "разблокируйте карту"
]

# Триггеры для YELLOW (подозрительный)
YELLOW_TRIGGERS = [
    "я случайно скинул вам",
    "я случайно скинул",
    "ошибочно перевел",
    "ошибочно перевёл",
    "можете отправить обратно",
    "верните пожалуйста",
    "вернуть деньги",
    "ошибся с номером",
    "неправильно перевел",
    "случайный перевод"
]


class Transaction:
    """Класс для представления транзакции"""
    
    transaction_counter = 0
    
    def __init__(self, sender_id: str, receiver_id: str, amount: float, 
                 currency: str = CURRENCY_DEFAULT, comment: str = ""):
        Transaction.transaction_counter += 1
        self.id = Transaction.transaction_counter
        self.sender_id = sender_id
        self.receiver_id = receiver_id
        self.amount = amount
        self.currency = currency
        self.comment = comment
        self.timestamp = datetime.now().isoformat()
        self.risk_level = None
        self.reason = None
        self.actions = []
    
    def to_dict(self) -> Dict:
        """Преобразовать транзакцию в словарь"""
        return {
            "id": self.id,
            "sender_id": self.sender_id,
            "receiver_id": self.receiver_id,
            "amount": self.amount,
            "currency": self.currency,
            "comment": self.comment,
            "timestamp": self.timestamp,
            "risk_level": self.risk_level,
            "reason": self.reason,
            "actions": self.actions
        }
    
    def __repr__(self) -> str:
        return f"Transaction(id={self.id}, sender={self.sender_id}, amount={self.amount}, risk={self.risk_level})"


class UserHistory:
    """Класс для хранения истории пользователя"""
    
    def __init__(self):
        self.count_yellow = 0
        self.is_blocked = False
        self.transactions = []
    
    def to_dict(self) -> Dict:
        return {
            "count_yellow": self.count_yellow,
            "is_blocked": self.is_blocked,
            "total_transactions": len(self.transactions)
        }


def check_triggers(text: str, triggers: List[str]) -> bool:
    """
    Проверяет, содержит ли текст любой из триггеров (без учета регистра)
    
    Args:
        text: Текст для проверки
        triggers: Список триггерных фраз
    
    Returns:
        True, если найден хотя бы один триггер
    """
    if not text:
        return False
    
    text_lower = text.lower().strip()
    
    for trigger in triggers:
        if trigger.lower() in text_lower:
            return True
    
    return False


def classify_transaction(transaction: Transaction, users_history: Dict[str, UserHistory]) -> Tuple[str, str, List[str]]:
    """
    Классифицирует транзакцию на один из уровней риска: RED, YELLOW, GREEN
    
    Args:
        transaction: Транзакция для классификации
        users_history: Словарь с историей пользователей (ключ - sender_id)
    
    Returns:
        Кортеж (risk_level, reason, actions)
    """
    sender_id = transaction.sender_id
    comment = transaction.comment or ""
    
    # Инициализируем историю отправителя, если её нет
    if sender_id not in users_history:
        users_history[sender_id] = UserHistory()
    
    user_history = users_history[sender_id]
    
    # Проверка 1: Если отправитель уже заблокирован - сразу RED
    if user_history.is_blocked:
        reason = f"Отправитель {sender_id} уже заблокирован как мошенник"
        actions = ["MOVE_TO_RED_QUEUE", "BLOCK_SENDER"]
        return ("RED", reason, actions)
    
    # Проверка 2: Проверяем триггеры RED (мошенничество)
    if check_triggers(comment, RED_TRIGGERS):
        reason = "Комментарий содержит признаки фишинга от имени банка"
        actions = ["MOVE_TO_RED_QUEUE", "BLOCK_SENDER"]
        # Блокируем отправителя
        user_history.is_blocked = True
        return ("RED", reason, actions)
    
    # Проверка 3: Проверяем триггеры YELLOW (подозрительный)
    if check_triggers(comment, YELLOW_TRIGGERS):
        # Увеличиваем счетчик YELLOW-переводов
        user_history.count_yellow += 1
        
        # Проверяем, не превышен ли порог
        if user_history.count_yellow >= YELLOW_THRESHOLD:
            # Превышен порог - блокируем и делаем RED
            user_history.is_blocked = True
            reason = f"Множественные подозрительные запросы на возврат средств от этого отправителя (YELLOW переводов: {user_history.count_yellow})"
            actions = ["MOVE_TO_RED_QUEUE", "BLOCK_SENDER"]
            return ("RED", reason, actions)
        else:
            # Ещё не превышен порог - остаётся YELLOW
            reason = f"Комментарий похож на схему с ошибочным переводом (YELLOW переводов от этого отправителя: {user_history.count_yellow}/{YELLOW_THRESHOLD})"
            actions = ["MOVE_TO_YELLOW_QUEUE"]
            return ("YELLOW", reason, actions)
    
    # Если не попал ни в RED, ни в YELLOW - значит GREEN (обычный перевод)
    reason = "Комментарий не содержит подозрительных признаков"
    actions = ["MOVE_TO_GREEN_QUEUE"]
    return ("GREEN", reason, actions)


def print_transaction_result(transaction: Transaction):
    """
    Выводит результат анализа транзакции в консоль
    
    Args:
        transaction: Транзакция для вывода
    """
    print("\n" + "=" * 80)
    print("РЕЗУЛЬТАТ АНАЛИЗА ПЕРЕВОДА")
    print("=" * 80)
    print(f"ID перевода: {transaction.id}")
    print(f"Отправитель (sender_id): {transaction.sender_id}")
    print(f"Получатель (receiver_id): {transaction.receiver_id}")
    print(f"Сумма: {transaction.amount:,.2f} {transaction.currency}")
    print(f"Комментарий: {transaction.comment}")
    print(f"Время: {transaction.timestamp}")
    print("-" * 80)
    
    # Цветовая индикация уровня риска
    risk_colors = {
        "RED": "\033[91m",      # Красный
        "YELLOW": "\033[93m",   # Жёлтый
        "GREEN": "\033[92m"     # Зелёный
    }
    reset_color = "\033[0m"
    
    risk_level_display = transaction.risk_level
    if transaction.risk_level in risk_colors:
        risk_level_display = f"{risk_colors[transaction.risk_level]}{transaction.risk_level}{reset_color}"
    
    print(f"Уровень риска: {risk_level_display}")
    print(f"Причина: {transaction.reason}")
    
    if transaction.actions:
        print(f"Действия: {', '.join(transaction.actions)}")
    else:
        print("Действия: нет")
    
    print("=" * 80 + "\n")


def get_user_input(prompt: str, default: Optional[str] = None) -> str:
    """
    Получает ввод от пользователя с поддержкой значения по умолчанию
    
    Args:
        prompt: Текст запроса
        default: Значение по умолчанию (опционально)
    
    Returns:
        Введенная строка или значение по умолчанию
    """
    if default:
        full_prompt = f"{prompt} (по умолчанию: {default}): "
    else:
        full_prompt = f"{prompt}: "
    
    user_input = input(full_prompt).strip()
    
    if not user_input and default:
        return default
    
    return user_input


def validate_amount(amount_str: str) -> Optional[float]:
    """
    Валидирует и преобразует строку в число (сумму)
    
    Args:
        amount_str: Строка с суммой
    
    Returns:
        Число или None, если невалидное
    """
    try:
        amount = float(amount_str.replace(',', '.'))
        if amount <= 0:
            print("Ошибка: Сумма должна быть положительным числом")
            return None
        return amount
    except ValueError:
        print("Ошибка: Некорректный формат суммы")
        return None


def load_transactions_from_json(filename: str) -> List[Dict]:
    """
    Загружает транзакции из JSON файла
    
    Args:
        filename: Путь к JSON файлу
    
    Returns:
        Список транзакций
    """
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Поддерживаем разные форматы JSON
        if isinstance(data, list):
            return data
        elif isinstance(data, dict) and 'transactions' in data:
            return data['transactions']
        else:
            print(f"Ошибка: Неожиданный формат JSON файла")
            return []
    except FileNotFoundError:
        print(f"Ошибка: Файл {filename} не найден")
        return []
    except json.JSONDecodeError as e:
        print(f"Ошибка: Не удалось распарсить JSON файл: {e}")
        return []
    except Exception as e:
        print(f"Ошибка при загрузке файла: {e}")
        return []


def analyze_transactions_from_json(filename: str):
    """
    Анализирует все транзакции из JSON файла
    
    Args:
        filename: Путь к JSON файлу с транзакциями
    """
    print("=" * 80)
    print("АНАЛИЗ ТРАНЗАКЦИЙ ИЗ JSON ФАЙЛА")
    print("=" * 80)
    print(f"Загрузка транзакций из: {filename}\n")
    
    # Загружаем транзакции
    transactions_data = load_transactions_from_json(filename)
    
    if not transactions_data:
        print("Нет транзакций для анализа")
        return
    
    print(f"Загружено транзакций: {len(transactions_data)}\n")
    
    # Хранение истории пользователей
    users_history: Dict[str, UserHistory] = {}
    
    # Список всех обработанных транзакций
    all_transactions: List[Transaction] = []
    
    # Статистика
    risk_counts = {"RED": 0, "YELLOW": 0, "GREEN": 0}
    blocked_users = set()
    
    # Обрабатываем каждую транзакцию
    for i, trans_data in enumerate(transactions_data, 1):
        try:
            # Создаём объект транзакции
            transaction = Transaction(
                sender_id=str(trans_data.get('sender_id', '')),
                receiver_id=str(trans_data.get('receiver_id', '')),
                amount=float(trans_data.get('amount', 0)),
                currency=trans_data.get('currency', CURRENCY_DEFAULT),
                comment=trans_data.get('comment', '')
            )
            
            # Классифицируем транзакцию
            risk_level, reason, actions = classify_transaction(transaction, users_history)
            
            # Сохраняем результаты
            transaction.risk_level = risk_level
            transaction.reason = reason
            transaction.actions = actions
            
            # Обновляем статистику
            risk_counts[risk_level] += 1
            
            # Проверяем блокировку
            sender_id = transaction.sender_id
            if sender_id in users_history and users_history[sender_id].is_blocked:
                blocked_users.add(sender_id)
            
            # Добавляем в историю
            if sender_id not in users_history:
                users_history[sender_id] = UserHistory()
            users_history[sender_id].transactions.append(transaction.id)
            
            all_transactions.append(transaction)
            
            # Показываем прогресс каждые 10 транзакций
            if i % 10 == 0:
                print(f"Обработано: {i}/{len(transactions_data)} транзакций...")
        
        except Exception as e:
            print(f"Ошибка при обработке транзакции #{i}: {e}")
            continue
    
    # Выводим результаты
    print("\n" + "=" * 80)
    print("РЕЗУЛЬТАТЫ АНАЛИЗА")
    print("=" * 80)
    print(f"Всего обработано транзакций: {len(all_transactions)}")
    print(f"\nРаспределение по уровням риска:")
    print(f"  🔴 RED (мошенничество): {risk_counts['RED']} ({risk_counts['RED']/len(all_transactions)*100:.1f}%)")
    print(f"  🟡 YELLOW (подозрительный): {risk_counts['YELLOW']} ({risk_counts['YELLOW']/len(all_transactions)*100:.1f}%)")
    print(f"  🟢 GREEN (обычный): {risk_counts['GREEN']} ({risk_counts['GREEN']/len(all_transactions)*100:.1f}%)")
    print(f"\nЗаблокировано отправителей: {len(blocked_users)}")
    
    # Показываем заблокированных пользователей
    if blocked_users:
        print(f"\nЗаблокированные отправители:")
        for user_id in sorted(blocked_users):
            hist = users_history[user_id]
            print(f"  - {user_id}: YELLOW переводов: {hist.count_yellow}, Всего переводов: {len(hist.transactions)}")
    
    # Показываем топ подозрительных отправителей
    suspicious_users = [
        (user_id, hist.count_yellow, len(hist.transactions))
        for user_id, hist in users_history.items()
        if hist.count_yellow > 0
    ]
    suspicious_users.sort(key=lambda x: x[1], reverse=True)
    
    if suspicious_users:
        print(f"\nТоп подозрительных отправителей (по количеству YELLOW переводов):")
        for user_id, yellow_count, total_count in suspicious_users[:10]:
            status = "🔴 ЗАБЛОКИРОВАН" if users_history[user_id].is_blocked else "⚠️ Под наблюдением"
            print(f"  - {user_id}: {yellow_count} YELLOW переводов из {total_count} ({status})")
    
    # Сохраняем результаты
    save_results = input("\nСохранить результаты анализа в файл? (y/n): ").strip().lower()
    if save_results == 'y':
        results_filename = f"analysis_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        results_data = {
            "source_file": filename,
            "analyzed_at": datetime.now().isoformat(),
            "statistics": {
                "total_transactions": len(all_transactions),
                "risk_counts": risk_counts,
                "blocked_users_count": len(blocked_users),
                "blocked_users": list(blocked_users)
            },
            "transactions": [trans.to_dict() for trans in all_transactions],
            "users_history": {
                sender_id: hist.to_dict()
                for sender_id, hist in users_history.items()
            }
        }
        
        with open(results_filename, 'w', encoding='utf-8') as f:
            json.dump(results_data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Результаты сохранены в: {results_filename}")
    
    print("\n" + "=" * 80)


def main():
    """
    Главная функция программы - цикл ввода и анализа переводов
    """
    print("=" * 80)
    print("СИСТЕМА АНТИФРОДА ДЛЯ ПЕРЕВОДОВ")
    print("=" * 80)
    print(f"Порог для блокировки отправителя: {YELLOW_THRESHOLD} подозрительных (YELLOW) переводов")
    print("\nВыберите режим работы:")
    print("  1. Ручной ввод переводов")
    print("  2. Анализ из JSON файла")
    print("  3. Выход")
    print("=" * 80 + "\n")
    
    mode = input("Выберите режим (1/2/3): ").strip()
    
    if mode == "2":
        # Режим анализа из JSON
        json_file = input("Введите путь к JSON файлу (или Enter для transactions_100.json): ").strip()
        if not json_file:
            json_file = "transactions_100.json"
        analyze_transactions_from_json(json_file)
        return
    elif mode == "3":
        print("Выход из программы...")
        return
    elif mode != "1":
        print("Неверный выбор, используем режим ручного ввода")
    
    # Режим ручного ввода (оригинальный функционал)
    print("\nРежим ручного ввода переводов")
    print("Для выхода введите пустой sender_id или 'exit'")
    print("=" * 80 + "\n")
    
    # Хранение истории пользователей
    users_history: Dict[str, UserHistory] = {}
    
    # Список всех транзакций для истории
    all_transactions: List[Transaction] = []
    
    while True:
        try:
            # Ввод данных перевода
            print("-" * 80)
            print("ВВОД ДАННЫХ ПЕРЕВОДА")
            print("-" * 80)
            
            sender_id = get_user_input("sender_id")
            if not sender_id or sender_id.lower() == "exit":
                print("\nВыход из программы...")
                break
            
            receiver_id = get_user_input("receiver_id")
            if not receiver_id:
                print("Ошибка: receiver_id обязателен. Пропускаем этот перевод.\n")
                continue
            
            # Ввод суммы
            amount_str = get_user_input("amount (сумма)")
            amount = validate_amount(amount_str)
            if amount is None:
                print("Пропускаем этот перевод.\n")
                continue
            
            # Валюта
            currency = get_user_input("currency", CURRENCY_DEFAULT).upper() or CURRENCY_DEFAULT
            
            # Комментарий
            comment = get_user_input("comment (комментарий)", "")
            
            # Создаём объект транзакции
            transaction = Transaction(
                sender_id=sender_id,
                receiver_id=receiver_id,
                amount=amount,
                currency=currency,
                comment=comment
            )
            
            # Классифицируем транзакцию
            risk_level, reason, actions = classify_transaction(transaction, users_history)
            
            # Сохраняем результаты в транзакцию
            transaction.risk_level = risk_level
            transaction.reason = reason
            transaction.actions = actions
            
            # Добавляем в историю пользователя
            user_history = users_history[sender_id]
            user_history.transactions.append(transaction.id)
            
            # Сохраняем транзакцию
            all_transactions.append(transaction)
            
            # Выводим результат
            print_transaction_result(transaction)
            
            # Показываем статистику по отправителю
            print(f"Статистика отправителя {sender_id}:")
            print(f"  - YELLOW переводов: {user_history.count_yellow}/{YELLOW_THRESHOLD}")
            print(f"  - Заблокирован: {'Да' if user_history.is_blocked else 'Нет'}")
            print(f"  - Всего переводов: {len(user_history.transactions)}")
            print()
            
        except KeyboardInterrupt:
            print("\n\nПрерывание программы пользователем...")
            break
        except Exception as e:
            print(f"\nОшибка: {e}")
            print("Продолжаем...\n")
    
    # Финальная статистика
    print("\n" + "=" * 80)
    print("ФИНАЛЬНАЯ СТАТИСТИКА")
    print("=" * 80)
    print(f"Всего обработано переводов: {len(all_transactions)}")
    
    # Подсчет по уровням риска
    risk_counts = {"RED": 0, "YELLOW": 0, "GREEN": 0}
    for trans in all_transactions:
        if trans.risk_level in risk_counts:
            risk_counts[trans.risk_level] += 1
    
    print(f"  - RED (мошенничество): {risk_counts['RED']}")
    print(f"  - YELLOW (подозрительный): {risk_counts['YELLOW']}")
    print(f"  - GREEN (обычный): {risk_counts['GREEN']}")
    print(f"\nВсего уникальных отправителей: {len(users_history)}")
    
    blocked_count = sum(1 for hist in users_history.values() if hist.is_blocked)
    print(f"Заблокировано отправителей: {blocked_count}")
    
    # Сохранение истории в файл (опционально)
    save_history = input("\nСохранить историю в файл? (y/n): ").strip().lower()
    if save_history == 'y':
        filename = f"transfer_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        history_data = {
            "transactions": [trans.to_dict() for trans in all_transactions],
            "users_history": {
                sender_id: hist.to_dict() 
                for sender_id, hist in users_history.items()
            },
            "statistics": {
                "total_transactions": len(all_transactions),
                "risk_counts": risk_counts,
                "blocked_users": blocked_count
            }
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(history_data, f, ensure_ascii=False, indent=2)
        
        print(f"История сохранена в файл: {filename}")
    
    print("\nПрограмма завершена.")


if __name__ == "__main__":
    main()

