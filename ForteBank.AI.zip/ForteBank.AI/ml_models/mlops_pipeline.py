"""
MLOps Pipeline для SmartAntiFraud
Включает:
- Автоматический retraining
- CI/CD для моделей
- Rollback механизм
- Zero-downtime обновления
- Мониторинг метрик
"""
import os
import json
import pickle
import shutil
from datetime import datetime, timedelta
from typing import Dict, Optional, List
import pandas as pd

class ModelVersion:
    """Версия модели"""
    
    def __init__(self, version: str, model_path: str, metrics: Dict, training_date: datetime):
        self.version = version
        self.model_path = model_path
        self.metrics = metrics
        self.training_date = training_date
        self.is_active = False
        self.rollback_path = None
    
    def to_dict(self):
        return {
            'version': self.version,
            'model_path': self.model_path,
            'metrics': self.metrics,
            'training_date': self.training_date.isoformat(),
            'is_active': self.is_active
        }

class MLOpsPipeline:
    """MLOps Pipeline для управления моделями"""
    
    def __init__(self, model_dir='ml_models/versions'):
        self.model_dir = model_dir
        self.versions_file = os.path.join(model_dir, 'versions.json')
        self.versions: Dict[str, ModelVersion] = {}
        self.current_version = None
        self.load_versions()
    
    def load_versions(self):
        """Загрузка информации о версиях"""
        if os.path.exists(self.versions_file):
            try:
                with open(self.versions_file, 'r') as f:
                    data = json.load(f)
                    for v_data in data.get('versions', []):
                        version = ModelVersion(
                            v_data['version'],
                            v_data['model_path'],
                            v_data['metrics'],
                            pd.to_datetime(v_data['training_date'])
                        )
                        version.is_active = v_data.get('is_active', False)
                        self.versions[v_data['version']] = version
                    
                    self.current_version = data.get('current_version')
            except Exception as e:
                print(f"Ошибка загрузки версий: {e}")
    
    def save_versions(self):
        """Сохранение информации о версиях"""
        os.makedirs(self.model_dir, exist_ok=True)
        
        data = {
            'current_version': self.current_version,
            'versions': [v.to_dict() for v in self.versions.values()]
        }
        
        with open(self.versions_file, 'w') as f:
            json.dump(data, f, indent=2, default=str)
    
    def create_version(self, model, metrics: Dict) -> str:
        """Создание новой версии модели"""
        version = datetime.now().strftime('%Y%m%d_%H%M%S')
        version_dir = os.path.join(self.model_dir, version)
        os.makedirs(version_dir, exist_ok=True)
        
        model_path = os.path.join(version_dir, 'model.pkl')
        
        # Сохранение модели
        with open(model_path, 'wb') as f:
            pickle.dump({
                'model': model.ml_model,
                'calibrated_model': model.calibrated_model,
                'scaler': model.scaler,
                'feature_names': model.feature_names,
                'metrics': metrics,
                'model_type': model.model_type,
                'training_date': datetime.now().isoformat()
            }, f)
        
        # Создание версии
        model_version = ModelVersion(
            version,
            model_path,
            metrics,
            datetime.now()
        )
        
        self.versions[version] = model_version
        self.save_versions()
        
        return version
    
    def deploy_version(self, version: str) -> bool:
        """Деплой версии модели"""
        if version not in self.versions:
            return False
        
        # Деактивация текущей версии
        if self.current_version and self.current_version in self.versions:
            self.versions[self.current_version].is_active = False
        
        # Активация новой версии
        self.versions[version].is_active = True
        self.current_version = version
        self.save_versions()
        
        return True
    
    def rollback(self) -> Optional[str]:
        """Откат к предыдущей версии"""
        if not self.current_version:
            return None
        
        # Находим предыдущую версию
        versions_list = sorted(
            [v for v in self.versions.values() if v.version != self.current_version],
            key=lambda x: x.training_date,
            reverse=True
        )
        
        if not versions_list:
            return None
        
        previous_version = versions_list[0].version
        self.deploy_version(previous_version)
        
        return previous_version
    
    def get_best_version(self, metric='roc_auc') -> Optional[str]:
        """Получить лучшую версию по метрике"""
        if not self.versions:
            return None
        
        best_version = None
        best_score = -1
        
        for version in self.versions.values():
            score = version.metrics.get(metric, 0)
            if score > best_score:
                best_score = score
                best_version = version.version
        
        return best_version
    
    def cleanup_old_versions(self, keep_last_n=5):
        """Удаление старых версий"""
        versions_list = sorted(
            self.versions.values(),
            key=lambda x: x.training_date,
            reverse=True
        )
        
        for version in versions_list[keep_last_n:]:
            if not version.is_active:
                # Удаление файлов
                version_dir = os.path.dirname(version.model_path)
                if os.path.exists(version_dir):
                    try:
                        shutil.rmtree(version_dir)
                    except:
                        pass
                
                # Удаление из списка
                del self.versions[version.version]
        
        self.save_versions()
    
    def get_version_info(self, version: str) -> Optional[Dict]:
        """Информация о версии"""
        if version in self.versions:
            return self.versions[version].to_dict()
        return None
    
    def list_versions(self) -> List[Dict]:
        """Список всех версий"""
        return [v.to_dict() for v in sorted(
            self.versions.values(),
            key=lambda x: x.training_date,
            reverse=True
        )]

class AutoRetrainer:
    """Автоматический retraining"""
    
    def __init__(self, model, mlops_pipeline, retrain_interval_days=30):
        self.model = model
        self.mlops_pipeline = mlops_pipeline
        self.retrain_interval_days = retrain_interval_days
        self.last_retrain_date = None
    
    def should_retrain(self) -> bool:
        """Проверка необходимости retraining"""
        if not self.model.last_training_date:
            return True
        
        days_since = (datetime.now() - self.model.last_training_date).days
        return days_since >= self.retrain_interval_days
    
    def retrain(self) -> Optional[str]:
        """Выполнение retraining"""
        if not self.should_retrain():
            return None
        
        print("Начинаю автоматический retraining...")
        
        # Обучение модели
        success = self.model.train_model_enhanced()
        
        if not success:
            return None
        
        # Создание версии
        version = self.mlops_pipeline.create_version(
            self.model,
            self.model.model_metrics
        )
        
        # Проверка улучшения метрик
        current_metrics = self.model.model_metrics
        if self.mlops_pipeline.current_version:
            current_version = self.mlops_pipeline.get_version_info(
                self.mlops_pipeline.current_version
            )
            if current_version:
                old_roc_auc = current_version['metrics'].get('roc_auc', 0)
                new_roc_auc = current_metrics.get('roc_auc', 0)
                
                # Деплой только если метрики улучшились
                if new_roc_auc >= old_roc_auc * 0.95:  # Допускаем небольшое снижение
                    self.mlops_pipeline.deploy_version(version)
                    self.last_retrain_date = datetime.now()
                    print(f"Модель обновлена до версии {version}")
                    return version
                else:
                    print(f"Новая модель хуже (ROC-AUC: {old_roc_auc:.4f} -> {new_roc_auc:.4f}), не деплоим")
        else:
            # Первая версия
            self.mlops_pipeline.deploy_version(version)
            self.last_retrain_date = datetime.now()
            return version
        
        return None

# Глобальный экземпляр
mlops_pipeline = None
auto_retrainer = None

def get_mlops_pipeline():
    """Получить MLOps pipeline"""
    global mlops_pipeline
    if mlops_pipeline is None:
        mlops_pipeline = MLOpsPipeline()
    return mlops_pipeline

def get_auto_retrainer(model):
    """Получить auto retrainer"""
    global auto_retrainer
    if auto_retrainer is None:
        mlops = get_mlops_pipeline()
        auto_retrainer = AutoRetrainer(model, mlops)
    return auto_retrainer

