"""
ML модель для выявления мошеннических транзакций
Использует обученную ML-модель на основе исторических данных
"""
import pandas as pd
import numpy as np
from datetime import datetime
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import pickle
import warnings
warnings.filterwarnings('ignore')

CSV_PATH = 'csv/translate.csv'
MODEL_PATH = 'ml_models/trained_model.pkl'

class AntiFraudModel:
    def __init__(self):
        self.transactions_df = None
        self.ml_model = None
        self.label_encoders = {}
        self.feature_names = []
        self.model_metrics = {}
        self.load_data()
        self.calculate_statistics()
        self.load_or_train_model()
    
    def load_data(self):
        """Загрузить данные транзакций из CSV"""
        try:
            csv_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), CSV_PATH)
            if os.path.exists(csv_path):
                # Пробуем разные кодировки
                encodings = ['windows-1251', 'cp1251', 'latin-1', 'utf-8-sig', 'utf-8']
                self.transactions_df = None
                
                for encoding in encodings:
                    try:
                        # Пропускаем первую строку (русский заголовок), используем вторую как названия колонок
                        self.transactions_df = pd.read_csv(
                            csv_path, 
                            sep=';',
                            encoding=encoding,
                            on_bad_lines='skip',
                            low_memory=False,
                            skiprows=1,  # Пропускаем первую строку с русским заголовком
                            header=0     # Вторая строка станет заголовком
                        )
                        
                        # Очищаем названия колонок от пробелов и кавычек
                        self.transactions_df.columns = self.transactions_df.columns.str.strip()
                        
                        # Проверяем, есть ли нужные колонки
                        date_columns = []
                        if 'transdate' in self.transactions_df.columns:
                            date_columns.append('transdate')
                        if 'transdatetime' in self.transactions_df.columns:
                            date_columns.append('transdatetime')
                        
                        # Если есть колонки с датами, парсим их
                        if date_columns:
                            for col in date_columns:
                                # Убираем кавычки и пробелы, затем парсим даты
                                # Формат в CSV: '2025-01-05 00:00:00.000'
                                self.transactions_df[col] = self.transactions_df[col].astype(str).str.replace("'", "").str.strip()
                                self.transactions_df[col] = pd.to_datetime(
                                    self.transactions_df[col], 
                                    errors='coerce',
                                    format='mixed'  # pandas автоматически определит формат
                                )
                        
                        # Обрабатываем числовые поля
                        if 'docno' in self.transactions_df.columns:
                            self.transactions_df['docno'] = pd.to_numeric(self.transactions_df['docno'], errors='coerce')
                        
                        # Обрабатываем target (0 или 1 - флаг мошенничества)
                        if 'target' in self.transactions_df.columns:
                            self.transactions_df['target'] = pd.to_numeric(self.transactions_df['target'], errors='coerce').fillna(0).astype(int)
                        
                        # Очищаем direction от кавычек и пробелов
                        if 'direction' in self.transactions_df.columns:
                            self.transactions_df['direction'] = self.transactions_df['direction'].astype(str).str.replace("'", "").str.strip()
                        
                        print(f"CSV файл успешно загружен с кодировкой: {encoding}")
                        print(f"Загружено строк: {len(self.transactions_df)}")
                        print(f"Колонки: {list(self.transactions_df.columns)}")
                        break
                    except (UnicodeDecodeError, UnicodeError) as e:
                        continue
                    except Exception as e:
                        print(f"Ошибка при чтении с кодировкой {encoding}: {e}")
                        import traceback
                        traceback.print_exc()
                        continue
                
                if self.transactions_df is None:
                    raise Exception("Не удалось загрузить CSV файл ни с одной кодировкой")
                # Очистка данных
                if self.transactions_df is not None and not self.transactions_df.empty:
                    # Обработка суммы
                    if 'amount' in self.transactions_df.columns:
                        self.transactions_df['amount'] = pd.to_numeric(self.transactions_df['amount'], errors='coerce')
                    
                    # Удаляем строки без суммы
                    if 'amount' in self.transactions_df.columns:
                        self.transactions_df = self.transactions_df.dropna(subset=['amount'])
                    
                    # Преобразуем ID клиента в числовой формат если возможно
                    if 'cst_dim_id' in self.transactions_df.columns:
                        self.transactions_df['cst_dim_id'] = pd.to_numeric(self.transactions_df['cst_dim_id'], errors='coerce')
                        self.transactions_df = self.transactions_df.dropna(subset=['cst_dim_id'])
            else:
                print(f"CSV файл не найден по пути: {csv_path}")
                self.transactions_df = pd.DataFrame()
        except Exception as e:
            print(f"Ошибка загрузки данных: {e}")
            import traceback
            traceback.print_exc()
            self.transactions_df = pd.DataFrame()
    
    def calculate_statistics(self):
        """Вычислить статистику по транзакциям для анализа"""
        if self.transactions_df is None or self.transactions_df.empty:
            self.stats = {}
            return
        
        try:
            # Статистика по клиентам
            client_stats = self.transactions_df.groupby('cst_dim_id').agg({
                'amount': ['mean', 'std', 'max', 'min', 'count'],
                'target': 'sum'
            }).fillna(0)
            
            # Статистика по получателям (direction)
            direction_stats = self.transactions_df.groupby('direction').agg({
                'amount': ['mean', 'count'],
                'target': 'sum'
            }).fillna(0)
            
            self.stats = {
                'client_stats': client_stats.to_dict(),
                'direction_stats': direction_stats.to_dict(),
                'avg_amount': self.transactions_df['amount'].mean(),
                'median_amount': self.transactions_df['amount'].median(),
                'fraud_rate': self.transactions_df['target'].mean() if 'target' in self.transactions_df.columns else 0
            }
        except Exception as e:
            print(f"Ошибка вычисления статистики: {e}")
            self.stats = {}
    
    def analyze_transaction(self, transaction_data):
        """
        Быстрый анализ транзакции на основе правил и статистики
        
        Args:
            transaction_data: dict с данными транзакции
                - cst_dim_id: ID клиента (опционально)
                - amount: сумма транзакции
                - direction: хеш получателя (опционально)
                - transdatetime: дата и время (опционально)
        
        Returns:
            dict с результатами анализа
        """
        if not self.stats:
            return {
                'risk_level': 'unknown',
                'risk_score': 0,
                'reasons': ['Недостаточно данных для анализа']
            }
        
        risk_score = 0
        reasons = []
        
        # Проверка суммы транзакции
        amount = float(transaction_data.get('amount', 0))
        if amount <= 0:
            return {
                'risk_level': 'high',
                'risk_score': 100,
                'reasons': ['Некорректная сумма транзакции']
            }
        
        # Анализ суммы
        avg_amount = self.stats.get('avg_amount', 10000)
        median_amount = self.stats.get('median_amount', 5000)
        
        if amount > avg_amount * 3:
            risk_score += 30
            reasons.append(f'Сумма {amount:,.0f} значительно превышает среднюю ({avg_amount:,.0f})')
        elif amount > avg_amount * 2:
            risk_score += 15
            reasons.append(f'Сумма {amount:,.0f} превышает среднюю ({avg_amount:,.0f})')
        
        if amount > 50000:
            risk_score += 20
            reasons.append('Крупная сумма транзакции (>50,000)')
        
        # Анализ по клиенту
        cst_dim_id = transaction_data.get('cst_dim_id')
        if cst_dim_id and self.transactions_df is not None and not self.transactions_df.empty:
            client_transactions = self.transactions_df[
                self.transactions_df['cst_dim_id'] == int(cst_dim_id)
            ]
            
            if not client_transactions.empty:
                client_avg = client_transactions['amount'].mean()
                client_max = client_transactions['amount'].max()
                client_count = len(client_transactions)
                
                if amount > client_max * 1.5:
                    risk_score += 25
                    reasons.append(f'Сумма превышает максимальную историческую транзакцию клиента')
                
                if amount > client_avg * 2:
                    risk_score += 15
                    reasons.append(f'Сумма значительно превышает среднюю транзакцию клиента')
            else:
                risk_score += 10
                reasons.append('Новый клиент без истории транзакций')
        
        # Анализ по получателю
        direction = transaction_data.get('direction')
        if direction and self.transactions_df is not None and not self.transactions_df.empty:
            direction_transactions = self.transactions_df[
                self.transactions_df['direction'] == direction
            ]
            
            if not direction_transactions.empty:
                fraud_count = direction_transactions['target'].sum() if 'target' in direction_transactions.columns else 0
                if fraud_count > 0:
                    risk_score += 40
                    reasons.append(f'Получатель связан с {fraud_count} мошенническими транзакциями')
                
                direction_count = len(direction_transactions)
                if direction_count > 100:
                    risk_score += 10
                    reasons.append('Получатель имеет множество транзакций')
        
        # Анализ времени
        transdatetime = transaction_data.get('transdatetime')
        if transdatetime:
            try:
                dt = pd.to_datetime(transdatetime)
                hour = dt.hour
                
                # Подозрительное время: поздняя ночь или раннее утро
                if hour >= 23 or hour < 6:
                    risk_score += 15
                    reasons.append(f'Транзакция в нестандартное время ({hour}:00)')
            except:
                pass
        
        # Определение уровня риска
        if risk_score >= 70:
            risk_level = 'high'
        elif risk_score >= 40:
            risk_level = 'medium'
        else:
            risk_level = 'low'
        
        return {
            'risk_level': risk_level,
            'risk_score': min(risk_score, 100),
            'reasons': reasons if reasons else ['Транзакция выглядит нормально'],
            'amount': amount
        }
    
    def prepare_features(self, transaction_data, include_history=True):
        """Подготовить признаки для ML-модели"""
        features = {}
        
        amount = float(transaction_data.get('amount', 0))
        cst_dim_id = transaction_data.get('cst_dim_id')
        direction = transaction_data.get('direction', '')
        transdatetime = transaction_data.get('transdatetime')
        
        # Базовые признаки
        features['amount'] = amount
        features['amount_log'] = np.log1p(amount) if amount > 0 else 0
        
        # Признаки времени
        if transdatetime:
            try:
                dt = pd.to_datetime(transdatetime)
                features['hour'] = dt.hour
                features['day_of_week'] = dt.dayofweek
                features['day_of_month'] = dt.day
                features['month'] = dt.month
            except:
                features['hour'] = 12
                features['day_of_week'] = 0
                features['day_of_month'] = 15
                features['month'] = 6
        else:
            features['hour'] = 12
            features['day_of_week'] = 0
            features['day_of_month'] = 15
            features['month'] = 6
        
        # Статистика по клиенту
        if cst_dim_id and include_history and self.transactions_df is not None and not self.transactions_df.empty:
            try:
                client_transactions = self.transactions_df[
                    self.transactions_df['cst_dim_id'] == int(cst_dim_id)
                ]
                
                if not client_transactions.empty:
                    features['client_avg_amount'] = client_transactions['amount'].mean()
                    features['client_max_amount'] = client_transactions['amount'].max()
                    features['client_min_amount'] = client_transactions['amount'].min()
                    features['client_transaction_count'] = len(client_transactions)
                    features['client_fraud_count'] = client_transactions['target'].sum() if 'target' in client_transactions.columns else 0
                    features['amount_vs_client_avg'] = amount / (client_transactions['amount'].mean() + 1)
                    features['amount_vs_client_max'] = amount / (client_transactions['amount'].max() + 1)
                else:
                    # Новый клиент
                    features['client_avg_amount'] = self.stats.get('avg_amount', 10000)
                    features['client_max_amount'] = amount
                    features['client_min_amount'] = amount
                    features['client_transaction_count'] = 0
                    features['client_fraud_count'] = 0
                    features['amount_vs_client_avg'] = amount / (self.stats.get('avg_amount', 10000) + 1)
                    features['amount_vs_client_max'] = 1.0
            except:
                features['client_avg_amount'] = self.stats.get('avg_amount', 10000)
                features['client_max_amount'] = amount
                features['client_min_amount'] = amount
                features['client_transaction_count'] = 0
                features['client_fraud_count'] = 0
                features['amount_vs_client_avg'] = amount / (self.stats.get('avg_amount', 10000) + 1)
                features['amount_vs_client_max'] = 1.0
        else:
            features['client_avg_amount'] = self.stats.get('avg_amount', 10000)
            features['client_max_amount'] = amount
            features['client_min_amount'] = amount
            features['client_transaction_count'] = 0
            features['client_fraud_count'] = 0
            features['amount_vs_client_avg'] = amount / (self.stats.get('avg_amount', 10000) + 1)
            features['amount_vs_client_max'] = 1.0
        
        # Статистика по получателю (direction)
        if direction and include_history and self.transactions_df is not None and not self.transactions_df.empty:
            try:
                direction_transactions = self.transactions_df[
                    self.transactions_df['direction'] == direction
                ]
                
                if not direction_transactions.empty:
                    features['direction_transaction_count'] = len(direction_transactions)
                    features['direction_fraud_count'] = direction_transactions['target'].sum() if 'target' in direction_transactions.columns else 0
                    features['direction_fraud_rate'] = features['direction_fraud_count'] / len(direction_transactions)
                else:
                    features['direction_transaction_count'] = 0
                    features['direction_fraud_count'] = 0
                    features['direction_fraud_rate'] = 0
            except:
                features['direction_transaction_count'] = 0
                features['direction_fraud_count'] = 0
                features['direction_fraud_rate'] = 0
        else:
            features['direction_transaction_count'] = 0
            features['direction_fraud_count'] = 0
            features['direction_fraud_rate'] = 0
        
        # Относительные признаки
        features['amount_vs_avg'] = amount / (self.stats.get('avg_amount', 10000) + 1)
        features['amount_vs_median'] = amount / (self.stats.get('median_amount', 5000) + 1)
        
        return features
    
    def train_model(self):
        """Обучить ML-модель на данных"""
        if self.transactions_df is None or self.transactions_df.empty:
            print("Нет данных для обучения модели")
            return False
        
        if 'target' not in self.transactions_df.columns:
            print("Колонка 'target' не найдена в данных")
            return False
        
        try:
            print("Начинаю подготовку данных для обучения...")
            
            # Подготовка данных
            X_list = []
            y_list = []
            
            # Обрабатываем каждую транзакцию
            for idx, row in self.transactions_df.iterrows():
                try:
                    transaction_data = {
                        'amount': row.get('amount', 0),
                        'cst_dim_id': row.get('cst_dim_id'),
                        'direction': row.get('direction', ''),
                        'transdatetime': row.get('transdatetime')
                    }
                    
                    features = self.prepare_features(transaction_data, include_history=True)
                    X_list.append(list(features.values()))
                    y_list.append(int(row.get('target', 0)))
                except Exception as e:
                    continue
            
            if len(X_list) == 0:
                print("Не удалось подготовить данные для обучения")
                return False
            
            X = np.array(X_list)
            y = np.array(y_list)
            
            # Разделение на обучающую и тестовую выборки
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42, stratify=y
            )
            
            print(f"Размер обучающей выборки: {len(X_train)}")
            print(f"Размер тестовой выборки: {len(X_test)}")
            print(f"Доля мошенничества в обучающей выборке: {y_train.mean():.2%}")
            
            # Обучение модели
            print("Обучаю модель RandomForest...")
            self.ml_model = RandomForestClassifier(
                n_estimators=100,
                max_depth=15,
                min_samples_split=5,
                min_samples_leaf=2,
                random_state=42,
                n_jobs=-1,
                class_weight='balanced'
            )
            
            self.ml_model.fit(X_train, y_train)
            
            # Сохранение названий признаков
            self.feature_names = list(features.keys())
            
            # Оценка модели
            y_pred = self.ml_model.predict(X_test)
            y_pred_proba = self.ml_model.predict_proba(X_test)[:, 1]
            
            self.model_metrics = {
                'accuracy': accuracy_score(y_test, y_pred),
                'precision': precision_score(y_test, y_pred, zero_division=0),
                'recall': recall_score(y_test, y_pred, zero_division=0),
                'f1': f1_score(y_test, y_pred, zero_division=0),
                'train_size': len(X_train),
                'test_size': len(X_test)
            }
            
            print(f"Точность модели: {self.model_metrics['accuracy']:.4f}")
            print(f"Precision: {self.model_metrics['precision']:.4f}")
            print(f"Recall: {self.model_metrics['recall']:.4f}")
            print(f"F1-score: {self.model_metrics['f1']:.4f}")
            
            # Сохранение модели
            model_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), MODEL_PATH)
            os.makedirs(os.path.dirname(model_path), exist_ok=True)
            
            with open(model_path, 'wb') as f:
                pickle.dump({
                    'model': self.ml_model,
                    'feature_names': self.feature_names,
                    'metrics': self.model_metrics
                }, f)
            
            print(f"Модель сохранена: {model_path}")
            return True
            
        except Exception as e:
            print(f"Ошибка при обучении модели: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def load_or_train_model(self):
        """Загрузить сохраненную модель или обучить новую"""
        model_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), MODEL_PATH)
        
        # Пытаемся загрузить сохраненную модель
        if os.path.exists(model_path):
            try:
                with open(model_path, 'rb') as f:
                    model_data = pickle.load(f)
                    self.ml_model = model_data['model']
                    self.feature_names = model_data.get('feature_names', [])
                    self.model_metrics = model_data.get('metrics', {})
                print(f"ML-модель загружена из {model_path}")
                if self.model_metrics:
                    print(f"Метрики модели: Accuracy={self.model_metrics.get('accuracy', 0):.4f}")
                return
            except Exception as e:
                print(f"Не удалось загрузить модель: {e}")
        
        # Если модель не загружена, обучаем новую
        print("Обучение новой ML-модели...")
        self.train_model()
    
    def predict_fraud(self, transaction_data):
        """Предсказать вероятность мошенничества используя ML-модель"""
        if self.ml_model is None:
            # Если модель не обучена, используем rule-based анализ
            return self.analyze_transaction(transaction_data)
        
        try:
            features = self.prepare_features(transaction_data, include_history=True)
            
            # Проверяем, что все признаки есть
            if not self.feature_names or len(self.feature_names) != len(features):
                # Если структура признаков изменилась, переобучаем модель
                print("Структура признаков изменилась, переобучаю модель...")
                self.train_model()
                if self.ml_model is None:
                    return self.analyze_transaction(transaction_data)
                features = self.prepare_features(transaction_data, include_history=True)
            
            # Формируем вектор признаков в правильном порядке
            feature_vector = np.array([features.get(name, 0) for name in self.feature_names])
            feature_vector = feature_vector.reshape(1, -1)
            
            # Предсказание
            fraud_proba = self.ml_model.predict_proba(feature_vector)[0, 1]
            fraud_prediction = self.ml_model.predict(feature_vector)[0]
            
            # Определяем уровень риска
            risk_score = int(fraud_proba * 100)
            
            if risk_score >= 70:
                risk_level = 'high'
            elif risk_score >= 40:
                risk_level = 'medium'
            else:
                risk_level = 'low'
            
            # Получаем важность признаков для объяснения
            if hasattr(self.ml_model, 'feature_importances_'):
                feature_importances = dict(zip(self.feature_names, self.ml_model.feature_importances_))
                top_features = sorted(feature_importances.items(), key=lambda x: x[1], reverse=True)[:5]
                reasons = [f"{name}: {imp:.2%}" for name, imp in top_features if imp > 0.01]
            else:
                reasons = []
            
            if not reasons:
                reasons = [f"Вероятность мошенничества: {risk_score}%"]
            
            return {
                'risk_level': risk_level,
                'risk_score': risk_score,
                'fraud_probability': float(fraud_proba),
                'fraud_prediction': bool(fraud_prediction),
                'reasons': reasons,
                'amount': float(transaction_data.get('amount', 0)),
                'model_type': 'ml'
            }
            
        except Exception as e:
            print(f"Ошибка при предсказании: {e}")
            import traceback
            traceback.print_exc()
            # В случае ошибки используем rule-based анализ
            return self.analyze_transaction(transaction_data)
    
    def get_client_history(self, cst_dim_id):
        """Получить историю транзакций клиента"""
        if self.transactions_df is None or self.transactions_df.empty:
            return pd.DataFrame()
        
        try:
            client_data = self.transactions_df[
                self.transactions_df['cst_dim_id'] == int(cst_dim_id)
            ].sort_values('transdatetime', ascending=False)
            
            return client_data.head(20)  # Последние 20 транзакций
        except:
            return pd.DataFrame()
    
    def get_suspicious_transactions(self, limit=10):
        """Получить подозрительные транзакции"""
        if self.transactions_df is None or self.transactions_df.empty:
            return pd.DataFrame()
        
        try:
            # Транзакции с мошенничеством
            if 'target' in self.transactions_df.columns:
                fraud_transactions = self.transactions_df[
                    self.transactions_df['target'] == 1
                ].sort_values('transdatetime', ascending=False)
                
                return fraud_transactions.head(limit)
        except:
            pass
        
        return pd.DataFrame()

# Глобальный экземпляр модели
antifraud_model = None

def get_model():
    """Получить или создать экземпляр модели"""
    global antifraud_model
    if antifraud_model is None:
        antifraud_model = AntiFraudModel()
    return antifraud_model

