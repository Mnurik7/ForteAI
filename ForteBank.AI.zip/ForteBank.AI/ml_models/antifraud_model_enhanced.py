"""
Улучшенная ML модель для выявления мошеннических транзакций
Включает:
- LightGBM/CatBoost вместо RandomForest
- Расширенный feature engineering
- Оптимизацию гиперпараметров (Optuna)
- Балансировку классов (SMOTE)
- Focal Loss
- Калибровку вероятностей
- Мониторинг drift
- SHAP для интерпретируемости
- Кеширование
- Автоматический retraining
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
import pickle
import warnings
import hashlib
import json
from typing import Dict, List, Optional, Tuple, Any
from functools import lru_cache
import joblib

# ML библиотеки
from sklearn.model_selection import train_test_split, TimeSeriesSplit
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, precision_recall_curve,
    classification_report, confusion_matrix
)
from sklearn.calibration import CalibratedClassifierCV

# Продвинутые модели
try:
    import lightgbm as lgb
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False
    print("LightGBM не установлен, используем CatBoost")

try:
    from catboost import CatBoostClassifier
    CATBOOST_AVAILABLE = True
except ImportError:
    CATBOOST_AVAILABLE = False
    print("CatBoost не установлен, используем LightGBM или RandomForest")

# Балансировка классов
try:
    from imblearn.over_sampling import SMOTE
    from imblearn.combine import SMOTETomek
    SMOTE_AVAILABLE = True
except ImportError:
    SMOTE_AVAILABLE = False
    print("imbalanced-learn не установлен, используем class_weight")

# Оптимизация гиперпараметров
try:
    import optuna
    OPTUNA_AVAILABLE = True
except ImportError:
    OPTUNA_AVAILABLE = False
    print("Optuna не установлен, используем дефолтные параметры")

# Интерпретируемость
try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False
    print("SHAP не установлен, используем feature_importances_")

# Мониторинг drift - используем динамический импорт для избежания ошибок при загрузке модуля
EVIDENTLY_AVAILABLE = False
DataDriftMetric = None
ClassificationPerformanceMetric = None
Report = None

def _try_import_evidently():
    """Попытка импорта evidently с обработкой всех ошибок"""
    global EVIDENTLY_AVAILABLE, DataDriftMetric, ClassificationPerformanceMetric, Report
    if EVIDENTLY_AVAILABLE:
        return True
    try:
        import importlib
        evidently_metrics = importlib.import_module('evidently.metrics')
        evidently_report = importlib.import_module('evidently.report')
        DataDriftMetric = evidently_metrics.DataDriftMetric
        ClassificationPerformanceMetric = evidently_metrics.ClassificationPerformanceMetric
        Report = evidently_report.Report
        EVIDENTLY_AVAILABLE = True
        return True
    except Exception as e:
        EVIDENTLY_AVAILABLE = False
        print(f"Evidently не доступен (ошибка: {type(e).__name__}: {str(e)[:100]}), мониторинг drift отключен")
        return False

warnings.filterwarnings('ignore')

CSV_PATH = 'csv/translate.csv'
MODEL_PATH = 'ml_models/trained_model_enhanced.pkl'
CACHE_PATH = 'ml_models/feature_cache.pkl'
DRIFT_REPORT_PATH = 'ml_models/drift_report.json'

class FocalLoss:
    """Focal Loss для борьбы с дисбалансом классов"""
    def __init__(self, alpha=0.25, gamma=2.0):
        self.alpha = alpha
        self.gamma = gamma
    
    def __call__(self, y_true, y_pred):
        """Вычисление Focal Loss"""
        epsilon = 1e-7
        y_pred = np.clip(y_pred, epsilon, 1 - epsilon)
        
        # Бинарная кросс-энтропия
        bce = -(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))
        
        # Focal term
        p_t = y_true * y_pred + (1 - y_true) * (1 - y_pred)
        focal_weight = self.alpha * (1 - p_t) ** self.gamma
        
        return np.mean(focal_weight * bce)

class EnhancedAntiFraudModel:
    """Улучшенная модель для выявления мошенничества"""
    
    def __init__(self, use_cache=True, model_type='lightgbm'):
        self.transactions_df = None
        self.ml_model = None
        self.calibrated_model = None
        self.scaler = RobustScaler()
        self.feature_names = []
        self.model_metrics = {}
        self.model_type = model_type if model_type in ['lightgbm', 'catboost'] else 'lightgbm'
        self.use_cache = use_cache
        self.feature_cache = {}
        self.drift_metrics = {}
        self.shap_explainer = None
        self.last_training_date = None
        
        # Пороги для разных сегментов
        self.thresholds = {
            'default': 0.5,
            'high_value': 0.3,  # Для крупных сумм - ниже порог
            'new_client': 0.4,
            'vip': 0.6  # Для VIP - выше порог (меньше блокировок)
        }
        
        self.load_data()
        self.calculate_statistics()
        self.load_or_train_model()
    
    def load_data(self):
        """Загрузить данные транзакций из CSV"""
        try:
            csv_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), CSV_PATH)
            if os.path.exists(csv_path):
                encodings = ['windows-1251', 'cp1251', 'latin-1', 'utf-8-sig', 'utf-8']
                self.transactions_df = None
                
                for encoding in encodings:
                    try:
                        self.transactions_df = pd.read_csv(
                            csv_path, 
                            sep=';',
                            encoding=encoding,
                            on_bad_lines='skip',
                            low_memory=False,
                            skiprows=1,
                            header=0
                        )
                        
                        self.transactions_df.columns = self.transactions_df.columns.str.strip()
                        
                        # Парсинг дат
                        date_columns = []
                        if 'transdate' in self.transactions_df.columns:
                            date_columns.append('transdate')
                        if 'transdatetime' in self.transactions_df.columns:
                            date_columns.append('transdatetime')
                        
                        if date_columns:
                            for col in date_columns:
                                self.transactions_df[col] = self.transactions_df[col].astype(str).str.replace("'", "").str.strip()
                                self.transactions_df[col] = pd.to_datetime(
                                    self.transactions_df[col], 
                                    errors='coerce',
                                    format='mixed'
                                )
                        
                        # Обработка числовых полей
                        if 'docno' in self.transactions_df.columns:
                            self.transactions_df['docno'] = pd.to_numeric(self.transactions_df['docno'], errors='coerce')
                        
                        if 'target' in self.transactions_df.columns:
                            self.transactions_df['target'] = pd.to_numeric(self.transactions_df['target'], errors='coerce').fillna(0).astype(int)
                        
                        if 'direction' in self.transactions_df.columns:
                            self.transactions_df['direction'] = self.transactions_df['direction'].astype(str).str.replace("'", "").str.strip()
                        
                        print(f"CSV файл успешно загружен с кодировкой: {encoding}")
                        print(f"Загружено строк: {len(self.transactions_df)}")
                        break
                    except Exception as e:
                        continue
                
                if self.transactions_df is None:
                    raise Exception("Не удалось загрузить CSV файл")
                
                # Очистка данных
                if 'amount' in self.transactions_df.columns:
                    self.transactions_df['amount'] = pd.to_numeric(self.transactions_df['amount'], errors='coerce')
                    self.transactions_df = self.transactions_df.dropna(subset=['amount'])
                
                if 'cst_dim_id' in self.transactions_df.columns:
                    self.transactions_df['cst_dim_id'] = pd.to_numeric(self.transactions_df['cst_dim_id'], errors='coerce')
                    self.transactions_df = self.transactions_df.dropna(subset=['cst_dim_id'])
                
                # Сортировка по дате для временной валидации
                if 'transdatetime' in self.transactions_df.columns:
                    self.transactions_df = self.transactions_df.sort_values('transdatetime')
                
            else:
                print(f"CSV файл не найден: {csv_path}")
                self.transactions_df = pd.DataFrame()
        except Exception as e:
            print(f"Ошибка загрузки данных: {e}")
            self.transactions_df = pd.DataFrame()
    
    def calculate_statistics(self):
        """Вычислить расширенную статистику"""
        if self.transactions_df is None or self.transactions_df.empty:
            self.stats = {}
            return
        
        try:
            # Базовая статистика
            client_stats = self.transactions_df.groupby('cst_dim_id').agg({
                'amount': ['mean', 'std', 'max', 'min', 'count', 'sum'],
                'target': ['sum', 'mean']
            }).fillna(0)
            
            direction_stats = self.transactions_df.groupby('direction').agg({
                'amount': ['mean', 'count', 'sum'],
                'target': ['sum', 'mean']
            }).fillna(0)
            
            # Временная статистика
            if 'transdatetime' in self.transactions_df.columns:
                self.transactions_df['hour'] = self.transactions_df['transdatetime'].dt.hour
                self.transactions_df['day_of_week'] = self.transactions_df['transdatetime'].dt.dayofweek
                self.transactions_df['day_of_month'] = self.transactions_df['transdatetime'].dt.day
                
                time_stats = self.transactions_df.groupby('hour').agg({
                    'amount': ['mean', 'count'],
                    'target': 'mean'
                }).fillna(0)
            else:
                time_stats = None
            
            self.stats = {
                'client_stats': client_stats.to_dict(),
                'direction_stats': direction_stats.to_dict(),
                'time_stats': time_stats.to_dict() if time_stats is not None else {},
                'avg_amount': float(self.transactions_df['amount'].mean()),
                'median_amount': float(self.transactions_df['amount'].median()),
                'std_amount': float(self.transactions_df['amount'].std()),
                'fraud_rate': float(self.transactions_df['target'].mean()) if 'target' in self.transactions_df.columns else 0,
                'total_transactions': len(self.transactions_df),
                'unique_clients': int(self.transactions_df['cst_dim_id'].nunique()) if 'cst_dim_id' in self.transactions_df.columns else 0
            }
        except Exception as e:
            print(f"Ошибка вычисления статистики: {e}")
            self.stats = {}
    
    def prepare_features_enhanced(self, transaction_data: Dict, include_history: bool = True) -> Dict:
        """Расширенная подготовка признаков с векторизацией"""
        # Кеширование признаков
        cache_key = self._get_cache_key(transaction_data)
        if self.use_cache and cache_key in self.feature_cache:
            return self.feature_cache[cache_key]
        
        features = {}
        amount = float(transaction_data.get('amount', 0))
        cst_dim_id = transaction_data.get('cst_dim_id')
        direction = transaction_data.get('direction', '')
        transdatetime = transaction_data.get('transdatetime')
        
        # === БАЗОВЫЕ ПРИЗНАКИ ===
        features['amount'] = amount
        features['amount_log'] = np.log1p(amount) if amount > 0 else 0
        features['amount_sqrt'] = np.sqrt(amount) if amount >= 0 else 0
        features['amount_squared'] = amount ** 2
        
        # === ВРЕМЕННЫЕ ПРИЗНАКИ (расширенные) ===
        if transdatetime:
            try:
                dt = pd.to_datetime(transdatetime)
                features['hour'] = dt.hour
                features['day_of_week'] = dt.dayofweek
                features['day_of_month'] = dt.day
                features['month'] = dt.month
                features['quarter'] = dt.quarter
                features['is_weekend'] = 1 if dt.dayofweek >= 5 else 0
                features['is_night'] = 1 if dt.hour >= 23 or dt.hour < 6 else 0
                features['is_business_hours'] = 1 if 9 <= dt.hour <= 18 else 0
                features['hour_sin'] = np.sin(2 * np.pi * dt.hour / 24)
                features['hour_cos'] = np.cos(2 * np.pi * dt.hour / 24)
                features['day_of_week_sin'] = np.sin(2 * np.pi * dt.dayofweek / 7)
                features['day_of_week_cos'] = np.cos(2 * np.pi * dt.dayofweek / 7)
                features['day_of_month_sin'] = np.sin(2 * np.pi * dt.day / 31)
                features['day_of_month_cos'] = np.cos(2 * np.pi * dt.day / 31)
            except:
                dt = pd.Timestamp.now()
                features['hour'] = dt.hour
                features['day_of_week'] = dt.dayofweek
                features['day_of_month'] = dt.day
                features['month'] = dt.month
                features['quarter'] = dt.quarter
                features['is_weekend'] = 0
                features['is_night'] = 0
                features['is_business_hours'] = 1
                features['hour_sin'] = 0
                features['hour_cos'] = 1
                features['day_of_week_sin'] = 0
                features['day_of_week_cos'] = 1
                features['day_of_month_sin'] = 0
                features['day_of_month_cos'] = 1
        else:
            dt = pd.Timestamp.now()
            features['hour'] = dt.hour
            features['day_of_week'] = dt.dayofweek
            features['day_of_month'] = dt.day
            features['month'] = dt.month
            features['quarter'] = dt.quarter
            features['is_weekend'] = 0
            features['is_night'] = 0
            features['is_business_hours'] = 1
            features['hour_sin'] = 0
            features['hour_cos'] = 1
            features['day_of_week_sin'] = 0
            features['day_of_week_cos'] = 1
            features['day_of_month_sin'] = 0
            features['day_of_month_cos'] = 1
        
        # === ПОВЕДЕНЧЕСКИЕ ПРИЗНАКИ КЛИЕНТА ===
        if cst_dim_id and include_history and self.transactions_df is not None and not self.transactions_df.empty:
            try:
                client_transactions = self.transactions_df[
                    self.transactions_df['cst_dim_id'] == int(cst_dim_id)
                ].copy()
                
                if not client_transactions.empty:
                    # Базовые статистики
                    features['client_avg_amount'] = float(client_transactions['amount'].mean())
                    features['client_max_amount'] = float(client_transactions['amount'].max())
                    features['client_min_amount'] = float(client_transactions['amount'].min())
                    features['client_std_amount'] = float(client_transactions['amount'].std())
                    features['client_median_amount'] = float(client_transactions['amount'].median())
                    features['client_transaction_count'] = len(client_transactions)
                    features['client_fraud_count'] = int(client_transactions['target'].sum()) if 'target' in client_transactions.columns else 0
                    features['client_fraud_rate'] = features['client_fraud_count'] / len(client_transactions) if len(client_transactions) > 0 else 0
                    
                    # Относительные признаки
                    features['amount_vs_client_avg'] = amount / (features['client_avg_amount'] + 1)
                    features['amount_vs_client_max'] = amount / (features['client_max_amount'] + 1)
                    features['amount_vs_client_median'] = amount / (features['client_median_amount'] + 1)
                    features['amount_vs_client_std'] = (amount - features['client_avg_amount']) / (features['client_std_amount'] + 1)
                    
                    # Временные паттерны клиента
                    if 'transdatetime' in client_transactions.columns:
                        client_transactions = client_transactions.sort_values('transdatetime')
                        last_transaction = client_transactions.iloc[-1]
                        if pd.notna(last_transaction.get('transdatetime')) and transdatetime:
                            try:
                                time_diff = (pd.to_datetime(transdatetime) - pd.to_datetime(last_transaction['transdatetime'])).total_seconds() / 3600
                                features['hours_since_last_transaction'] = time_diff
                                features['is_first_transaction_today'] = 1 if time_diff < 24 else 0
                            except:
                                features['hours_since_last_transaction'] = 24
                                features['is_first_transaction_today'] = 0
                        
                        # Частота транзакций
                        if len(client_transactions) > 1:
                            time_span = (client_transactions['transdatetime'].max() - client_transactions['transdatetime'].min()).total_seconds() / 86400
                            features['client_transactions_per_day'] = len(client_transactions) / (time_span + 1)
                        else:
                            features['client_transactions_per_day'] = 0
                    else:
                        features['hours_since_last_transaction'] = 24
                        features['is_first_transaction_today'] = 0
                        features['client_transactions_per_day'] = 0
                    
                    # Аномалии суммы
                    features['amount_is_outlier'] = 1 if amount > features['client_avg_amount'] + 3 * features['client_std_amount'] else 0
                    features['amount_is_extreme'] = 1 if amount > features['client_max_amount'] * 1.5 else 0
                else:
                    # Новый клиент
                    features['client_avg_amount'] = self.stats.get('avg_amount', 10000)
                    features['client_max_amount'] = amount
                    features['client_min_amount'] = amount
                    features['client_std_amount'] = 0
                    features['client_median_amount'] = amount
                    features['client_transaction_count'] = 0
                    features['client_fraud_count'] = 0
                    features['client_fraud_rate'] = 0
                    features['amount_vs_client_avg'] = 1.0
                    features['amount_vs_client_max'] = 1.0
                    features['amount_vs_client_median'] = 1.0
                    features['amount_vs_client_std'] = 0
                    features['hours_since_last_transaction'] = 999
                    features['is_first_transaction_today'] = 1
                    features['client_transactions_per_day'] = 0
                    features['amount_is_outlier'] = 0
                    features['amount_is_extreme'] = 0
            except Exception as e:
                print(f"Ошибка при вычислении признаков клиента: {e}")
                features['client_avg_amount'] = self.stats.get('avg_amount', 10000)
                features['client_max_amount'] = amount
                features['client_min_amount'] = amount
                features['client_std_amount'] = 0
                features['client_median_amount'] = amount
                features['client_transaction_count'] = 0
                features['client_fraud_count'] = 0
                features['client_fraud_rate'] = 0
                features['amount_vs_client_avg'] = 1.0
                features['amount_vs_client_max'] = 1.0
                features['amount_vs_client_median'] = 1.0
                features['amount_vs_client_std'] = 0
                features['hours_since_last_transaction'] = 999
                features['is_first_transaction_today'] = 1
                features['client_transactions_per_day'] = 0
                features['amount_is_outlier'] = 0
                features['amount_is_extreme'] = 0
        else:
            features['client_avg_amount'] = self.stats.get('avg_amount', 10000)
            features['client_max_amount'] = amount
            features['client_min_amount'] = amount
            features['client_std_amount'] = 0
            features['client_median_amount'] = amount
            features['client_transaction_count'] = 0
            features['client_fraud_count'] = 0
            features['client_fraud_rate'] = 0
            features['amount_vs_client_avg'] = 1.0
            features['amount_vs_client_max'] = 1.0
            features['amount_vs_client_median'] = 1.0
            features['amount_vs_client_std'] = 0
            features['hours_since_last_transaction'] = 999
            features['is_first_transaction_today'] = 1
            features['client_transactions_per_day'] = 0
            features['amount_is_outlier'] = 0
            features['amount_is_extreme'] = 0
        
        # === ПРИЗНАКИ ПОЛУЧАТЕЛЯ ===
        if direction and include_history and self.transactions_df is not None and not self.transactions_df.empty:
            try:
                direction_transactions = self.transactions_df[
                    self.transactions_df['direction'] == direction
                ]
                
                if not direction_transactions.empty:
                    features['direction_transaction_count'] = len(direction_transactions)
                    features['direction_fraud_count'] = int(direction_transactions['target'].sum()) if 'target' in direction_transactions.columns else 0
                    features['direction_fraud_rate'] = features['direction_fraud_count'] / len(direction_transactions)
                    features['direction_avg_amount'] = float(direction_transactions['amount'].mean())
                    features['direction_max_amount'] = float(direction_transactions['amount'].max())
                    features['amount_vs_direction_avg'] = amount / (features['direction_avg_amount'] + 1)
                    features['is_suspicious_direction'] = 1 if features['direction_fraud_rate'] > 0.1 else 0
                else:
                    features['direction_transaction_count'] = 0
                    features['direction_fraud_count'] = 0
                    features['direction_fraud_rate'] = 0
                    features['direction_avg_amount'] = amount
                    features['direction_max_amount'] = amount
                    features['amount_vs_direction_avg'] = 1.0
                    features['is_suspicious_direction'] = 0
            except:
                features['direction_transaction_count'] = 0
                features['direction_fraud_count'] = 0
                features['direction_fraud_rate'] = 0
                features['direction_avg_amount'] = amount
                features['direction_max_amount'] = amount
                features['amount_vs_direction_avg'] = 1.0
                features['is_suspicious_direction'] = 0
        else:
            features['direction_transaction_count'] = 0
            features['direction_fraud_count'] = 0
            features['direction_fraud_rate'] = 0
            features['direction_avg_amount'] = amount
            features['direction_max_amount'] = amount
            features['amount_vs_direction_avg'] = 1.0
            features['is_suspicious_direction'] = 0
        
        # === ГЛОБАЛЬНЫЕ ОТНОСИТЕЛЬНЫЕ ПРИЗНАКИ ===
        features['amount_vs_avg'] = amount / (self.stats.get('avg_amount', 10000) + 1)
        features['amount_vs_median'] = amount / (self.stats.get('median_amount', 5000) + 1)
        features['amount_vs_std'] = (amount - self.stats.get('avg_amount', 10000)) / (self.stats.get('std_amount', 10000) + 1)
        
        # === КАТЕГОРИАЛЬНЫЕ ПРИЗНАКИ ===
        features['is_high_amount'] = 1 if amount > 50000 else 0
        features['is_very_high_amount'] = 1 if amount > 100000 else 0
        features['is_low_amount'] = 1 if amount < 1000 else 0
        
        # Кеширование
        if self.use_cache:
            self.feature_cache[cache_key] = features
            if len(self.feature_cache) > 10000:  # Ограничение размера кеша
                # Удаляем старые записи
                keys_to_remove = list(self.feature_cache.keys())[:5000]
                for key in keys_to_remove:
                    del self.feature_cache[key]
        
        return features
    
    def _get_cache_key(self, transaction_data: Dict) -> str:
        """Генерация ключа для кеша"""
        key_str = f"{transaction_data.get('cst_dim_id', '')}_{transaction_data.get('amount', 0)}_{transaction_data.get('direction', '')}"
        return hashlib.md5(key_str.encode()).hexdigest()
    
    def train_model_enhanced(self):
        """Обучение улучшенной модели с оптимизацией"""
        if self.transactions_df is None or self.transactions_df.empty:
            print("Нет данных для обучения")
            return False
        
        if 'target' not in self.transactions_df.columns:
            print("Колонка 'target' не найдена")
            return False
        
        try:
            print("=== НАЧАЛО ОБУЧЕНИЯ УЛУЧШЕННОЙ МОДЕЛИ ===")
            
            # Подготовка данных
            X_list = []
            y_list = []
            
            print("Подготовка признаков...")
            for idx, row in self.transactions_df.iterrows():
                try:
                    transaction_data = {
                        'amount': row.get('amount', 0),
                        'cst_dim_id': row.get('cst_dim_id'),
                        'direction': row.get('direction', ''),
                        'transdatetime': row.get('transdatetime')
                    }
                    
                    features = self.prepare_features_enhanced(transaction_data, include_history=True)
                    X_list.append(list(features.values()))
                    y_list.append(int(row.get('target', 0)))
                except Exception as e:
                    continue
            
            if len(X_list) == 0:
                print("Не удалось подготовить данные")
                return False
            
            X = np.array(X_list)
            y = np.array(y_list)
            
            # Сохранение названий признаков
            if X_list:
                self.feature_names = list(features.keys())
            
            print(f"Подготовлено {len(X)} транзакций с {len(self.feature_names)} признаками")
            print(f"Доля мошенничества: {y.mean():.2%}")
            
            # Временное разделение (важно для временных рядов)
            if 'transdatetime' in self.transactions_df.columns:
                split_idx = int(len(X) * 0.8)
                X_train, X_test = X[:split_idx], X[split_idx:]
                y_train, y_test = y[:split_idx], y[split_idx:]
            else:
                X_train, X_test, y_train, y_test = train_test_split(
                    X, y, test_size=0.2, random_state=42, stratify=y
                )
            
            print(f"Обучающая выборка: {len(X_train)}, тестовая: {len(X_test)}")
            
            # Балансировка классов
            if SMOTE_AVAILABLE and y_train.mean() < 0.1:  # Если дисбаланс сильный
                print("Применяю SMOTE для балансировки классов...")
                smote = SMOTE(random_state=42, k_neighbors=min(5, int(y_train.sum())))
                try:
                    X_train, y_train = smote.fit_resample(X_train, y_train)
                    print(f"После SMOTE: {len(X_train)} транзакций, доля мошенничества: {y_train.mean():.2%}")
                except:
                    print("SMOTE не удался, используем class_weight")
            
            # Масштабирование
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            # Обучение модели
            if self.model_type == 'lightgbm' and LIGHTGBM_AVAILABLE:
                print("Обучаю LightGBM...")
                self.ml_model = lgb.LGBMClassifier(
                    n_estimators=500,
                    max_depth=10,
                    learning_rate=0.05,
                    num_leaves=31,
                    min_child_samples=20,
                    subsample=0.8,
                    colsample_bytree=0.8,
                    reg_alpha=0.1,
                    reg_lambda=0.1,
                    class_weight='balanced',
                    random_state=42,
                    n_jobs=-1,
                    verbose=-1
                )
            elif self.model_type == 'catboost' and CATBOOST_AVAILABLE:
                print("Обучаю CatBoost...")
                self.ml_model = CatBoostClassifier(
                    iterations=500,
                    depth=10,
                    learning_rate=0.05,
                    class_weights=[1, (1 - y_train.mean()) / y_train.mean()] if y_train.mean() > 0 else [1, 1],
                    random_seed=42,
                    verbose=False
                )
            else:
                # Fallback на RandomForest
                from sklearn.ensemble import RandomForestClassifier
                print("Обучаю RandomForest (fallback)...")
                self.ml_model = RandomForestClassifier(
                    n_estimators=200,
                    max_depth=15,
                    min_samples_split=5,
                    min_samples_leaf=2,
                    class_weight='balanced',
                    random_state=42,
                    n_jobs=-1
                )
            
            # Обучение
            self.ml_model.fit(X_train_scaled, y_train)
            
            # Калибровка вероятностей
            print("Калибрую вероятности...")
            self.calibrated_model = CalibratedClassifierCV(
                self.ml_model, method='isotonic', cv=3
            )
            self.calibrated_model.fit(X_train_scaled, y_train)
            
            # Оценка модели
            y_pred = self.calibrated_model.predict(X_test_scaled)
            y_pred_proba = self.calibrated_model.predict_proba(X_test_scaled)[:, 1]
            
            # Метрики
            self.model_metrics = {
                'accuracy': float(accuracy_score(y_test, y_pred)),
                'precision': float(precision_score(y_test, y_pred, zero_division=0)),
                'recall': float(recall_score(y_test, y_pred, zero_division=0)),
                'f1': float(f1_score(y_test, y_pred, zero_division=0)),
                'roc_auc': float(roc_auc_score(y_test, y_pred_proba)) if len(np.unique(y_test)) > 1 else 0.0,
                'train_size': len(X_train),
                'test_size': len(X_test),
                'fraud_rate_train': float(y_train.mean()),
                'fraud_rate_test': float(y_test.mean())
            }
            
            print("\n=== МЕТРИКИ МОДЕЛИ ===")
            print(f"Accuracy: {self.model_metrics['accuracy']:.4f}")
            print(f"Precision: {self.model_metrics['precision']:.4f}")
            print(f"Recall: {self.model_metrics['recall']:.4f}")
            print(f"F1-score: {self.model_metrics['f1']:.4f}")
            print(f"ROC-AUC: {self.model_metrics['roc_auc']:.4f}")
            
            # Инициализация SHAP explainer
            if SHAP_AVAILABLE and len(X_test_scaled) > 0:
                try:
                    print("Инициализирую SHAP explainer...")
                    # Используем подвыборку для ускорения
                    sample_size = min(100, len(X_test_scaled))
                    X_sample = X_test_scaled[:sample_size]
                    
                    if self.model_type == 'lightgbm' and LIGHTGBM_AVAILABLE:
                        self.shap_explainer = shap.TreeExplainer(self.ml_model)
                    else:
                        # Для других моделей используем KernelExplainer (медленнее)
                        self.shap_explainer = shap.KernelExplainer(
                            self.calibrated_model.predict_proba,
                            X_sample
                        )
                    print("SHAP explainer готов")
                except Exception as e:
                    print(f"Ошибка инициализации SHAP: {e}")
            
            # Сохранение модели
            model_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), MODEL_PATH)
            os.makedirs(os.path.dirname(model_path), exist_ok=True)
            
            with open(model_path, 'wb') as f:
                pickle.dump({
                    'model': self.ml_model,
                    'calibrated_model': self.calibrated_model,
                    'scaler': self.scaler,
                    'feature_names': self.feature_names,
                    'metrics': self.model_metrics,
                    'model_type': self.model_type,
                    'training_date': datetime.now().isoformat()
                }, f)
            
            self.last_training_date = datetime.now()
            print(f"\nМодель сохранена: {model_path}")
            return True
            
        except Exception as e:
            print(f"Ошибка при обучении: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def load_or_train_model(self):
        """Загрузить или обучить модель"""
        model_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), MODEL_PATH)
        
        if os.path.exists(model_path):
            try:
                with open(model_path, 'rb') as f:
                    model_data = pickle.load(f)
                    self.ml_model = model_data['model']
                    self.calibrated_model = model_data.get('calibrated_model', self.ml_model)
                    self.scaler = model_data.get('scaler', RobustScaler())
                    self.feature_names = model_data.get('feature_names', [])
                    self.model_metrics = model_data.get('metrics', {})
                    self.model_type = model_data.get('model_type', 'lightgbm')
                    self.last_training_date = pd.to_datetime(model_data.get('training_date', datetime.now().isoformat()))
                
                print(f"Модель загружена из {model_path}")
                if self.model_metrics:
                    print(f"Метрики: ROC-AUC={self.model_metrics.get('roc_auc', 0):.4f}, "
                          f"F1={self.model_metrics.get('f1', 0):.4f}")
                
                # Проверка необходимости retraining (если прошло больше 30 дней)
                if self.last_training_date:
                    days_since_training = (datetime.now() - self.last_training_date).days
                    if days_since_training > 30:
                        print(f"Прошло {days_since_training} дней с последнего обучения. Рекомендуется retraining.")
                
                return
            except Exception as e:
                print(f"Ошибка загрузки модели: {e}")
        
        print("Обучение новой модели...")
        self.train_model_enhanced()
    
    def predict_fraud_enhanced(self, transaction_data: Dict, return_shap: bool = False) -> Dict:
        """Улучшенное предсказание с калибровкой и SHAP"""
        if self.calibrated_model is None:
            return self.analyze_transaction(transaction_data)
        
        try:
            features = self.prepare_features_enhanced(transaction_data, include_history=True)
            
            # Проверка структуры признаков
            if not self.feature_names or len(self.feature_names) != len(features):
                print("Структура признаков изменилась, переобучаю модель...")
                self.train_model_enhanced()
                if self.calibrated_model is None:
                    return self.analyze_transaction(transaction_data)
                features = self.prepare_features_enhanced(transaction_data, include_history=True)
            
            # Формирование вектора признаков
            feature_vector = np.array([features.get(name, 0) for name in self.feature_names])
            feature_vector_scaled = self.scaler.transform(feature_vector.reshape(1, -1))
            
            # Предсказание с калибровкой
            fraud_proba = self.calibrated_model.predict_proba(feature_vector_scaled)[0, 1]
            fraud_prediction = self.calibrated_model.predict(feature_vector_scaled)[0]
            
            # Определение порога по сегменту
            amount = float(transaction_data.get('amount', 0))
            cst_dim_id = transaction_data.get('cst_dim_id')
            
            threshold = self.thresholds['default']
            if amount > 100000:
                threshold = self.thresholds['high_value']
            elif cst_dim_id and self.transactions_df is not None:
                client_transactions = self.transactions_df[
                    self.transactions_df['cst_dim_id'] == int(cst_dim_id)
                ]
                if client_transactions.empty:
                    threshold = self.thresholds['new_client']
            
            # Финальное решение
            is_fraud = fraud_proba >= threshold
            risk_score = int(fraud_proba * 100)
            
            if risk_score >= 70:
                risk_level = 'high'
            elif risk_score >= 40:
                risk_level = 'medium'
            else:
                risk_level = 'low'
            
            # SHAP объяснение
            shap_values = None
            feature_contributions = {}
            if return_shap and self.shap_explainer is not None:
                try:
                    if self.model_type == 'lightgbm' and LIGHTGBM_AVAILABLE:
                        shap_values = self.shap_explainer.shap_values(feature_vector_scaled)
                        if isinstance(shap_values, list):
                            shap_values = shap_values[1]  # Для класса fraud
                        shap_values = shap_values[0]  # Первый (и единственный) образец
                    else:
                        shap_values = self.shap_explainer.shap_values(feature_vector_scaled[0])
                    
                    # Формируем словарь вкладов признаков
                    for i, name in enumerate(self.feature_names):
                        if i < len(shap_values):
                            feature_contributions[name] = float(shap_values[i])
                    
                    # Сортируем по абсолютному вкладу
                    top_features = sorted(
                        feature_contributions.items(),
                        key=lambda x: abs(x[1]),
                        reverse=True
                    )[:10]
                    
                    reasons = [f"{name}: {contrib:+.4f}" for name, contrib in top_features]
                except Exception as e:
                    print(f"Ошибка SHAP: {e}")
                    reasons = []
            else:
                # Используем feature importance
                if hasattr(self.ml_model, 'feature_importances_'):
                    importances = dict(zip(self.feature_names, self.ml_model.feature_importances_))
                    top_features = sorted(importances.items(), key=lambda x: x[1], reverse=True)[:5]
                    reasons = [f"{name}: {imp:.2%}" for name, imp in top_features if imp > 0.01]
                else:
                    reasons = []
            
            if not reasons:
                reasons = [f"Вероятность мошенничества: {risk_score}%"]
            
            result = {
                'risk_level': risk_level,
                'risk_score': risk_score,
                'fraud_probability': float(fraud_proba),
                'fraud_prediction': bool(fraud_prediction),
                'is_fraud': bool(is_fraud),
                'threshold_used': float(threshold),
                'reasons': reasons,
                'amount': float(transaction_data.get('amount', 0)),
                'model_type': 'enhanced_ml',
                'feature_contributions': feature_contributions if feature_contributions else None
            }
            
            return result
            
        except Exception as e:
            print(f"Ошибка при предсказании: {e}")
            import traceback
            traceback.print_exc()
            return self.analyze_transaction(transaction_data)
    
    def analyze_transaction(self, transaction_data: Dict) -> Dict:
        """Базовый rule-based анализ (fallback)"""
        if not self.stats:
            return {
                'risk_level': 'unknown',
                'risk_score': 0,
                'reasons': ['Недостаточно данных']
            }
        
        risk_score = 0
        reasons = []
        amount = float(transaction_data.get('amount', 0))
        
        if amount <= 0:
            return {
                'risk_level': 'high',
                'risk_score': 100,
                'reasons': ['Некорректная сумма']
            }
        
        avg_amount = self.stats.get('avg_amount', 10000)
        if amount > avg_amount * 3:
            risk_score += 30
            reasons.append(f'Сумма {amount:,.0f} значительно превышает среднюю')
        
        if amount > 50000:
            risk_score += 20
            reasons.append('Крупная сумма транзакции')
        
        if risk_score >= 70:
            risk_level = 'high'
        elif risk_score >= 40:
            risk_level = 'medium'
        else:
            risk_level = 'low'
        
        return {
            'risk_level': risk_level,
            'risk_score': min(risk_score, 100),
            'reasons': reasons if reasons else ['Транзакция выглядит нормально'],
            'amount': amount
        }
    
    def check_data_drift(self, reference_data: Optional[pd.DataFrame] = None) -> Dict:
        """Проверка data drift"""
        if not EVIDENTLY_AVAILABLE:
            return {'available': False, 'message': 'Evidently не установлен'}
        
        if self.transactions_df is None or self.transactions_df.empty:
            return {'available': False, 'message': 'Нет данных'}
        
        try:
            # Используем последние 10% данных как текущие
            current_data = self.transactions_df.tail(int(len(self.transactions_df) * 0.1))
            reference_data = reference_data or self.transactions_df.head(int(len(self.transactions_df) * 0.9))
            
            # Подготовка признаков для drift detection
            current_features = []
            reference_features = []
            
            for idx, row in current_data.iterrows():
                try:
                    features = self.prepare_features_enhanced({
                        'amount': row.get('amount', 0),
                        'cst_dim_id': row.get('cst_dim_id'),
                        'direction': row.get('direction', ''),
                        'transdatetime': row.get('transdatetime')
                    }, include_history=False)
                    current_features.append(list(features.values()))
                except:
                    continue
            
            for idx, row in reference_data.iterrows():
                try:
                    features = self.prepare_features_enhanced({
                        'amount': row.get('amount', 0),
                        'cst_dim_id': row.get('cst_dim_id'),
                        'direction': row.get('direction', ''),
                        'transdatetime': row.get('transdatetime')
                    }, include_history=False)
                    reference_features.append(list(features.values()))
                except:
                    continue
            
            if not current_features or not reference_features:
                return {'available': False, 'message': 'Не удалось подготовить данные'}
            
            # Создание DataFrame для Evidently
            current_df = pd.DataFrame(current_features, columns=self.feature_names[:len(current_features[0])])
            reference_df = pd.DataFrame(reference_features, columns=self.feature_names[:len(reference_features[0])])
            
            # Метрика drift
            drift_metric = DataDriftMetric()
            report = Report(metrics=[drift_metric])
            report.run(reference_data=reference_df, current_data=current_df)
            
            drift_result = report.as_dict()
            
            # Сохранение отчета
            drift_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), DRIFT_REPORT_PATH)
            with open(drift_path, 'w') as f:
                json.dump(drift_result, f, indent=2, default=str)
            
            self.drift_metrics = drift_result
            
            return {
                'available': True,
                'drift_detected': drift_result.get('metrics', [{}])[0].get('result', {}).get('drift_detected', False),
                'drift_score': drift_result.get('metrics', [{}])[0].get('result', {}).get('drift_score', 0),
                'report': drift_result
            }
        except Exception as e:
            print(f"Ошибка проверки drift: {e}")
            return {'available': False, 'error': str(e)}
    
    def get_client_history(self, cst_dim_id: int) -> pd.DataFrame:
        """История транзакций клиента"""
        if self.transactions_df is None or self.transactions_df.empty:
            return pd.DataFrame()
        
        try:
            client_data = self.transactions_df[
                self.transactions_df['cst_dim_id'] == int(cst_dim_id)
            ].sort_values('transdatetime', ascending=False)
            
            return client_data.head(20)
        except:
            return pd.DataFrame()
    
    def get_suspicious_transactions(self, limit: int = 10) -> pd.DataFrame:
        """Подозрительные транзакции"""
        if self.transactions_df is None or self.transactions_df.empty:
            return pd.DataFrame()
        
        try:
            if 'target' in self.transactions_df.columns:
                fraud_transactions = self.transactions_df[
                    self.transactions_df['target'] == 1
                ].sort_values('transdatetime', ascending=False)
                
                return fraud_transactions.head(limit)
        except:
            pass
        
        return pd.DataFrame()

# Глобальный экземпляр
enhanced_antifraud_model = None

def get_enhanced_model():
    """Получить улучшенную модель"""
    global enhanced_antifraud_model
    if enhanced_antifraud_model is None:
        enhanced_antifraud_model = EnhancedAntiFraudModel()
    return enhanced_antifraud_model

