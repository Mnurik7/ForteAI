"""
AI-ассистент для ForteAI
Подстраивается под каждую страницу и предоставляет контекстную помощь
"""
import os
from typing import Dict, List, Optional
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

# Контексты для разных страниц
PAGE_CONTEXTS = {
    'index': {
        'name': 'Главная страница',
        'description': 'Главная страница ForteAI с выбором модулей',
        'modules': [
            {
                'name': 'SmartAntiFraud',
                'description': 'ML модель по выявлению мошеннических переводов в Мобильном интернет-Банкинге',
                'features': [
                    'Быстрый ML анализ транзакций',
                    'Глубокий AI анализ с Gemini',
                    'Пакетный анализ',
                    'История клиента',
                    'Статистика',
                    'Метрики модели',
                    'Управление порогами',
                    'MLOps',
                    'Мониторинг',
                    'Интерпретируемость (SHAP)'
                ]
            },
            {
                'name': 'AI-Procure',
                'description': 'AI-агент для закупок и тендерного анализа',
                'features': [
                    'Извлечение параметров тендера',
                    'Подбор поставщиков',
                    'Анализ рисков',
                    'Проверка аффилированности',
                    'Генерация отчётов',
                    'Поддержка новичков'
                ]
            },
            {
                'name': 'AI-Scrum Master',
                'description': 'Ассистент по управлению задач для сотрудников банка',
                'features': [
                    'Управление проектами',
                    'Создание задач из текста',
                    'Декомпозиция задач',
                    'Ассистент встреч',
                    'Контроль дедлайнов',
                    'Управление спринтами',
                    'Аналитика'
                ]
            },
            {
                'name': 'AI-Business Analyst',
                'description': 'AI-помощник по бизнес-аналитике',
                'features': [
                    'Анализ документов',
                    'Извлечение требований',
                    'Генерация BRD',
                    'Генерация Use Case',
                    'Генерация User Stories',
                    'Генерация страниц для Confluence'
                ]
            },
            {
                'name': 'AI-Code Review Assistant',
                'description': 'AI-агент для проведения ревью кода в GitLab',
                'features': [
                    'Загрузка архитектуры',
                    'Анализ кода',
                    'Анализ diff',
                    'Анализ проекта',
                    'Генерация отчётов',
                    'Интеграция с GitLab',
                    'Обучающая поддержка'
                ]
            }
        ]
    },
    'smartantifraud': {
        'name': 'SmartAntiFraud',
        'description': 'ML модель по выявлению мошеннических переводов',
        'features': [
            {
                'name': 'Быстрый анализ',
                'description': 'ML анализ транзакции на основе исторических данных',
                'how_to': 'Введите данные транзакции (сумма, ID клиента, получатель) и нажмите "Анализировать"'
            },
            {
                'name': 'Глубокий AI анализ',
                'description': 'Детальный анализ с использованием Gemini AI',
                'how_to': 'Введите описание транзакции или данные в текстовом формате'
            },
            {
                'name': 'Пакетный анализ',
                'description': 'Анализ множества транзакций',
                'how_to': 'Загрузите JSON файл с транзакциями или используйте фильтры'
            },
            {
                'name': 'Метрики модели',
                'description': 'Просмотр метрик ML-модели (ROC-AUC, Precision, Recall)',
                'how_to': 'Нажмите на карточку "Метрики модели" для просмотра'
            },
            {
                'name': 'Управление порогами',
                'description': 'Настройка порогов риска для разных сегментов',
                'how_to': 'Нажмите на карточку "Управление порогами" и измените значения'
            },
            {
                'name': 'MLOps',
                'description': 'Управление версиями моделей, retraining, rollback',
                'how_to': 'Нажмите на карточку "MLOps" для управления версиями'
            },
            {
                'name': 'Мониторинг',
                'description': 'Data drift, стабильность модели, алерты',
                'how_to': 'Нажмите на карточку "Мониторинг" для просмотра'
            },
            {
                'name': 'Интерпретируемость',
                'description': 'SHAP объяснения, важность признаков',
                'how_to': 'Нажмите на карточку "Интерпретируемость" и введите данные транзакции'
            }
        ],
        'tips': [
            'Используйте быстрый анализ для оперативной проверки транзакций',
            'Глубокий AI анализ даёт более детальное объяснение',
            'Пакетный анализ эффективен для обработки больших объёмов данных',
            'Регулярно проверяйте метрики модели для контроля качества',
            'Настройте пороги под ваши бизнес-требования',
            'Используйте мониторинг для отслеживания стабильности модели'
        ]
    },
    'ai_procure': {
        'name': 'AI-Procure',
        'description': 'AI-агент для закупок и тендерного анализа',
        'features': [
            {
                'name': 'Извлечение параметров тендера',
                'description': 'Автоматическое извлечение параметров из текста тендера',
                'how_to': 'Вставьте текст тендера и нажмите "Извлечь параметры"'
            },
            {
                'name': 'Подбор поставщиков',
                'description': 'Интеллектуальный подбор подходящих поставщиков',
                'how_to': 'Укажите параметры тендера и критерии подбора'
            },
            {
                'name': 'Анализ рисков',
                'description': 'Оценка рисков тендера и поставщиков',
                'how_to': 'Загрузите данные тендера для анализа рисков'
            },
            {
                'name': 'Проверка аффилированности',
                'description': 'Проверка связей между участниками',
                'how_to': 'Укажите список сущностей для проверки'
            },
            {
                'name': 'Генерация отчётов',
                'description': 'Создание комплексных отчётов по тендеру',
                'how_to': 'Используйте функцию генерации отчёта после анализа'
            }
        ],
        'tips': [
            'Используйте извлечение параметров для быстрой обработки тендеров',
            'Проверяйте аффилированность перед выбором поставщика',
            'Анализируйте риски для принятия обоснованных решений'
        ]
    },
    'ai_scrum': {
        'name': 'AI-Scrum Master',
        'description': 'Ассистент по управлению задач для сотрудников банка',
        'features': [
            {
                'name': 'Управление проектами',
                'description': 'Создание и управление проектами',
                'how_to': 'Нажмите "Создать проект" и заполните данные'
            },
            {
                'name': 'Создание задач из текста',
                'description': 'Автоматическое создание задач из описания',
                'how_to': 'Введите описание задачи и нажмите "Создать задачи"'
            },
            {
                'name': 'Декомпозиция задач',
                'description': 'Разбиение больших задач на подзадачи',
                'how_to': 'Выберите задачу и используйте функцию декомпозиции'
            },
            {
                'name': 'Ассистент встреч',
                'description': 'Анализ и обработка встреч',
                'how_to': 'Загрузите транскрипт встречи для анализа'
            },
            {
                'name': 'Контроль дедлайнов',
                'description': 'Отслеживание и напоминания о дедлайнах',
                'how_to': 'Добавьте дедлайн к задаче для автоматического контроля'
            }
        ],
        'tips': [
            'Используйте создание задач из текста для экономии времени',
            'Регулярно проверяйте дедлайны через ассистента',
            'Анализируйте встречи для извлечения задач'
        ]
    },
    'ai_business_analyst': {
        'name': 'AI-Business Analyst',
        'description': 'AI-помощник по бизнес-аналитике',
        'features': [
            {
                'name': 'Анализ документов',
                'description': 'Структурированный анализ бизнес-документов',
                'how_to': 'Загрузите документ или вставьте текст для анализа'
            },
            {
                'name': 'Извлечение требований',
                'description': 'Автоматическое извлечение требований из документов',
                'how_to': 'Используйте функцию извлечения требований после анализа'
            },
            {
                'name': 'Генерация BRD',
                'description': 'Создание Business Requirements Document',
                'how_to': 'После анализа документа используйте генерацию BRD'
            },
            {
                'name': 'Генерация Use Case',
                'description': 'Создание Use Case диаграмм и описаний',
                'how_to': 'Укажите требование для генерации Use Case'
            },
            {
                'name': 'Генерация User Stories',
                'description': 'Создание User Stories из требований',
                'how_to': 'Выберите требования и используйте генерацию User Stories'
            }
        ],
        'tips': [
            'Анализируйте документы перед извлечением требований',
            'Используйте генерацию BRD для структурирования требований',
            'User Stories помогают лучше понять потребности пользователей'
        ]
    },
    'ai_code_review': {
        'name': 'AI-Code Review Assistant',
        'description': 'AI-агент для проведения ревью кода в GitLab',
        'features': [
            {
                'name': 'Анализ кода',
                'description': 'Автоматический анализ кода на ошибки и улучшения',
                'how_to': 'Вставьте код или загрузите файл для анализа'
            },
            {
                'name': 'Анализ diff',
                'description': 'Анализ изменений в коде',
                'how_to': 'Вставьте diff для анализа изменений'
            },
            {
                'name': 'Анализ проекта',
                'description': 'Комплексный анализ всего проекта',
                'how_to': 'Загрузите несколько файлов для анализа проекта'
            },
            {
                'name': 'Генерация отчётов',
                'description': 'Создание отчётов по ревью кода',
                'how_to': 'После анализа используйте генерацию отчёта'
            },
            {
                'name': 'Интеграция с GitLab',
                'description': 'Работа с Merge Requests в GitLab',
                'how_to': 'Настройте интеграцию с GitLab для автоматического ревью'
            }
        ],
        'tips': [
            'Загружайте архитектуру проекта для лучшего анализа',
            'Используйте анализ diff для проверки изменений',
            'Интеграция с GitLab ускоряет процесс ревью'
        ]
    }
}

class AIAssistant:
    """AI-ассистент с контекстным пониманием"""
    
    def __init__(self):
        api_key = os.getenv('GEMINI_API_KEY')
        if not api_key:
            raise ValueError("GEMINI_API_KEY не найден")
        
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel(os.getenv('GEMINI_MODEL', 'gemini-2.5-flash'))
        self.conversation_history = {}  # История по пользователям
    
    def get_page_context(self, page_name: str) -> Dict:
        """Получить контекст страницы"""
        return PAGE_CONTEXTS.get(page_name, {
            'name': 'Неизвестная страница',
            'description': 'Страница не распознана'
        })
    
    def build_system_prompt(self, page_name: str, user_question: str = None) -> str:
        """Построить системный промпт с контекстом страницы"""
        context = self.get_page_context(page_name)
        
        prompt = f"""Ты AI-ассистент ForteAI - платформы искусственного интеллекта для банковской сферы.

ТЕКУЩАЯ СТРАНИЦА: {context['name']}
ОПИСАНИЕ: {context['description']}

"""
        
        # Добавляем информацию о функциях
        if 'features' in context:
            prompt += "ДОСТУПНЫЕ ФУНКЦИИ НА ЭТОЙ СТРАНИЦЕ:\n"
            if isinstance(context['features'], list) and len(context['features']) > 0:
                if isinstance(context['features'][0], dict):
                    # Детальная информация о функциях
                    for i, feature in enumerate(context['features'], 1):
                        prompt += f"{i}. {feature.get('name', 'Функция')}\n"
                        prompt += f"   Описание: {feature.get('description', '')}\n"
                        if 'how_to' in feature:
                            prompt += f"   Как использовать: {feature.get('how_to', '')}\n"
                else:
                    # Простой список
                    for i, feature in enumerate(context['features'], 1):
                        prompt += f"{i}. {feature}\n"
            prompt += "\n"
        
        # Добавляем советы
        if 'tips' in context:
            prompt += "ПОЛЕЗНЫЕ СОВЕТЫ:\n"
            for tip in context['tips']:
                prompt += f"- {tip}\n"
            prompt += "\n"
        
        # Добавляем информацию о модулях для главной страницы
        if page_name == 'index' and 'modules' in context:
            prompt += "ДОСТУПНЫЕ МОДУЛИ:\n"
            for module in context['modules']:
                prompt += f"- {module['name']}: {module['description']}\n"
                if 'features' in module:
                    prompt += "  Функции: " + ", ".join(module['features']) + "\n"
            prompt += "\n"
        
        prompt += """ТВОЯ РОЛЬ:
1. Помогать пользователям понять функции страницы
2. Отвечать на вопросы о работе системы
3. Быть путеводителем по интерфейсу
4. Объяснять сложные концепции простым языком
5. Предлагать оптимальные способы использования функций

СТИЛЬ ОБЩЕНИЯ:
- Дружелюбный и профессиональный
- Понятный язык без жаргона
- Конкретные примеры
- Структурированные ответы
- Эмодзи для визуального разделения

"""
        
        if user_question:
            prompt += f"ВОПРОС ПОЛЬЗОВАТЕЛЯ: {user_question}\n\n"
            prompt += "Ответь на вопрос, учитывая контекст страницы и доступные функции. Если вопрос не связан с текущей страницей, помоги пользователю найти нужную информацию."
        else:
            prompt += "Предоставь краткое введение в страницу и её функции."
        
        return prompt
    
    def get_greeting(self, page_name: str) -> str:
        """Получить приветственное сообщение для страницы"""
        context = self.get_page_context(page_name)
        
        greeting = f"👋 Привет! Я твой AI-ассистент на странице **{context['name']}**.\n\n"
        greeting += f"**{context['description']}**\n\n"
        
        if 'features' in context and context['features']:
            greeting += "Я могу помочь тебе:\n"
            if isinstance(context['features'][0], dict):
                for feature in context['features'][:5]:  # Первые 5 функций
                    greeting += f"• Понять функцию **{feature.get('name', '')}**\n"
            else:
                for feature in context['features'][:5]:
                    greeting += f"• Использовать **{feature}**\n"
            greeting += "\n"
        
        greeting += "💡 Задай мне любой вопрос о работе этой страницы или функций!"
        
        return greeting
    
    def ask(self, page_name: str, question: str, user_id: str = 'default', conversation_history: List = None) -> str:
        """Задать вопрос ассистенту"""
        try:
            # Строим промпт с контекстом
            system_prompt = self.build_system_prompt(page_name, question)
            
            # Добавляем историю разговора если есть
            full_prompt = system_prompt
            if conversation_history:
                full_prompt += "\n\nКОНТЕКСТ ПРЕДЫДУЩЕГО РАЗГОВОРА:\n"
                for msg in conversation_history[-5:]:  # Последние 5 сообщений
                    role = msg.get('role', 'user')
                    content = msg.get('content', '')
                    full_prompt += f"{'Пользователь' if role == 'user' else 'Ассистент'}: {content}\n"
                full_prompt += "\n"
            
            # Генерируем ответ
            response = self.model.generate_content(full_prompt)
            
            if hasattr(response, 'text'):
                return response.text
            else:
                return "Извините, не удалось получить ответ. Попробуйте переформулировать вопрос."
                
        except Exception as e:
            return f"Произошла ошибка: {str(e)}. Попробуйте позже."
    
    def get_feature_guide(self, page_name: str, feature_name: str = None) -> str:
        """Получить путеводитель по функции"""
        context = self.get_page_context(page_name)
        
        if not feature_name:
            # Общий путеводитель
            guide = f"# Путеводитель по {context['name']}\n\n"
            guide += f"{context['description']}\n\n"
            
            if 'features' in context:
                guide += "## Доступные функции:\n\n"
                for i, feature in enumerate(context['features'], 1):
                    if isinstance(feature, dict):
                        guide += f"### {i}. {feature.get('name', '')}\n"
                        guide += f"{feature.get('description', '')}\n\n"
                        if 'how_to' in feature:
                            guide += f"**Как использовать:** {feature.get('how_to')}\n\n"
                    else:
                        guide += f"{i}. {feature}\n\n"
            
            return guide
        else:
            # Путеводитель по конкретной функции
            if 'features' in context:
                for feature in context['features']:
                    if isinstance(feature, dict) and feature.get('name') == feature_name:
                        guide = f"# {feature.get('name', '')}\n\n"
                        guide += f"{feature.get('description', '')}\n\n"
                        if 'how_to' in feature:
                            guide += f"## Как использовать:\n\n{feature.get('how_to')}\n\n"
                        return guide
            
            return f"Функция '{feature_name}' не найдена на этой странице."

# Глобальный экземпляр
ai_assistant = None

def get_assistant():
    """Получить экземпляр ассистента"""
    global ai_assistant
    if ai_assistant is None:
        ai_assistant = AIAssistant()
    return ai_assistant

