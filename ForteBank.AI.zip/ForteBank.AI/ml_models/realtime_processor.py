"""
Real-time обработчик транзакций для SmartAntiFraud
Включает:
- Event-driven архитектуру
- Очереди для обработки
- Автоматические решения
- Масштабирование
"""
import asyncio
import time
from typing import Dict, List, Optional, Callable
from collections import deque
from datetime import datetime
import threading
import queue

class TransactionQueue:
    """Очередь для обработки транзакций"""
    
    def __init__(self, max_size=10000):
        self.queue = queue.Queue(maxsize=max_size)
        self.processed_count = 0
        self.blocked_count = 0
        self.allowed_count = 0
        self.start_time = time.time()
    
    def put(self, transaction: Dict):
        """Добавить транзакцию в очередь"""
        try:
            self.queue.put_nowait(transaction)
            return True
        except queue.Full:
            return False
    
    def get(self, timeout=None):
        """Получить транзакцию из очереди"""
        try:
            return self.queue.get(timeout=timeout)
        except queue.Empty:
            return None
    
    def size(self):
        """Размер очереди"""
        return self.queue.qsize()
    
    def stats(self):
        """Статистика очереди"""
        elapsed = time.time() - self.start_time
        return {
            'queue_size': self.size(),
            'processed': self.processed_count,
            'blocked': self.blocked_count,
            'allowed': self.allowed_count,
            'throughput_per_sec': self.processed_count / elapsed if elapsed > 0 else 0,
            'block_rate': self.blocked_count / self.processed_count if self.processed_count > 0 else 0
        }

class RealTimeProcessor:
    """Real-time процессор транзакций"""
    
    def __init__(self, model, max_workers=4):
        self.model = model
        self.queue = TransactionQueue()
        self.max_workers = max_workers
        self.workers = []
        self.running = False
        self.callbacks = {
            'on_fraud': [],
            'on_allow': [],
            'on_error': []
        }
    
    def register_callback(self, event: str, callback: Callable):
        """Регистрация callback для событий"""
        if event in self.callbacks:
            self.callbacks[event].append(callback)
    
    def _process_transaction(self, transaction: Dict) -> Dict:
        """Обработка одной транзакции"""
        try:
            start_time = time.time()
            
            # Быстрое предсказание
            result = self.model.predict_fraud_enhanced(transaction, return_shap=False)
            
            processing_time = (time.time() - start_time) * 1000  # в миллисекундах
            
            # Автоматическое решение
            is_fraud = result.get('is_fraud', False)
            auto_action = 'block' if is_fraud else 'allow'
            
            result['auto_action'] = auto_action
            result['processing_time_ms'] = processing_time
            
            # Вызов callbacks
            if is_fraud:
                for callback in self.callbacks['on_fraud']:
                    try:
                        callback(transaction, result)
                    except:
                        pass
            else:
                for callback in self.callbacks['on_allow']:
                    try:
                        callback(transaction, result)
                    except:
                        pass
            
            return result
            
        except Exception as e:
            for callback in self.callbacks['on_error']:
                try:
                    callback(transaction, str(e))
                except:
                    pass
            return {'error': str(e)}
    
    def _worker(self):
        """Worker thread для обработки транзакций"""
        while self.running:
            transaction = self.queue.get(timeout=1)
            if transaction:
                result = self._process_transaction(transaction)
                self.queue.processed_count += 1
                if result.get('auto_action') == 'block':
                    self.queue.blocked_count += 1
                else:
                    self.queue.allowed_count += 1
    
    def start(self):
        """Запуск процессора"""
        if self.running:
            return
        
        self.running = True
        self.workers = []
        
        for i in range(self.max_workers):
            worker = threading.Thread(target=self._worker, daemon=True)
            worker.start()
            self.workers.append(worker)
    
    def stop(self):
        """Остановка процессора"""
        self.running = False
        for worker in self.workers:
            worker.join(timeout=5)
    
    def process(self, transaction: Dict) -> Dict:
        """Синхронная обработка транзакции"""
        return self._process_transaction(transaction)
    
    def process_async(self, transaction: Dict) -> bool:
        """Асинхронная обработка (добавление в очередь)"""
        return self.queue.put(transaction)
    
    def get_stats(self) -> Dict:
        """Получить статистику"""
        return self.queue.stats()

class EventDrivenProcessor:
    """Event-driven процессор с подпиской на события"""
    
    def __init__(self, model):
        self.model = model
        self.subscribers = {
            'transaction_received': [],
            'fraud_detected': [],
            'transaction_allowed': [],
            'high_risk': []
        }
    
    def subscribe(self, event: str, handler: Callable):
        """Подписка на событие"""
        if event in self.subscribers:
            self.subscribers[event].append(handler)
    
    def _publish(self, event: str, data: Dict):
        """Публикация события"""
        if event in self.subscribers:
            for handler in self.subscribers[event]:
                try:
                    handler(data)
                except Exception as e:
                    print(f"Ошибка в handler для {event}: {e}")
    
    def process_transaction(self, transaction: Dict) -> Dict:
        """Обработка транзакции с событиями"""
        # Событие: транзакция получена
        self._publish('transaction_received', transaction)
        
        # Анализ
        result = self.model.predict_fraud_enhanced(transaction, return_shap=False)
        
        # События на основе результата
        if result.get('is_fraud', False):
            self._publish('fraud_detected', {
                'transaction': transaction,
                'result': result
            })
        elif result.get('risk_level') == 'high':
            self._publish('high_risk', {
                'transaction': transaction,
                'result': result
            })
        else:
            self._publish('transaction_allowed', {
                'transaction': transaction,
                'result': result
            })
        
        return result

# Глобальный экземпляр
realtime_processor = None
event_processor = None

def get_realtime_processor(model):
    """Получить real-time процессор"""
    global realtime_processor
    if realtime_processor is None:
        realtime_processor = RealTimeProcessor(model)
        realtime_processor.start()
    return realtime_processor

def get_event_processor(model):
    """Получить event-driven процессор"""
    global event_processor
    if event_processor is None:
        event_processor = EventDrivenProcessor(model)
    return event_processor

