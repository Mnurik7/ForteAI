"""
Модуль для интеграции с GitLab (управление статусами MR)
"""
import json
import os
from typing import Dict, List, Optional, Any
from datetime import datetime


class GitLabIntegration:
    """Интеграция с GitLab для управления MR"""
    
    def __init__(self):
        self.mr_statuses_file = 'data/code_review_mrs.json'
        self._ensure_data_file()
    
    def _ensure_data_file(self):
        """Создаёт файл для хранения статусов MR если его нет"""
        os.makedirs(os.path.dirname(self.mr_statuses_file), exist_ok=True)
        if not os.path.exists(self.mr_statuses_file):
            with open(self.mr_statuses_file, 'w', encoding='utf-8') as f:
                json.dump([], f, ensure_ascii=False, indent=2)
    
    def update_mr_status(self, mr_id: str, status: str, 
                        labels: Optional[List[str]] = None,
                        review_data: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Обновляет статус MR
        
        Args:
            mr_id: ID Merge Request
            status: Статус (ready-for-merge, needs-review, changes-requested)
            labels: Метки MR (опционально)
            review_data: Данные ревью (опционально)
        
        Returns:
            Результат обновления
        """
        valid_statuses = ['ready-for-merge', 'needs-review', 'changes-requested', 'reject']
        if status not in valid_statuses:
            return {'error': f'Недопустимый статус: {status}. Допустимые: {valid_statuses}'}
        
        try:
            # Загружаем существующие MR
            with open(self.mr_statuses_file, 'r', encoding='utf-8') as f:
                mrs = json.load(f)
            
            # Ищем существующий MR или создаём новый
            mr_found = False
            for mr in mrs:
                if mr.get('mr_id') == mr_id:
                    mr['status'] = status
                    mr['labels'] = labels or mr.get('labels', [])
                    mr['updated_at'] = datetime.now().isoformat()
                    if review_data:
                        mr['review_data'] = review_data
                    mr_found = True
                    break
            
            if not mr_found:
                new_mr = {
                    'mr_id': mr_id,
                    'status': status,
                    'labels': labels or [],
                    'created_at': datetime.now().isoformat(),
                    'updated_at': datetime.now().isoformat(),
                    'review_data': review_data or {}
                }
                mrs.append(new_mr)
            
            # Сохраняем
            with open(self.mr_statuses_file, 'w', encoding='utf-8') as f:
                json.dump(mrs, f, ensure_ascii=False, indent=2)
            
            return {
                'mr_id': mr_id,
                'status': status,
                'labels': labels or [],
                'success': True
            }
        except Exception as e:
            return {'error': f'Ошибка при обновлении статуса MR: {str(e)}'}
    
    def get_mr_status(self, mr_id: str) -> Dict[str, Any]:
        """
        Получает статус MR
        
        Args:
            mr_id: ID Merge Request
        
        Returns:
            Информация о MR
        """
        try:
            with open(self.mr_statuses_file, 'r', encoding='utf-8') as f:
                mrs = json.load(f)
            
            for mr in mrs:
                if mr.get('mr_id') == mr_id:
                    return mr
            
            return {'error': f'MR {mr_id} не найден'}
        except Exception as e:
            return {'error': f'Ошибка при получении статуса MR: {str(e)}'}
    
    def list_mrs(self, status_filter: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Получает список MR
        
        Args:
            status_filter: Фильтр по статусу (опционально)
        
        Returns:
            Список MR
        """
        try:
            with open(self.mr_statuses_file, 'r', encoding='utf-8') as f:
                mrs = json.load(f)
            
            if status_filter:
                mrs = [mr for mr in mrs if mr.get('status') == status_filter]
            
            return mrs
        except Exception as e:
            return [{'error': f'Ошибка при получении списка MR: {str(e)}'}]
    
    def add_labels(self, mr_id: str, labels: List[str]) -> Dict[str, Any]:
        """
        Добавляет метки к MR
        
        Args:
            mr_id: ID Merge Request
            labels: Список меток
        
        Returns:
            Результат добавления меток
        """
        try:
            with open(self.mr_statuses_file, 'r', encoding='utf-8') as f:
                mrs = json.load(f)
            
            for mr in mrs:
                if mr.get('mr_id') == mr_id:
                    existing_labels = mr.get('labels', [])
                    new_labels = list(set(existing_labels + labels))
                    mr['labels'] = new_labels
                    mr['updated_at'] = datetime.now().isoformat()
                    
                    with open(self.mr_statuses_file, 'w', encoding='utf-8') as f:
                        json.dump(mrs, f, ensure_ascii=False, indent=2)
                    
                    return {
                        'mr_id': mr_id,
                        'labels': new_labels,
                        'success': True
                    }
            
            return {'error': f'MR {mr_id} не найден'}
        except Exception as e:
            return {'error': f'Ошибка при добавлении меток: {str(e)}'}

