"""
Модули AI-Code Review Assistant
"""
from code_review_models.architecture_loader import ArchitectureLoader
from code_review_models.code_analyzer import CodeAnalyzer
from code_review_models.review_generator import ReviewGenerator
from code_review_models.report_generator import ReportGenerator
from code_review_models.gitlab_integration import GitLabIntegration
from code_review_models.educational_support import EducationalSupport
from code_review_models.language_detector import LanguageDetector

__all__ = [
    'ArchitectureLoader',
    'CodeAnalyzer',
    'ReviewGenerator',
    'ReportGenerator',
    'GitLabIntegration',
    'EducationalSupport',
    'LanguageDetector'
]

