"""
Модуль для генерации рекомендаций по ревью кода
"""
from typing import Dict, List, Optional, Any


class ReviewGenerator:
    """Генератор рекомендаций по ревью кода"""
    
    def __init__(self, model):
        self.model = model
    
    def generate_recommendations(self, analysis: Dict[str, Any], 
                                review_scope: str = 'file') -> Dict[str, Any]:
        """
        Генерирует рекомендации на основе анализа
        
        Args:
            analysis: Результат анализа кода
            review_scope: Область ревью ('file' или 'project')
        
        Returns:
            Словарь с рекомендациями
        """
        if analysis.get('error'):
            return analysis
        
        analysis_text = analysis.get('analysis', '')
        
        prompt = f"""Краткие рекомендации с улучшенным кодом.

Область: {review_scope}

Анализ:
{analysis_text[:5000]}

Формат:

**КРИТИЧНО:**
- [Строка] [Проблема: кратко]
  ```python
  # Исправленный код
  ```

**ВАЖНО:**
- [Строка] [Проблема: кратко]
  ```python
  # Исправленный код
  ```

**УЛУЧШЕНИЯ:**
- [Строка] [Рекомендация: кратко]
  ```python
  # Улучшенный код
  ```

Для каждого пункта: краткое описание (1 предложение) + исправленный код."""
        
        try:
            response = self.model.generate_content(prompt)
            recommendations_text = response.text if hasattr(response, 'text') else str(response)
            
            return {
                'recommendations': recommendations_text,
                'review_scope': review_scope,
                'success': True
            }
        except Exception as e:
            return {
                'error': f'Ошибка при генерации рекомендаций: {str(e)}',
                'review_scope': review_scope
            }
    
    def generate_educational_hints(self, issue: str, developer_level: str = 'junior') -> Dict[str, Any]:
        """
        Генерирует обучающие подсказки для разработчиков
        
        Args:
            issue: Проблема в коде
            developer_level: Уровень разработчика (junior/middle/senior)
        
        Returns:
            Обучающие подсказки
        """
        prompt = f"""Ты ментор для разработчиков. Объясни следующую проблему в коде для разработчика уровня {developer_level}.

Проблема:
{issue}

Предоставь объяснение в следующем формате:

1. ЧТО НЕ ТАК:
   - [Простое объяснение проблемы]

2. ПОЧЕМУ ЭТО ПРОБЛЕМА:
   - [Объяснение последствий]
   - [Примеры когда это может вызвать проблемы]

3. КАК ИСПРАВИТЬ:
   - [Пошаговое объяснение]
   - [Пример правильного кода]

4. BEST PRACTICES:
   - [Рекомендации как избежать в будущем]
   - [Полезные ресурсы для изучения]

5. ПРОВЕРЬ СЕБЯ:
   - [Вопросы для самопроверки]

Будь дружелюбным и понятным. Используй простой язык для junior разработчиков."""
        
        try:
            response = self.model.generate_content(prompt)
            hints_text = response.text if hasattr(response, 'text') else str(response)
            
            return {
                'hints': hints_text,
                'developer_level': developer_level,
                'success': True
            }
        except Exception as e:
            return {
                'error': f'Ошибка при генерации подсказок: {str(e)}',
                'developer_level': developer_level
            }

