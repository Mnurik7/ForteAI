"""
Модуль для анализа кода и diff
"""
import re
import json
from typing import Dict, List, Optional, Any
import difflib


class CodeAnalyzer:
    """Анализатор кода и изменений"""
    
    def __init__(self, model):
        self.model = model
    
    def analyze_code(self, code: str, language: str, file_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Анализирует код на соответствие стандартам
        
        Args:
            code: Исходный код
            language: Язык программирования
            file_path: Путь к файлу (опционально)
        
        Returns:
            Результат анализа кода
        """
        prompt = f"""Проведи краткое ревью кода на {language}. Для каждой проблемы сразу давай улучшенный код.

{'Файл: ' + file_path if file_path else ''}

Код:
```{language}
{code}
```

Формат ответа:

**КРИТИЧНО:**
- [Строка X] Проблема: [краткое описание]
  ```{language}
  // Исправленный код
  ```

**ВАЖНО:**
- [Строка Y] Проблема: [краткое описание]
  ```{language}
  // Исправленный код
  ```

**УЛУЧШЕНИЯ:**
- [Строка Z] Рекомендация: [краткое описание]
  ```{language}
  // Улучшенный код
  ```

**БЕЗОПАСНОСТЬ:**
- [Строка N] Уязвимость: [тип]
  ```{language}
  // Безопасный код
  ```

**ПРОИЗВОДИТЕЛЬНОСТЬ:**
- [Строка M] Проблема: [краткое описание]
  ```{language}
  // Оптимизированный код
  ```

Для каждой проблемы: краткое описание (1 предложение) + исправленный код. Без лишних слов."""
        
        try:
            response = self.model.generate_content(prompt)
            analysis_text = response.text if hasattr(response, 'text') else str(response)
            
            # Извлекаем проблемы
            issues = self._extract_issues(analysis_text)
            
            return {
                'analysis': analysis_text,
                'issues': issues,
                'file_path': file_path,
                'language': language,
                'success': True
            }
        except Exception as e:
            return {
                'error': f'Ошибка при анализе кода: {str(e)}',
                'file_path': file_path,
                'language': language
            }
    
    def analyze_diff(self, diff_text: str, base_code: Optional[str] = None, 
                     new_code: Optional[str] = None) -> Dict[str, Any]:
        """
        Анализирует diff изменений
        
        Args:
            diff_text: Текст diff
            base_code: Исходный код (опционально)
            new_code: Новый код (опционально)
        
        Returns:
            Результат анализа diff
        """
        prompt = f"""Краткий анализ diff. Для каждой проблемы давай улучшенный код.

Diff:
```
{diff_text}
```

{f'Исходный:\n```\n{base_code}\n```' if base_code else ''}
{f'Новый:\n```\n{new_code}\n```' if new_code else ''}

Формат:

**КРИТИЧНО:**
- [Строка] Проблема: [кратко]
  ```python
  # Исправленный код
  ```

**ВАЖНО:**
- [Строка] Проблема: [кратко]
  ```python
  # Исправленный код
  ```

**РЕКОМЕНДАЦИИ:**
- [Строка] Улучшение: [кратко]
  ```python
  # Улучшенный код
  ```

**СТАТУС:** ready-for-merge / needs-fixes / reject

Для каждой проблемы: описание + исправленный код."""
        
        try:
            response = self.model.generate_content(prompt)
            analysis_text = response.text if hasattr(response, 'text') else str(response)
            
            # Извлекаем рекомендацию по merge
            merge_recommendation = self._extract_merge_recommendation(analysis_text)
            
            return {
                'analysis': analysis_text,
                'merge_recommendation': merge_recommendation,
                'success': True
            }
        except Exception as e:
            return {
                'error': f'Ошибка при анализе diff: {str(e)}'
            }
    
    def analyze_project(self, files: List[Dict[str, str]], architecture: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Анализирует весь проект
        
        Args:
            files: Список файлов с кодом [{'path': '...', 'code': '...', 'language': '...'}]
            architecture: Информация об архитектуре (опционально)
        
        Returns:
            Результат анализа проекта
        """
        files_summary = []
        for file_info in files[:20]:  # Ограничиваем количество файлов
            files_summary.append({
                'path': file_info.get('path', 'unknown'),
                'language': file_info.get('language', 'unknown'),
                'size': len(file_info.get('code', ''))
            })
        
        architecture_info = ""
        if architecture:
            architecture_info = f"\n\nИнформация об архитектуре:\n{architecture.get('analysis', '')[:2000]}"
        
        prompt = f"""Краткий анализ проекта. Для каждой проблемы давай улучшенный код.

Файлы ({len(files)}):
{json.dumps(files_summary, ensure_ascii=False, indent=2)}{architecture_info}

Формат:

**АРХИТЕКТУРА:**
- Проблема: [кратко]
  ```python
  # Исправление
  ```

**ФАЙЛЫ:**
- [Файл:Строка] Проблема: [кратко]
  ```python
  # Исправленный код
  ```

**ОБЩИЕ ПРОБЛЕМЫ:**
- [Проблема]: [кратко]
  ```python
  # Решение
  ```

**ПРИОРИТЕТЫ:**
1. [Критично] → [код исправления]
2. [Важно] → [код исправления]
3. [Улучшить] → [код улучшения]

Для каждой проблемы: краткое описание + исправленный код."""
        
        try:
            response = self.model.generate_content(prompt)
            analysis_text = response.text if hasattr(response, 'text') else str(response)
            
            return {
                'analysis': analysis_text,
                'files_analyzed': len(files),
                'success': True
            }
        except Exception as e:
            return {
                'error': f'Ошибка при анализе проекта: {str(e)}',
                'files_analyzed': len(files)
            }
    
    def _extract_issues(self, analysis_text: str) -> List[Dict[str, Any]]:
        """Извлекает конкретные проблемы из анализа"""
        issues = []
        # Простой парсинг для извлечения проблем
        lines = analysis_text.split('\n')
        current_issue = None
        
        for line in lines:
            if re.match(r'^\d+\.', line) or ':' in line:
                if current_issue:
                    issues.append(current_issue)
                current_issue = {'title': line.strip(), 'details': []}
            elif current_issue and line.strip():
                current_issue['details'].append(line.strip())
        
        if current_issue:
            issues.append(current_issue)
        
        return issues[:10]  # Ограничиваем количество
    
    def _extract_merge_recommendation(self, analysis_text: str) -> str:
        """Извлекает рекомендацию по merge из анализа"""
        text_lower = analysis_text.lower()
        
        if 'reject' in text_lower or 'отклонить' in text_lower:
            return 'reject'
        elif 'needs-fixes' in text_lower or 'требует исправлений' in text_lower or 'нужны исправления' in text_lower:
            return 'needs-fixes'
        elif 'ready' in text_lower or 'готов' in text_lower or 'merge' in text_lower:
            return 'ready-for-merge'
        else:
            return 'needs-review'

