from flask import Flask, render_template, request, jsonify, session, redirect, url_for, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
from dotenv import load_dotenv
import google.generativeai as genai
import json
from datetime import datetime
from ml_models.antifraud_model import get_model
from ml_models.antifraud_model_enhanced import get_enhanced_model
from ml_models.mlops_pipeline import get_mlops_pipeline, get_auto_retrainer
from ml_models.realtime_processor import get_realtime_processor, get_event_processor
from ml_models.ai_assistant import get_assistant
import pandas as pd

# Импорт модулей AI-Procure
from procure_models.tender_analyzer import TenderAnalyzer
from procure_models.supplier_matcher import SupplierMatcher
from procure_models.risk_analyzer import RiskAnalyzer
from procure_models.report_generator import ReportGenerator
from procure_models.beginner_support import BeginnerSupport

# Импорт модулей AI-Scrum Master
from scrum_models.project_manager import ProjectManager
from scrum_models.task_creator import TaskCreator
from scrum_models.task_decomposer import TaskDecomposer
from scrum_models.meeting_assistant import MeetingAssistant
from scrum_models.deadline_tracker import DeadlineTracker
from scrum_models.sprint_manager import SprintManager
from scrum_models.analytics_engine import AnalyticsEngine
from scrum_models.integration_manager import IntegrationManager

# Импорт модулей AI-Business Analyst
from business_analyst_models.document_analyzer import DocumentAnalyzer
from business_analyst_models.requirement_extractor import RequirementExtractor
from business_analyst_models.document_generator import DocumentGenerator

# Импорт модулей AI-Code Review Assistant
from code_review_models.architecture_loader import ArchitectureLoader
from code_review_models.code_analyzer import CodeAnalyzer
from code_review_models.review_generator import ReviewGenerator
from code_review_models.report_generator import ReportGenerator as CodeReviewReportGenerator
from code_review_models.gitlab_integration import GitLabIntegration
from code_review_models.educational_support import EducationalSupport
from code_review_models.language_detector import LanguageDetector

load_dotenv()

app = Flask(__name__)
# Используем постоянный secret_key для сохранения сессий между перезапусками
# В продакшене это должно быть в переменных окружения
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'fortebank-ai-innovation-lab-secret-key-2025')
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['PERMANENT_SESSION_LIFETIME'] = 86400  # 24 часа

# Настройка Gemini API
api_key = os.getenv('GEMINI_API_KEY')
if not api_key:
    raise ValueError("GEMINI_API_KEY не найден в переменных окружения. Создайте файл .env с вашим API ключом.")

genai.configure(api_key=api_key)
model = genai.GenerativeModel(os.getenv('GEMINI_MODEL', 'gemini-2.5-flash'))

# Инициализация модулей AI-Procure
tender_analyzer = TenderAnalyzer(model)
supplier_matcher = SupplierMatcher(model)
risk_analyzer = RiskAnalyzer(model)
report_generator = ReportGenerator(model)
beginner_support = BeginnerSupport()

# Инициализация модулей AI-Scrum Master
project_manager = ProjectManager(model)
task_creator = TaskCreator(model)
task_decomposer = TaskDecomposer(model)
meeting_assistant = MeetingAssistant(model)
deadline_tracker = DeadlineTracker()
sprint_manager = SprintManager(model)
analytics_engine = AnalyticsEngine(model)
integration_manager = IntegrationManager()

# Инициализация модулей AI-Business Analyst
document_analyzer = DocumentAnalyzer(model)
requirement_extractor = RequirementExtractor(model)
document_generator = DocumentGenerator(model)

# Инициализация модулей AI-Code Review Assistant
language_detector = LanguageDetector()
architecture_loader = ArchitectureLoader(model)
code_analyzer = CodeAnalyzer(model)
review_generator = ReviewGenerator(model)
code_review_report_generator = CodeReviewReportGenerator(model)
gitlab_integration = GitLabIntegration()
educational_support = EducationalSupport(model)

# JSON база данных пользователей
DB_FILE = 'data/users.json'

def load_users():
    """Загрузить пользователей из JSON файла"""
    if not os.path.exists(DB_FILE):
        # Создать директорию если не существует
        os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
        # Инициализировать базу с тестовыми пользователями
        initial_users = [
            {
                "username": "admin",
                "password_hash": generate_password_hash('admin123'),
                "role": "admin",
                "created_at": "2024-01-01T00:00:00"
            },
            {
                "username": "user",
                "password_hash": generate_password_hash('user123'),
                "role": "user",
                "created_at": "2024-01-01T00:00:00"
            }
        ]
        save_users(initial_users)
        return initial_users
    
    try:
        with open(DB_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        return []

def save_users(users_data):
    """Сохранить пользователей в JSON файл"""
    os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
    with open(DB_FILE, 'w', encoding='utf-8') as f:
        json.dump(users_data, f, ensure_ascii=False, indent=2)

def get_user_by_username(username):
    """Получить пользователя по имени"""
    users = load_users()
    for user in users:
        if user.get('username') == username:
            return user
    return None

def verify_password(username, password):
    """Проверить пароль пользователя"""
    user = get_user_by_username(username)
    if not user:
        return False
    return check_password_hash(user.get('password_hash'), password)

@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('index.html', username=session.get('username'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if verify_password(username, password):
            user = get_user_by_username(username)
            session.permanent = True  # Делаем сессию постоянной
            session['username'] = username
            session['role'] = user.get('role', 'user')
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error='Неверное имя пользователя или пароль')
    
    if 'username' in session:
        return redirect(url_for('index'))
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/smartantifraud')
def smartantifraud():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('smartantifraud.html', username=session.get('username'))

@app.route('/ai-procure')
def ai_procure():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('ai_procure.html', username=session.get('username'))

@app.route('/ai-scrum')
def ai_scrum():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('ai_scrum.html', username=session.get('username'))

@app.route('/ai-business-analyst')
def ai_business_analyst():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('ai_business_analyst.html', username=session.get('username'))

@app.route('/confluence-docs')
def confluence_docs():
    """Страница для просмотра сохраненных документов Confluence"""
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('confluence_docs.html', username=session.get('username'))

@app.route('/ai-code-review')
def ai_code_review():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('ai_code_review.html', username=session.get('username'))

# API endpoints для SmartAntiFraud

# Быстрый ML анализ транзакции (улучшенная модель)
@app.route('/api/smartantifraud/quick', methods=['POST'])
def api_smartantifraud_quick():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        data = request.json
        return_shap = data.get('return_shap', False)
        
        result = enhanced_model.predict_fraud_enhanced(data, return_shap=return_shap)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Глубокий AI анализ с Gemini
@app.route('/api/smartantifraud/deep', methods=['POST'])
def api_smartantifraud_deep():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.json
    transaction_data = data.get('transaction_data', '')
    
    # Сначала быстрый ML анализ
    ml_result = None
    try:
        antifraud = get_model()
        # Извлекаем данные для быстрого анализа
        ml_analysis = {}
        if 'amount' in transaction_data.lower() or 'сумма' in transaction_data.lower():
            ml_analysis['amount'] = 0  # Будет определено AI
        ml_result = antifraud.analyze_transaction(ml_analysis) if ml_analysis else None
    except:
        pass
    
    prompt = f"""Ты эксперт по выявлению мошенничества в банковских транзакциях. Проанализируй следующие данные транзакции на предмет мошенничества.

Данные транзакции:
{transaction_data}

{'Результат быстрого ML анализа: ' + json.dumps(ml_result, ensure_ascii=False) if ml_result else ''}

Проведи глубокий анализ и предоставь детальный отчет в следующем формате:

1. ОБЩАЯ ОЦЕНКА:
   - Уровень риска: [Низкий/Средний/Высокий]
   - Вероятность мошенничества: [X%]

2. ПРИЗНАКИ МОШЕННИЧЕСТВА:
   - [Список найденных признаков]

3. ПОВЕДЕНЧЕСКИЙ АНАЛИЗ:
   - [Анализ поведенческих паттернов]

4. КОНТЕКСТ И СВЯЗИ:
   - [Анализ связей и контекста]

5. РЕКОМЕНДАЦИИ:
   - [Конкретные рекомендации по действию]

6. ДОПОЛНИТЕЛЬНЫЕ ЗАМЕЧАНИЯ:
   - [Любые дополнительные наблюдения]"""
    
    try:
        response = model.generate_content(prompt)
        if hasattr(response, 'text'):
            return jsonify({'result': response.text})
        else:
            return jsonify({'error': 'Получен неожиданный формат ответа от API'}), 500
    except Exception as e:
        error_message = str(e)
        if 'API key' in error_message or 'authentication' in error_message.lower():
            return jsonify({'error': 'Ошибка аутентификации с Gemini API. Проверьте ваш API ключ.'}), 500
        return jsonify({'error': f'Ошибка при обработке запроса: {error_message}'}), 500

# Пакетный анализ транзакций (улучшенная версия)
@app.route('/api/smartantifraud/batch', methods=['POST'])
def api_smartantifraud_batch():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        data = request.json
        transactions = data.get('transactions', [])
        use_enhanced = data.get('use_enhanced', True)  # По умолчанию используем улучшенную модель
        
        results = []
        summary = {'high': 0, 'medium': 0, 'low': 0, 'fraud_detected': 0}
        
        for transaction in transactions:
            if use_enhanced:
                result = enhanced_model.predict_fraud_enhanced(transaction, return_shap=False)
            else:
                result = enhanced_model.analyze_transaction(transaction)
            results.append(result)
            summary[result['risk_level']] += 1
            if result.get('is_fraud', False):
                summary['fraud_detected'] += 1
        
        return jsonify({
            'results': results,
            'summary': summary,
            'total': len(transactions),
            'fraud_rate': summary['fraud_detected'] / len(transactions) if transactions else 0
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# История транзакций клиента
@app.route('/api/smartantifraud/client-history/<int:client_id>')
def api_smartantifraud_client_history(client_id):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        antifraud = get_model()
        history_df = antifraud.get_client_history(client_id)
        
        if history_df.empty:
            return jsonify({'history': [], 'message': 'История не найдена'})
        
        # Конвертируем в список словарей
        history = history_df.to_dict('records')
        
        # Конвертируем даты в строки
        for record in history:
            for key, value in record.items():
                if hasattr(value, 'isoformat'):
                    record[key] = value.isoformat()
                elif pd.isna(value):
                    record[key] = None
        
        return jsonify({
            'history': history,
            'total': len(history)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Получить случайные транзакции для анализа
@app.route('/api/smartantifraud/random-transactions', methods=['POST'])
def api_smartantifraud_random_transactions():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        antifraud = get_model()
        data = request.json
        limit = data.get('limit', 50)
        
        if antifraud.transactions_df is None or antifraud.transactions_df.empty:
            return jsonify({'error': 'Данные не загружены'}), 500
        
        # Берем случайные транзакции
        random_transactions = antifraud.transactions_df.sample(n=min(limit, len(antifraud.transactions_df)), random_state=42)
        
        # Конвертируем в список словарей
        transactions = random_transactions.to_dict('records')
        
        # Конвертируем даты в строки
        for record in transactions:
            for key, value in record.items():
                if hasattr(value, 'isoformat'):
                    record[key] = value.isoformat()
                elif pd.isna(value):
                    record[key] = None
        
        return jsonify({
            'transactions': transactions,
            'total': len(transactions)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Статистика по транзакциям (улучшенная)
@app.route('/api/smartantifraud/statistics')
def api_smartantifraud_statistics():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        stats = enhanced_model.stats
        
        if enhanced_model.transactions_df is not None and not enhanced_model.transactions_df.empty:
            df = enhanced_model.transactions_df
            
            # Добавляем метрики модели
            model_metrics = enhanced_model.model_metrics
            
            return jsonify({
                'total_transactions': len(df),
                'fraud_rate': float(df['target'].mean()) if 'target' in df.columns else 0,
                'fraud_count': int(df['target'].sum()) if 'target' in df.columns else 0,
                'avg_amount': float(df['amount'].mean()) if 'amount' in df.columns else 0,
                'median_amount': float(df['amount'].median()) if 'amount' in df.columns else 0,
                'max_amount': float(df['amount'].max()) if 'amount' in df.columns else 0,
                'min_amount': float(df['amount'].min()) if 'amount' in df.columns else 0,
                'unique_clients': int(df['cst_dim_id'].nunique()) if 'cst_dim_id' in df.columns else 0,
                'unique_destinations': int(df['direction'].nunique()) if 'direction' in df.columns else 0,
                'model_metrics': model_metrics,
                'model_type': enhanced_model.model_type,
                'feature_count': len(enhanced_model.feature_names)
            })
        else:
            return jsonify({
                'total_transactions': 0,
                'fraud_rate': 0,
                'fraud_count': 0,
                'message': 'Данные не загружены'
            })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Подозрительные транзакции
@app.route('/api/smartantifraud/suspicious')
def api_smartantifraud_suspicious():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        antifraud = get_model()
        limit = request.args.get('limit', 10, type=int)
        
        suspicious_df = antifraud.get_suspicious_transactions(limit)
        
        if suspicious_df.empty:
            return jsonify({'transactions': [], 'message': 'Подозрительные транзакции не найдены'})
        
        transactions = suspicious_df.to_dict('records')
        
        # Конвертируем даты в строки
        for record in transactions:
            for key, value in record.items():
                if hasattr(value, 'isoformat'):
                    record[key] = value.isoformat()
                elif pd.isna(value):
                    record[key] = None
        
        return jsonify({
            'transactions': transactions,
            'total': len(transactions)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Анализ перевода с использованием улучшенной ML-модели
@app.route('/api/smartantifraud/transfer-analyze', methods=['POST'])
def api_smartantifraud_transfer_analyze():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        transaction_data = request.json
        return_shap = transaction_data.get('return_shap', False)
        
        # Используем улучшенную ML-модель
        result = enhanced_model.predict_fraud_enhanced(transaction_data, return_shap=return_shap)
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Анализ переводов из JSON файла
@app.route('/api/smartantifraud/transfer-json-analysis', methods=['POST'])
def api_smartantifraud_transfer_json_analysis():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        
        # Поддерживаем разные форматы JSON
        if isinstance(data, list):
            transactions_data = data
        elif isinstance(data, dict) and 'transactions' in data:
            transactions_data = data['transactions']
        else:
            return jsonify({'error': 'Неверный формат JSON. Ожидается массив транзакций или объект с полем "transactions"'}), 400
        
        if not transactions_data:
            return jsonify({'error': 'JSON файл не содержит транзакций'}), 400
        
        # Импортируем функции классификации из transfer_antifraud_console
        import sys
        import os
        sys.path.append(os.path.dirname(os.path.abspath(__file__)))
        
        from transfer_antifraud_console import (
            Transaction, UserHistory, classify_transaction, YELLOW_THRESHOLD,
            check_triggers, RED_TRIGGERS, YELLOW_TRIGGERS
        )
        
        # Хранение истории пользователей
        users_history = {}
        
        # Список всех обработанных транзакций
        all_transactions = []
        
        # Статистика
        risk_counts = {"RED": 0, "YELLOW": 0, "GREEN": 0}
        blocked_users = set()
        suspicious_users = []
        
        # Обрабатываем каждую транзакцию
        for trans_data in transactions_data:
            try:
                # Создаём объект транзакции
                transaction = Transaction(
                    sender_id=str(trans_data.get('sender_id', '')),
                    receiver_id=str(trans_data.get('receiver_id', '')),
                    amount=float(trans_data.get('amount', 0)),
                    currency=trans_data.get('currency', 'KZT'),
                    comment=trans_data.get('comment', '')
                )
                
                # Классифицируем транзакцию
                risk_level, reason, actions = classify_transaction(transaction, users_history)
                
                # Сохраняем результаты
                transaction.risk_level = risk_level
                transaction.reason = reason
                transaction.actions = actions
                
                # Обновляем статистику
                risk_counts[risk_level] += 1
                
                # Проверяем блокировку
                sender_id = transaction.sender_id
                if sender_id in users_history and users_history[sender_id].is_blocked:
                    blocked_users.add(sender_id)
                
                # Добавляем в историю
                if sender_id not in users_history:
                    users_history[sender_id] = UserHistory()
                users_history[sender_id].transactions.append(transaction.id)
                
                all_transactions.append(transaction)
            
            except Exception as e:
                continue
        
        # Формируем список подозрительных пользователей
        for user_id, hist in users_history.items():
            if hist.count_yellow > 0:
                suspicious_users.append({
                    'user_id': user_id,
                    'yellow_count': hist.count_yellow,
                    'total_count': len(hist.transactions),
                    'is_blocked': hist.is_blocked
                })
        
        suspicious_users.sort(key=lambda x: x['yellow_count'], reverse=True)
        
        return jsonify({
            'statistics': {
                'total_transactions': len(all_transactions),
                'risk_counts': risk_counts,
                'blocked_users_count': len(blocked_users)
            },
            'blocked_users': list(blocked_users),
            'suspicious_users': suspicious_users[:20],  # Топ 20
            'users_history': {
                sender_id: {
                    'count_yellow': hist.count_yellow,
                    'is_blocked': hist.is_blocked,
                    'total_transactions': len(hist.transactions)
                }
                for sender_id, hist in users_history.items()
            },
            'transactions': [
                {
                    'id': trans.id,
                    'sender_id': trans.sender_id,
                    'receiver_id': trans.receiver_id,
                    'amount': trans.amount,
                    'currency': trans.currency,
                    'comment': trans.comment,
                    'risk_level': trans.risk_level,
                    'reason': trans.reason,
                    'actions': trans.actions
                }
                for trans in all_transactions
            ]
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# AI анализ перевода с использованием Gemini 2.5 Flash
@app.route('/api/smartantifraud/transfer-ai-analysis', methods=['POST'])
def api_smartantifraud_transfer_ai_analysis():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        antifraud = get_model()
        data = request.json
        
        # Если данные содержат описание, используем его
        description = data.get('description', '')
        
        # Если это JSON с данными перевода, сначала анализируем через ML
        ml_result = None
        if 'amount' in data or 'cst_dim_id' in data:
            ml_result = antifraud.predict_fraud(data)
        
        # Формируем prompt для Gemini
        prompt = f"""Ты эксперт по анализу мошеннических переводов в банковской сфере.

Задача: Проанализируй перевод на предмет возможного мошенничества.

Данные перевода:
"""
        
        if ml_result:
            prompt += f"""
Результат ML-модели:
- Уровень риска: {ml_result.get('risk_level', 'unknown')}
- Вероятность мошенничества: {ml_result.get('fraud_probability', 0) * 100:.2f}%
- Оценка риска: {ml_result.get('risk_score', 0)}/100
- Причины: {', '.join(ml_result.get('reasons', []))}

Данные транзакции:
"""
        
        for key, value in data.items():
            if key != 'description':
                prompt += f"- {key}: {value}\n"
        
        if description:
            prompt += f"\nОписание: {description}\n"
        
        prompt += """
Проведи детальный анализ и предоставь:
1. ОБЩАЯ ОЦЕНКА: Общая оценка риска мошенничества
2. ПРИЗНАКИ МОШЕННИЧЕСТВА: Какие признаки указывают на возможное мошенничество
3. ПОВЕДЕНЧЕСКИЙ АНАЛИЗ: Анализ поведения клиента и получателя
4. КОНТЕКСТ И СВЯЗИ: Анализ связей с другими транзакциями
5. РЕКОМЕНДАЦИИ: Конкретные рекомендации (блокировать/разрешить/требуется проверка)
6. ДОПОЛНИТЕЛЬНЫЕ ЗАМЕЧАНИЯ: Дополнительные наблюдения

Будь конкретным и структурированным в ответе. Используй формат с четкими заголовками."""

        # Используем Gemini 2.5 Flash
        model_name = os.getenv('GEMINI_MODEL', 'gemini-2.5-flash')
        model = genai.GenerativeModel(model_name)
        response = model.generate_content(prompt)
        
        if hasattr(response, 'text'):
            result = {
                'result': response.text,
                'ml_analysis': ml_result
            }
            return jsonify(result)
        else:
            return jsonify({'error': 'Получен неожиданный формат ответа от API'}), 500
            
    except Exception as e:
        error_message = str(e)
        if 'API key' in error_message or 'authentication' in error_message.lower():
            return jsonify({'error': 'Ошибка аутентификации с Gemini API. Проверьте ваш API ключ.'}), 500
        return jsonify({'error': f'Ошибка при обработке запроса: {error_message}'}), 500

# Старый endpoint для обратной совместимости
@app.route('/api/smartantifraud', methods=['POST'])
def api_smartantifraud():
    """Старый endpoint, теперь перенаправляет на глубокий анализ"""
    return api_smartantifraud_deep()

# === НОВЫЕ ENDPOINTS ДЛЯ УЛУЧШЕННОЙ МОДЕЛИ ===

# Мониторинг data drift
@app.route('/api/smartantifraud/monitoring/drift', methods=['GET', 'POST'])
def api_smartantifraud_drift():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        drift_result = enhanced_model.check_data_drift()
        return jsonify(drift_result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Метрики модели
@app.route('/api/smartantifraud/model/metrics', methods=['GET'])
def api_smartantifraud_metrics():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        metrics = enhanced_model.model_metrics
        return jsonify({
            'metrics': metrics,
            'model_type': enhanced_model.model_type,
            'last_training_date': enhanced_model.last_training_date.isoformat() if enhanced_model.last_training_date else None,
            'feature_count': len(enhanced_model.feature_names)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Интерпретируемость (SHAP)
@app.route('/api/smartantifraud/explain', methods=['POST'])
def api_smartantifraud_explain():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        transaction_data = request.json
        
        # Получаем предсказание с SHAP
        result = enhanced_model.predict_fraud_enhanced(transaction_data, return_shap=True)
        
        return jsonify({
            'prediction': result,
            'explanation': {
                'top_features': result.get('feature_contributions', {}),
                'risk_factors': result.get('reasons', [])
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Управление порогами
@app.route('/api/smartantifraud/thresholds', methods=['GET', 'POST'])
def api_smartantifraud_thresholds():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        
        if request.method == 'POST':
            # Обновление порогов
            data = request.json
            if 'thresholds' in data:
                enhanced_model.thresholds.update(data['thresholds'])
                return jsonify({
                    'success': True,
                    'thresholds': enhanced_model.thresholds
                })
        else:
            # Получение порогов
            return jsonify({
                'thresholds': enhanced_model.thresholds
            })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Retraining модели
@app.route('/api/smartantifraud/retrain', methods=['POST'])
def api_smartantifraud_retrain():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        success = enhanced_model.train_model_enhanced()
        
        if success:
            return jsonify({
                'success': True,
                'metrics': enhanced_model.model_metrics,
                'message': 'Модель успешно переобучена'
            })
        else:
            return jsonify({'error': 'Ошибка при переобучении модели'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Batch обработка (оптимизированная)
@app.route('/api/smartantifraud/batch-enhanced', methods=['POST'])
def api_smartantifraud_batch_enhanced():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        data = request.json
        transactions = data.get('transactions', [])
        
        results = []
        summary = {'high': 0, 'medium': 0, 'low': 0, 'fraud_detected': 0}
        
        # Batch processing с кешированием
        for transaction in transactions:
            result = enhanced_model.predict_fraud_enhanced(transaction, return_shap=False)
            results.append(result)
            summary[result['risk_level']] += 1
            if result.get('is_fraud', False):
                summary['fraud_detected'] += 1
        
        return jsonify({
            'results': results,
            'summary': summary,
            'total': len(transactions),
            'fraud_rate': summary['fraud_detected'] / len(transactions) if transactions else 0
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Real-time scoring endpoint
@app.route('/api/smartantifraud/realtime', methods=['POST'])
def api_smartantifraud_realtime():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        realtime_processor = get_realtime_processor(enhanced_model)
        transaction_data = request.json
        
        # Используем real-time процессор
        result = realtime_processor.process(transaction_data)
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# MLOps endpoints
@app.route('/api/smartantifraud/mlops/versions', methods=['GET'])
def api_smartantifraud_versions():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        mlops = get_mlops_pipeline()
        versions = mlops.list_versions()
        return jsonify({
            'versions': versions,
            'current_version': mlops.current_version
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/smartantifraud/mlops/deploy/<version>', methods=['POST'])
def api_smartantifraud_deploy(version):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        mlops = get_mlops_pipeline()
        success = mlops.deploy_version(version)
        if success:
            return jsonify({'success': True, 'version': version})
        else:
            return jsonify({'error': 'Версия не найдена'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/smartantifraud/mlops/rollback', methods=['POST'])
def api_smartantifraud_rollback():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        mlops = get_mlops_pipeline()
        previous_version = mlops.rollback()
        if previous_version:
            return jsonify({'success': True, 'version': previous_version})
        else:
            return jsonify({'error': 'Нет предыдущей версии'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/smartantifraud/mlops/auto-retrain', methods=['POST'])
def api_smartantifraud_auto_retrain():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        auto_retrainer = get_auto_retrainer(enhanced_model)
        version = auto_retrainer.retrain()
        
        if version:
            return jsonify({
                'success': True,
                'version': version,
                'metrics': enhanced_model.model_metrics
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Retraining не выполнен (модель не улучшилась или не требуется)'
            })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Real-time статистика
@app.route('/api/smartantifraud/realtime/stats', methods=['GET'])
def api_smartantifraud_realtime_stats():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        enhanced_model = get_enhanced_model()
        realtime_processor = get_realtime_processor(enhanced_model)
        stats = realtime_processor.get_stats()
        return jsonify(stats)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Получение первого перевода
@app.route('/api/smartantifraud/first-transaction', methods=['GET'])
def api_smartantifraud_first_transaction():
    """Получить самый первый перевод из CSV файла"""
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        import pandas as pd
        client_id = request.args.get('client_id', type=int)
        
        # Используем translate.csv
        csv_file = 'csv/translate.csv'
        
        if not os.path.exists(csv_file):
            return jsonify({
                'error': 'CSV файл не найден',
                'transaction': None
            })
        
        # Пробуем разные кодировки
        encodings = ['windows-1251', 'cp1251', 'latin-1', 'utf-8-sig', 'utf-8']
        transactions_df = None
        encoding_used = None
        
        for encoding in encodings:
            try:
                # Пропускаем первую строку (русский заголовок), используем вторую как названия колонок
                transactions_df = pd.read_csv(
                    csv_file, 
                    sep=';',
                    encoding=encoding,
                    on_bad_lines='skip',
                    low_memory=False,
                    skiprows=1,  # Пропускаем первую строку с русским заголовком
                    header=0     # Вторая строка станет заголовком
                )
                # Очищаем названия колонок от пробелов и кавычек
                transactions_df.columns = transactions_df.columns.str.strip()
                encoding_used = encoding
                break
            except Exception as e:
                continue
        
        if transactions_df is None:
            return jsonify({
                'error': f'Не удалось прочитать CSV файл. Попробованы кодировки: {", ".join(encodings)}',
                'transaction': None
            })
        
        if transactions_df.empty:
            return jsonify({
                'error': 'CSV файл пуст',
                'transaction': None
            })
        
        # Фильтруем по клиенту, если указан
        if client_id:
            transactions_df = transactions_df[transactions_df['cst_dim_id'] == client_id]
        
        # Сортируем по дате (первые первыми - по возрастанию)
        if 'transdatetime' in transactions_df.columns:
            transactions_df['transdatetime'] = pd.to_datetime(transactions_df['transdatetime'], errors='coerce')
            transactions_df = transactions_df.sort_values('transdatetime', ascending=True)
        elif 'transdate' in transactions_df.columns:
            transactions_df['transdate'] = pd.to_datetime(transactions_df['transdate'], errors='coerce')
            transactions_df = transactions_df.sort_values('transdate', ascending=True)
        
        # Берем первую транзакцию
        if transactions_df.empty:
            return jsonify({
                'error': 'Транзакции не найдены',
                'transaction': None
            })
        
        first_row = transactions_df.iloc[0]
        
        # Формируем результат
        transaction = {
            'cst_dim_id': int(first_row.get('cst_dim_id', 0)),
            'amount': float(first_row.get('amount', 0)),
            'docno': int(first_row.get('docno', 0)) if pd.notna(first_row.get('docno')) else None,
            'direction': str(first_row.get('direction', '')),
            'target': int(first_row.get('target', 0)) if pd.notna(first_row.get('target')) else 0,
        }
        
        # Дата
        if 'transdatetime' in first_row and pd.notna(first_row.get('transdatetime')):
            transaction['transdatetime'] = str(first_row['transdatetime'])
            transaction['transdate'] = str(first_row['transdatetime'].date()) if hasattr(first_row['transdatetime'], 'date') else str(first_row['transdatetime'])[:10]
        elif 'transdate' in first_row and pd.notna(first_row.get('transdate')):
            transaction['transdate'] = str(first_row['transdate'])
            transaction['transdatetime'] = str(first_row['transdate'])
        else:
            transaction['transdate'] = None
            transaction['transdatetime'] = None
        
        return jsonify({
            'success': True,
            'transaction': transaction,
            'source_file': csv_file
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# Получение последних переводов
@app.route('/api/smartantifraud/last-transactions', methods=['GET'])
def api_smartantifraud_last_transactions():
    """Получить последние переводы из CSV файла"""
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        import pandas as pd
        limit = request.args.get('limit', 10, type=int)
        client_id = request.args.get('client_id', type=int)
        
        # Используем translate.csv
        csv_file = 'csv/translate.csv'
        
        if not os.path.exists(csv_file):
            return jsonify({
                'error': 'CSV файл не найден',
                'transactions': [],
                'total': 0
            })
        
        # Пробуем разные кодировки
        encodings = ['windows-1251', 'cp1251', 'latin-1', 'utf-8-sig', 'utf-8']
        transactions_df = None
        encoding_used = None
        
        for encoding in encodings:
            try:
                # Пропускаем первую строку (русский заголовок), используем вторую как названия колонок
                transactions_df = pd.read_csv(
                    csv_file, 
                    sep=';',
                    encoding=encoding,
                    on_bad_lines='skip',
                    low_memory=False,
                    skiprows=1,  # Пропускаем первую строку с русским заголовком
                    header=0     # Вторая строка станет заголовком
                )
                # Очищаем названия колонок от пробелов и кавычек
                transactions_df.columns = transactions_df.columns.str.strip()
                encoding_used = encoding
                break
            except Exception as e:
                continue
        
        if transactions_df is None:
            return jsonify({
                'error': f'Не удалось прочитать CSV файл. Попробованы кодировки: {", ".join(encodings)}',
                'transactions': [],
                'total': 0
            })
        
        if transactions_df.empty:
            return jsonify({
                'error': 'CSV файл пуст',
                'transactions': [],
                'total': 0
            })
        
        # Фильтруем по клиенту, если указан
        if client_id:
            transactions_df = transactions_df[transactions_df['cst_dim_id'] == client_id]
        
        # Сортируем по дате (последние первыми)
        if 'transdatetime' in transactions_df.columns:
            transactions_df['transdatetime'] = pd.to_datetime(transactions_df['transdatetime'], errors='coerce')
            transactions_df = transactions_df.sort_values('transdatetime', ascending=False)
        elif 'transdate' in transactions_df.columns:
            transactions_df['transdate'] = pd.to_datetime(transactions_df['transdate'], errors='coerce')
            transactions_df = transactions_df.sort_values('transdate', ascending=False)
        
        # Берем последние N транзакций
        last_transactions = transactions_df.head(limit)
        
        # Формируем результат
        transactions_list = []
        for idx, row in last_transactions.iterrows():
            transaction = {
                'cst_dim_id': int(row.get('cst_dim_id', 0)),
                'amount': float(row.get('amount', 0)),
                'docno': int(row.get('docno', 0)) if pd.notna(row.get('docno')) else None,
                'direction': str(row.get('direction', '')),
                'target': int(row.get('target', 0)) if pd.notna(row.get('target')) else 0,
            }
            
            # Дата
            if 'transdatetime' in row and pd.notna(row.get('transdatetime')):
                transaction['transdatetime'] = str(row['transdatetime'])
                transaction['transdate'] = str(row['transdatetime'].date()) if hasattr(row['transdatetime'], 'date') else str(row['transdatetime'])[:10]
            elif 'transdate' in row and pd.notna(row.get('transdate')):
                transaction['transdate'] = str(row['transdate'])
                transaction['transdatetime'] = str(row['transdate'])
            else:
                transaction['transdate'] = None
                transaction['transdatetime'] = None
            
            transactions_list.append(transaction)
        
        return jsonify({
            'success': True,
            'transactions': transactions_list,
            'total': len(transactions_list),
            'source_file': csv_file
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# Обработка банковского перевода (имитация)
@app.route('/api/smartantifraud/process-transfer', methods=['POST'])
def api_smartantifraud_process_transfer():
    """Обработка перевода: проверка антифрод + сохранение в CSV"""
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        sender_id = data.get('sender_id')
        receiver_id = data.get('receiver_id') or data.get('receiver')
        amount = float(data.get('amount', 0))
        currency = data.get('currency', 'KZT')
        comment = data.get('comment', '')
        
        if not sender_id or not receiver_id or amount <= 0:
            return jsonify({'error': 'Неверные данные перевода'}), 400
        
        # Формируем данные для проверки антифрод
        transaction_data = {
            'cst_dim_id': int(sender_id),
            'amount': amount,
            'currency': currency,
            'direction': receiver_id,
            'comment': comment
        }
        
        # Проверяем через антифрод систему
        enhanced_model = get_enhanced_model()
        fraud_check = enhanced_model.predict_fraud_enhanced(transaction_data, return_shap=False)
        
        risk_level = fraud_check.get('risk_level', 'low')
        is_fraud = fraud_check.get('is_fraud', False)
        risk_score = fraud_check.get('risk_score', 0)
        
        # Определяем, блокировать ли перевод
        should_block = is_fraud or risk_score >= 70 or risk_level == 'high'
        
        # Если не блокируем - сохраняем в CSV
        if not should_block:
            # Генерируем уникальный номер документа
            import random
            docno = random.randint(1000, 99999)
            
            # Текущая дата и время
            from datetime import datetime
            now = datetime.now()
            transdate = now.strftime('%Y-%m-%d 00:00:00.000')
            transdatetime = now.strftime('%Y-%m-%d %H:%M:%S.000')
            
            # Хеш для direction (можно использовать receiver_id или сгенерировать)
            import hashlib
            direction_hash = hashlib.md5(str(receiver_id).encode()).hexdigest()
            
            # Формируем строку для CSV
            csv_line = f"{sender_id};'{transdate}';'{transdatetime}';{amount};{docno};{direction_hash};0\n"
            
            # Сохраняем в CSV файл translate.csv
            csv_file = 'csv/translate.csv'
            file_exists = os.path.exists(csv_file)
            
            # Проверяем, есть ли заголовки в файле
            has_header = False
            if file_exists:
                try:
                    with open(csv_file, 'r', encoding='utf-8-sig') as f:
                        first_line = f.readline().strip()
                        if 'cst_dim_id' in first_line:
                            has_header = True
                except:
                    pass
            
            with open(csv_file, 'a', encoding='utf-8-sig', newline='') as f:
                # Если файл новый или нет заголовков - добавляем заголовки
                if not file_exists or not has_header:
                    f.write('cst_dim_id;transdate;transdatetime;amount;docno;direction;target\n')
                f.write(csv_line)
            
            return jsonify({
                'success': True,
                'blocked': False,
                'message': 'Перевод успешно выполнен',
                'transaction': {
                    'sender_id': sender_id,
                    'receiver_id': receiver_id,
                    'amount': amount,
                    'currency': currency,
                    'docno': docno,
                    'date': transdatetime
                },
                'fraud_check': {
                    'risk_level': risk_level,
                    'risk_score': risk_score,
                    'is_fraud': is_fraud,
                    'reasons': fraud_check.get('reasons', [])
                }
            })
        else:
            # Блокируем перевод
            return jsonify({
                'success': False,
                'blocked': True,
                'message': 'Перевод заблокирован системой антифрода',
                'reason': 'Обнаружены признаки мошенничества',
                'fraud_check': {
                    'risk_level': risk_level,
                    'risk_score': risk_score,
                    'is_fraud': is_fraud,
                    'reasons': fraud_check.get('reasons', [])
                }
            }), 403
            
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# Блокировка транзакции
@app.route('/api/smartantifraud/block-transaction', methods=['POST'])
def api_smartantifraud_block_transaction():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        transaction_id = data.get('transaction_id')
        reason = data.get('reason', 'Обнаружены признаки мошенничества')
        
        # Здесь можно добавить логику сохранения блокировки в БД
        # Пока просто возвращаем успех
        
        return jsonify({
            'success': True,
            'message': 'Транзакция успешно заблокирована',
            'transaction_id': transaction_id,
            'reason': reason,
            'blocked_at': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Отметка транзакции как легитимной
@app.route('/api/smartantifraud/mark-legitimate', methods=['POST'])
def api_smartantifraud_mark_legitimate():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        transaction_id = data.get('transaction_id')
        notes = data.get('notes', '')
        
        # Здесь можно добавить логику сохранения в БД
        # Пока просто возвращаем успех
        
        return jsonify({
            'success': True,
            'message': 'Транзакция отмечена как легитимная',
            'transaction_id': transaction_id,
            'notes': notes,
            'marked_at': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Получение деталей транзакции
@app.route('/api/smartantifraud/transaction-details/<transaction_id>', methods=['GET'])
def api_smartantifraud_transaction_details(transaction_id):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        import pandas as pd
        csv_file = 'csv/translate.csv'
        
        if not os.path.exists(csv_file):
            return jsonify({'error': 'CSV файл не найден'}), 404
        
        # Читаем CSV с разными кодировками
        transactions_df = None
        encodings = ['windows-1251', 'cp1251', 'latin-1', 'utf-8-sig', 'utf-8']
        
        for encoding in encodings:
            try:
                transactions_df = pd.read_csv(
                    csv_file, 
                    sep=';', 
                    encoding=encoding, 
                    low_memory=False,
                    skiprows=1,
                    header=0
                )
                transactions_df.columns = transactions_df.columns.str.strip()
                break
            except Exception:
                continue
        
        if transactions_df is None or transactions_df.empty:
            return jsonify({'error': 'Не удалось прочитать данные'}), 404
        
        # Ищем транзакцию по ID
        transaction = None
        if 'docno' in transactions_df.columns:
            transaction = transactions_df[transactions_df['docno'].astype(str) == str(transaction_id)].iloc[0] if len(transactions_df[transactions_df['docno'].astype(str) == str(transaction_id)]) > 0 else None
        
        if transaction is None:
            return jsonify({'error': 'Транзакция не найдена'}), 404
        
        # Формируем детали
        details = {
            'transaction_id': str(transaction.get('docno', transaction_id)),
            'amount': float(transaction.get('amount', 0)),
            'client_id': int(transaction.get('cst_dim_id', 0)),
            'direction': str(transaction.get('direction', '')),
            'date': str(transaction.get('transdate', '')),
            'datetime': str(transaction.get('transdatetime', '')),
            'target': int(transaction.get('target', 0))
        }
        
        # Получаем анализ риска
        enhanced_model = get_enhanced_model()
        fraud_check = enhanced_model.predict_fraud_enhanced({
            'cst_dim_id': details['client_id'],
            'amount': details['amount'],
            'direction': details['direction']
        }, return_shap=True)
        
        details['fraud_analysis'] = fraud_check
        
        return jsonify({
            'success': True,
            'transaction': details
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# ==================== AI-Procure API Endpoints ====================

# Извлечение параметров тендера
@app.route('/api/ai-procure/extract', methods=['POST'])
def api_procure_extract():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        tender_text = data.get('tender_text', '')
        source_type = data.get('source_type', 'text')
        
        if not tender_text:
            return jsonify({'error': 'Текст тендера не предоставлен'}), 400
        
        tender_params = tender_analyzer.extract_tender_params(tender_text, source_type)
        completeness = tender_analyzer.analyze_tender_completeness(tender_params)
        
        return jsonify({
            'tender_params': tender_params,
            'completeness': completeness,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Подбор поставщиков
@app.route('/api/ai-procure/match-suppliers', methods=['POST'])
def api_procure_match_suppliers():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        tender_params = data.get('tender_params', {})
        criteria = data.get('criteria', {})
        
        if not tender_params:
            return jsonify({'error': 'Параметры тендера не предоставлены'}), 400
        
        suppliers, summary = supplier_matcher.match_suppliers(tender_params, criteria)
        
        return jsonify({
            'suppliers': suppliers,
            'summary': summary,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Анализ рисков
@app.route('/api/ai-procure/analyze-risks', methods=['POST'])
def api_procure_analyze_risks():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        tender_params = data.get('tender_params', {})
        winner_info = data.get('winner_info')
        
        if not tender_params:
            return jsonify({'error': 'Параметры тендера не предоставлены'}), 400
        
        risk_analysis = risk_analyzer.analyze_risks(tender_params, winner_info)
        
        return jsonify({
            'risk_analysis': risk_analysis,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Проверка аффилированности
@app.route('/api/ai-procure/check-affiliation', methods=['POST'])
def api_procure_check_affiliation():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        entities = data.get('entities', [])
        
        if not entities:
            return jsonify({'error': 'Список сущностей не предоставлен'}), 400
        
        affiliation_analysis = risk_analyzer.check_affiliation(entities)
        
        return jsonify({
            'affiliation_analysis': affiliation_analysis,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Генерация комплексного отчёта
@app.route('/api/ai-procure/generate-report', methods=['POST'])
def api_procure_generate_report():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        tender_params = data.get('tender_params', {})
        suppliers = data.get('suppliers', [])
        risk_analysis = data.get('risk_analysis', {})
        completeness = data.get('completeness', {})
        winner = data.get('winner')
        
        if not tender_params:
            return jsonify({'error': 'Параметры тендера не предоставлены'}), 400
        
        report = report_generator.generate_comprehensive_report(
            tender_params, suppliers, risk_analysis, completeness, winner
        )
        
        return jsonify({
            'report': report,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Комплексный анализ тендера (все функции сразу)
@app.route('/api/ai-procure/analyze', methods=['POST'])
def api_procure_analyze():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        tender_text = data.get('tender_text', '')
        source_type = data.get('source_type', 'text')
        include_suppliers = data.get('include_suppliers', True)
        include_risks = data.get('include_risks', True)
        include_report = data.get('include_report', True)
        
        if not tender_text:
            return jsonify({'error': 'Текст тендера не предоставлен'}), 400
        
        # 1. Извлечение параметров
        tender_params = tender_analyzer.extract_tender_params(tender_text, source_type)
        completeness = tender_analyzer.analyze_tender_completeness(tender_params)
        
        result = {
            'tender_params': tender_params,
            'completeness': completeness,
            'success': True
        }
        
        # 2. Подбор поставщиков
        if include_suppliers:
            suppliers, summary = supplier_matcher.match_suppliers(tender_params)
            result['suppliers'] = suppliers
            result['suppliers_summary'] = summary
        else:
            suppliers = []
        
        # 3. Анализ рисков
        if include_risks:
            risk_analysis = risk_analyzer.analyze_risks(tender_params)
            result['risk_analysis'] = risk_analysis
        else:
            risk_analysis = {}
        
        # 4. Генерация отчёта
        if include_report:
            report = report_generator.generate_comprehensive_report(
                tender_params, suppliers, risk_analysis, completeness
            )
            result['report'] = report
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Поддержка новичков - получение рейтинга
@app.route('/api/ai-procure/beginner/rating', methods=['GET'])
def api_procure_beginner_rating():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        user_id = session.get('username', 'anonymous')
        rating = beginner_support.get_beginner_rating(user_id)
        return jsonify({'rating': rating, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Поддержка новичков - обновление рейтинга
@app.route('/api/ai-procure/beginner/update-rating', methods=['POST'])
def api_procure_beginner_update_rating():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        action = data.get('action', 'participate')
        success = data.get('success', False)
        user_id = session.get('username', 'anonymous')
        
        beginner_support.update_rating(user_id, action, success)
        rating = beginner_support.get_beginner_rating(user_id)
        
        return jsonify({'rating': rating, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Поддержка новичков - создание тендера в песочнице
@app.route('/api/ai-procure/beginner/sandbox/create', methods=['POST'])
def api_procure_beginner_sandbox_create():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        tender_params = data.get('tender_params', {})
        user_id = session.get('username', 'anonymous')
        
        sandbox_tender = beginner_support.create_sandbox_tender(tender_params, user_id)
        return jsonify({'sandbox_tender': sandbox_tender, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Поддержка новичков - получение тендеров из песочницы
@app.route('/api/ai-procure/beginner/sandbox/list', methods=['GET'])
def api_procure_beginner_sandbox_list():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        user_id = session.get('username', 'anonymous')
        sandbox_tenders = beginner_support.get_sandbox_tenders(user_id)
        return jsonify({'sandbox_tenders': sandbox_tenders, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Поддержка новичков - отправка попытки в песочнице
@app.route('/api/ai-procure/beginner/sandbox/submit', methods=['POST'])
def api_procure_beginner_sandbox_submit():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        tender_id = data.get('tender_id')
        attempt_data = data.get('attempt_data', {})
        user_id = session.get('username', 'anonymous')
        
        if not tender_id:
            return jsonify({'error': 'ID тендера не указан'}), 400
        
        feedback = beginner_support.submit_sandbox_attempt(tender_id, user_id, attempt_data)
        return jsonify({'feedback': feedback, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Поддержка новичков - пошаговая инструкция
@app.route('/api/ai-procure/beginner/guide', methods=['POST'])
def api_procure_beginner_guide():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        tender_params = data.get('tender_params', {})
        step = data.get('step', 1)
        
        guide = report_generator.generate_beginner_guide(tender_params, step)
        return jsonify({'guide': guide, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Поддержка новичков - генерация документов
@app.route('/api/ai-procure/beginner/generate-documents', methods=['POST'])
def api_procure_beginner_generate_documents():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        tender_params = data.get('tender_params', {})
        document_type = data.get('document_type', 'application')
        
        document = beginner_support.generate_documents(tender_params, document_type)
        return jsonify({'document': document, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Поиск партнёрств для новичков
@app.route('/api/ai-procure/beginner/partnerships', methods=['POST'])
def api_procure_beginner_partnerships():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        beginner_supplier = data.get('beginner_supplier', {})
        tender_params = data.get('tender_params', {})
        
        if not tender_params:
            return jsonify({'error': 'Параметры тендера не предоставлены'}), 400
        
        partners, strategy = supplier_matcher.find_partnership_opportunities(beginner_supplier, tender_params)
        return jsonify({
            'partners': partners,
            'strategy': strategy,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Старый endpoint для обратной совместимости
@app.route('/api/ai-procure', methods=['POST'])
def api_ai_procure():
    """Старый endpoint, перенаправляет на комплексный анализ"""
    return api_procure_analyze()

# ==================== AI-Scrum Master API Endpoints ====================

# Управление проектами
@app.route('/api/ai-scrum/projects/create', methods=['POST'])
def api_scrum_create_project():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        project = project_manager.create_project(
            name=data.get('name'),
            description=data.get('description', ''),
            owner=session.get('username', 'unknown'),
            deadline=data.get('deadline')
        )
        return jsonify({'project': project, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/projects', methods=['GET'])
def api_scrum_get_projects():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        username = request.args.get('username')
        projects = project_manager.get_projects(username)
        return jsonify({'projects': projects, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/projects/<project_id>', methods=['GET'])
def api_scrum_get_project(project_id):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        project = project_manager.get_project(project_id)
        if not project:
            return jsonify({'error': 'Проект не найден'}), 404
        
        # Получаем дополнительную информацию
        team_members = project_manager.get_team_members(project_id)
        
        # Загружаем спринты проекта
        sprints = sprint_manager._load_sprints()
        project_sprints = [s for s in sprints if s.get("project_id") == project_id]
        
        # Загружаем задачи проекта (если есть)
        tasks = sprint_manager._load_tasks()
        project_tasks = [t for t in tasks if t.get("project_id") == project_id]
        
        # Статистика проекта
        stats = {
            "team_size": len(team_members),
            "sprints_count": len(project_sprints),
            "active_sprints": len([s for s in project_sprints if s.get("status") == "active"]),
            "tasks_count": len(project_tasks),
            "completed_tasks": len([t for t in project_tasks if t.get("status") == "completed"]),
            "in_progress_tasks": len([t for t in project_tasks if t.get("status") == "in_progress"])
        }
        
        # Анализ дедлайнов
        deadline_risks = deadline_tracker.analyze_risks(project_id)
        
        return jsonify({
            'project': project,
            'team_members': team_members,
            'sprints': project_sprints,
            'tasks': project_tasks[:20],  # Первые 20 задач
            'statistics': stats,
            'deadline_risks': deadline_risks,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Управление командами
@app.route('/api/ai-scrum/teams/create', methods=['POST'])
def api_scrum_create_team():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        team = project_manager.create_team(
            project_id=data.get('project_id'),
            team_name=data.get('team_name'),
            members=data.get('members', [])
        )
        return jsonify({'team': team, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/members/add', methods=['POST'])
def api_scrum_add_member():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        member = project_manager.add_member(
            project_id=data.get('project_id'),
            username=data.get('username'),
            role=data.get('role', 'developer'),
            workload=data.get('workload', 1.0)
        )
        return jsonify({'member': member, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Создание задач из текста
@app.route('/api/ai-scrum/tasks/create-from-text', methods=['POST'])
def api_scrum_create_tasks_from_text():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        text = data.get('text', '')
        project_id = data.get('project_id')
        context = data.get('context')
        
        if not text or not project_id:
            return jsonify({'error': 'Текст и project_id обязательны'}), 400
        
        tasks_data = task_creator.create_tasks_from_text(text, project_id, context)
        return jsonify({'tasks_data': tasks_data, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/tasks/confirm', methods=['POST'])
def api_scrum_confirm_tasks():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        tasks_data = data.get('tasks_data', {})
        save_to_jira = data.get('save_to_jira', False)
        
        result = task_creator.confirm_and_save_tasks(tasks_data, save_to_jira)
        return jsonify({'result': result, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Декомпозиция задач
@app.route('/api/ai-scrum/tasks/decompose', methods=['POST'])
def api_scrum_decompose_task():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        decomposition = task_decomposer.decompose_task(
            task=data.get('task', {}),
            team_info=data.get('team_info', {}),
            resources=data.get('resources', {}),
            calendar=data.get('calendar', {})
        )
        return jsonify({'decomposition': decomposition, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/tasks/optimize-allocation', methods=['POST'])
def api_scrum_optimize_allocation():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        result = task_decomposer.optimize_allocation(
            tasks=data.get('tasks', []),
            team=data.get('team', [])
        )
        return jsonify({'result': result, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Ассистент встреч
@app.route('/api/ai-scrum/meetings/analyze', methods=['POST'])
def api_scrum_analyze_meeting():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        analysis = meeting_assistant.analyze_meeting_transcript(
            transcript=data.get('transcript', ''),
            meeting_type=data.get('meeting_type', 'standup'),
            project_id=data.get('project_id'),
            participants=data.get('participants', [])
        )
        return jsonify({'analysis': analysis, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/meetings/generate-report', methods=['POST'])
def api_scrum_generate_meeting_report():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        analysis = data.get('analysis', {})
        report = meeting_assistant.generate_meeting_report(analysis)
        return jsonify({'report': report, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/meetings', methods=['GET'])
def api_scrum_get_meetings():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        project_id = request.args.get('project_id')
        meetings = meeting_assistant.get_meetings(project_id)
        return jsonify({'meetings': meetings, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Контроль дедлайнов
@app.route('/api/ai-scrum/deadlines/add', methods=['POST'])
def api_scrum_add_deadline():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        deadline = deadline_tracker.add_deadline(
            task_id=data.get('task_id'),
            deadline=data.get('deadline'),
            assignee=data.get('assignee'),
            project_id=data.get('project_id'),
            priority=data.get('priority', 'medium')
        )
        return jsonify({'deadline': deadline, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/deadlines/check', methods=['GET'])
def api_scrum_check_deadlines():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        days_ahead = request.args.get('days_ahead', 7, type=int)
        result = deadline_tracker.check_deadlines(days_ahead)
        return jsonify({'result': result, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/deadlines/reminders', methods=['GET'])
def api_scrum_get_reminders():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        assignee = request.args.get('assignee')
        reminders = deadline_tracker.get_reminders(assignee)
        return jsonify({'reminders': reminders, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/deadlines/risks', methods=['GET'])
def api_scrum_analyze_deadline_risks():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        project_id = request.args.get('project_id')
        risks = deadline_tracker.analyze_risks(project_id)
        return jsonify({'risks': risks, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Управление спринтами
@app.route('/api/ai-scrum/sprints/create', methods=['POST'])
def api_scrum_create_sprint():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        sprint = sprint_manager.create_sprint(
            project_id=data.get('project_id'),
            name=data.get('name'),
            start_date=data.get('start_date'),
            end_date=data.get('end_date'),
            goal=data.get('goal', '')
        )
        return jsonify({'sprint': sprint, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/sprints/<sprint_id>/backlog', methods=['POST'])
def api_scrum_build_backlog(sprint_id):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        backlog = sprint_manager.build_sprint_backlog(
            sprint_id=sprint_id,
            available_tasks=data.get('available_tasks', []),
            team_capacity=data.get('team_capacity', {})
        )
        return jsonify({'backlog': backlog, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/sprints/<sprint_id>/burndown', methods=['GET'])
def api_scrum_calculate_burndown(sprint_id):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        burndown = sprint_manager.calculate_burndown(sprint_id)
        return jsonify({'burndown': burndown, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/sprints/<sprint_id>/performance', methods=['GET'])
def api_scrum_analyze_sprint_performance(sprint_id):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        performance = sprint_manager.analyze_sprint_performance(sprint_id)
        return jsonify({'performance': performance, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Аналитика
@app.route('/api/ai-scrum/analytics/insights', methods=['POST'])
def api_scrum_generate_insights():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        project_id = data.get('project_id')
        if not project_id:
            return jsonify({'error': 'project_id обязателен'}), 400
        
        # Если данные не предоставлены, аналитика загрузит их сама
        custom_data = data.get('data')
        insights = analytics_engine.generate_insights(
            project_id=project_id,
            data=custom_data
        )
        return jsonify({'insights': insights, 'success': True})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/ai-scrum/analytics/predict-sprint', methods=['POST'])
def api_scrum_predict_sprint():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        prediction = analytics_engine.predict_sprint_completion(
            sprint_id=data.get('sprint_id'),
            current_data=data.get('current_data', {})
        )
        return jsonify({'prediction': prediction, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Интеграции
@app.route('/api/ai-scrum/integrations/jira/sync', methods=['POST'])
def api_scrum_sync_jira():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        result = integration_manager.sync_to_jira(
            tasks=data.get('tasks', []),
            project_key=data.get('project_key', 'PROJ')
        )
        return jsonify({'result': result, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Старый endpoint для обратной совместимости
@app.route('/api/ai-scrum', methods=['POST'])
def api_ai_scrum():
    """Старый endpoint, перенаправляет на создание задач из текста"""
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.json
    query = data.get('query', '')
    
    if not query:
        return jsonify({'error': 'Запрос не предоставлен'}), 400
    
    # Используем новый функционал создания задач
    try:
        # Создаём временный проект если нужно
        project = project_manager.create_project(
            name="Временный проект",
            description="Создан из запроса",
            owner=session.get('username', 'unknown')
        )
        
        tasks_data = task_creator.create_tasks_from_text(query, project["project_id"])
        return jsonify({
            'result': 'Задачи созданы из текста',
            'tasks_data': tasks_data,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ==================== AI-Business Analyst API Endpoints ====================

# Анализ документа
@app.route('/api/ai-business-analyst/analyze-document', methods=['POST'])
def api_ba_analyze_document():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        document_text = data.get('document_text', '')
        document_type = data.get('document_type')
        
        if not document_text:
            return jsonify({'error': 'Текст документа не предоставлен'}), 400
        
        analysis = document_analyzer.analyze_document(document_text, document_type)
        return jsonify({
            'analysis': analysis,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Извлечение требований
@app.route('/api/ai-business-analyst/extract-requirements', methods=['POST'])
def api_ba_extract_requirements():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        document_text = data.get('document_text', '')
        context = data.get('context', {})
        
        if not document_text:
            return jsonify({'error': 'Текст документа не предоставлен'}), 400
        
        requirements = requirement_extractor.extract_requirements(document_text, context)
        
        # Если есть анализ, находим пробелы
        analysis = data.get('analysis', {})
        if analysis:
            gaps = requirement_extractor.identify_gaps(requirements, analysis)
            requirements['gaps'] = gaps
        
        return jsonify({
            'requirements': requirements,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Генерация BRD
@app.route('/api/ai-business-analyst/generate-brd', methods=['POST'])
def api_ba_generate_brd():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        analysis = data.get('analysis', {})
        context = data.get('context', {})
        export_format = data.get('export_format', None)  # 'docx', 'doc', 'pdf', или None для текста
        
        if not analysis:
            return jsonify({'error': 'Анализ документа не предоставлен'}), 400
        
        brd = document_generator.generate_brd(analysis, context)
        
        # Extract BRD content
        brd_content = ''
        if isinstance(brd, dict):
            if 'error' in brd:
                return jsonify({
                    'error': brd.get('error', 'Ошибка генерации BRD'),
                    'success': False
                }), 500
            else:
                brd_content = brd.get('content', str(brd))
        else:
            brd_content = str(brd)
        
        # Если запрошен экспорт в файл
        if export_format:
            os.makedirs('uploads', exist_ok=True)
            
            # 'doc' и 'docx' обрабатываются одинаково (используем docx формат)
            if export_format in ['docx', 'doc']:
                try:
                    from docx import Document
                    doc = Document()
                    
                    # Парсим Markdown и добавляем в документ
                    lines = brd_content.split('\n')
                    for line in lines:
                        if line.startswith('# '):
                            doc.add_heading(line[2:], level=1)
                        elif line.startswith('## '):
                            doc.add_heading(line[3:], level=2)
                        elif line.startswith('### '):
                            doc.add_heading(line[4:], level=3)
                        elif line.startswith('- ') or line.startswith('* '):
                            doc.add_paragraph(line[2:], style='List Bullet')
                        elif line.strip():
                            doc.add_paragraph(line)
                    
                    # Используем .docx для обоих форматов (python-docx не поддерживает старый .doc)
                    file_ext = '.docx' if export_format == 'docx' else '.docx'
                    filename = f'BRD_{datetime.now().strftime("%Y%m%d_%H%M%S")}{file_ext}'
                    filepath = os.path.join('uploads', filename)
                    doc.save(filepath)
                    
                    return jsonify({
                        'brd': {'content': brd_content, 'type': 'BRD'},
                        'filename': filename,
                        'filepath': filepath,
                        'format': export_format,
                        'success': True
                    })
                except ImportError:
                    return jsonify({'error': 'Библиотека python-docx не установлена'}), 500
            
            elif export_format == 'pdf':
                try:
                    from reportlab.lib.pagesizes import letter, A4
                    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
                    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
                    from reportlab.lib.units import inch
                    import re
                    
                    filename = f'BRD_{datetime.now().strftime("%Y%m%d_%H%M%S")}.pdf'
                    filepath = os.path.join('uploads', filename)
                    
                    doc = SimpleDocTemplate(filepath, pagesize=A4)
                    styles = getSampleStyleSheet()
                    story = []
                    
                    # Создаем кастомные стили
                    title_style = ParagraphStyle(
                        'CustomTitle',
                        parent=styles['Heading1'],
                        fontSize=18,
                        textColor='#8B1E2D',
                        spaceAfter=12,
                    )
                    heading1_style = ParagraphStyle(
                        'CustomHeading1',
                        parent=styles['Heading1'],
                        fontSize=16,
                        textColor='#8B1E2D',
                        spaceAfter=10,
                    )
                    heading2_style = ParagraphStyle(
                        'CustomHeading2',
                        parent=styles['Heading2'],
                        fontSize=14,
                        textColor='#A52A2A',
                        spaceAfter=8,
                    )
                    
                    # Парсим Markdown
                    lines = brd_content.split('\n')
                    for line in lines:
                        if line.startswith('# '):
                            story.append(Paragraph(line[2:], title_style))
                            story.append(Spacer(1, 0.2*inch))
                        elif line.startswith('## '):
                            story.append(Paragraph(line[3:], heading1_style))
                            story.append(Spacer(1, 0.15*inch))
                        elif line.startswith('### '):
                            story.append(Paragraph(line[4:], heading2_style))
                            story.append(Spacer(1, 0.1*inch))
                        elif line.startswith('- ') or line.startswith('* '):
                            story.append(Paragraph('• ' + line[2:], styles['Normal']))
                            story.append(Spacer(1, 0.05*inch))
                        elif line.strip():
                            story.append(Paragraph(line, styles['Normal']))
                            story.append(Spacer(1, 0.1*inch))
                    
                    doc.build(story)
                    
                    return jsonify({
                        'brd': {'content': brd_content, 'type': 'BRD'},
                        'filename': filename,
                        'filepath': filepath,
                        'format': export_format,
                        'success': True
                    })
                except ImportError:
                    return jsonify({'error': 'Библиотека reportlab не установлена. Установите: pip install reportlab'}), 500
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    return jsonify({'error': f'Ошибка создания PDF: {str(e)}'}), 500
        
        # Возвращаем только текст BRD
        return jsonify({
            'brd': {'content': brd_content, 'type': 'BRD'},
            'success': True
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Ошибка генерации BRD: {str(e)}'}), 500

# Генерация Use Case
@app.route('/api/ai-business-analyst/generate-use-case', methods=['POST'])
def api_ba_generate_use_case():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        if not data:
            return jsonify({'error': 'Данные не предоставлены'}), 400
        
        requirement = data.get('requirement', '')
        actor = data.get('actor', 'Пользователь')
        context = data.get('context', {})
        
        if not requirement or not requirement.strip():
            return jsonify({'error': 'Требование не предоставлено или пустое'}), 400
        
        use_case = document_generator.generate_use_case(requirement, actor, context)
        
        # Ensure use_case is a dict with proper structure
        if isinstance(use_case, dict):
            if 'error' in use_case:
                return jsonify({'error': use_case.get('error', 'Ошибка генерации Use Case')}), 500
        else:
            # If it's not a dict, wrap it
            use_case = {
                'type': 'Use Case',
                'content': str(use_case),
                'actor': actor
            }
        
        return jsonify({
            'use_case': use_case,
            'success': True
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Ошибка генерации Use Case: {str(e)}'}), 500

# Генерация User Stories
@app.route('/api/ai-business-analyst/generate-user-stories', methods=['POST'])
def api_ba_generate_user_stories():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        requirements = data.get('requirements', [])
        roles = data.get('roles', [])
        
        if not requirements:
            return jsonify({'error': 'Требования не предоставлены'}), 400
        
        user_stories = document_generator.generate_user_stories(requirements, roles)
        return jsonify({
            'user_stories': user_stories,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Генерация страницы для Confluence
@app.route('/api/ai-business-analyst/generate-confluence', methods=['POST'])
def api_ba_generate_confluence():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        documents = data.get('documents', [])
        title = data.get('title', 'Бизнес-анализ')
        
        if not documents:
            return jsonify({'error': 'Документы не предоставлены'}), 400
        
        confluence_page = document_generator.generate_confluence_page(documents, title)
        return jsonify({
            'confluence_page': confluence_page,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Генерация BPMN диаграммы
@app.route('/api/ai-business-analyst/generate-bpmn', methods=['POST'])
def api_ba_generate_bpmn():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        process_description = data.get('process_description', '')
        use_cases = data.get('use_cases', [])
        
        if not process_description and not use_cases:
            return jsonify({'error': 'Описание процесса или Use Cases не предоставлены'}), 400
        
        # Генерируем BPMN описание через AI
        prompt = f"""Создай BPMN диаграмму для следующего процесса:
        
Описание процесса: {process_description}

Use Cases: {use_cases}

Верни описание BPMN диаграммы в формате XML (BPMN 2.0) или текстовое описание с элементами:
- Start Event
- Tasks/Activities
- Gateways (Decision points)
- End Events
- Sequence Flows
"""
        response = model.generate_content(prompt)
        bpmn_description = response.text if hasattr(response, 'text') else str(response)
        
        return jsonify({
            'bpmn': bpmn_description,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Экспорт BRD в Word/PDF
@app.route('/api/ai-business-analyst/export-brd', methods=['POST'])
def api_ba_export_brd():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        brd_content = data.get('brd_content', '')
        format_type = data.get('format', 'word')  # 'word' or 'pdf'
        
        if not brd_content:
            return jsonify({'error': 'Содержимое BRD не предоставлено'}), 400
        
        # Для Word формата
        if format_type == 'word':
            try:
                from docx import Document
                doc = Document()
                # Парсим Markdown и добавляем в документ
                lines = brd_content.split('\n')
                for line in lines:
                    if line.startswith('# '):
                        doc.add_heading(line[2:], level=1)
                    elif line.startswith('## '):
                        doc.add_heading(line[3:], level=2)
                    elif line.startswith('### '):
                        doc.add_heading(line[4:], level=3)
                    elif line.startswith('- ') or line.startswith('* '):
                        doc.add_paragraph(line[2:], style='List Bullet')
                    elif line.strip():
                        doc.add_paragraph(line)
                
                # Сохраняем временный файл
                filename = f'BRD_{datetime.now().strftime("%Y%m%d_%H%M%S")}.docx'
                filepath = os.path.join('uploads', filename)
                os.makedirs('uploads', exist_ok=True)
                doc.save(filepath)
                
                return jsonify({
                    'filename': filename,
                    'filepath': filepath,
                    'success': True
                })
            except ImportError:
                return jsonify({'error': 'Библиотека python-docx не установлена'}), 500
        
        # Для PDF формата (простой вариант - возвращаем текст)
        elif format_type == 'pdf':
            return jsonify({
                'content': brd_content,
                'format': 'pdf',
                'success': True,
                'message': 'PDF экспорт будет реализован позже. Используйте Word формат.'
            })
        
        return jsonify({'error': 'Неподдерживаемый формат'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Публикация в Confluence (локальное хранение)
@app.route('/api/ai-business-analyst/publish-confluence', methods=['POST'])
def api_ba_publish_confluence():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        import json
        data = request.json
        if not data:
            return jsonify({'error': 'Данные не предоставлены'}), 400
        
        page_content = data.get('page_content', '')
        page_title = data.get('page_title', 'Business Requirements Document')
        space_key = data.get('space_key', 'BA')
        brd_content = data.get('brd_content', '')
        
        # Используем brd_content если page_content пустой
        final_content = page_content or brd_content
        
        if not final_content or len(final_content.strip()) < 10:
            return jsonify({'error': 'Содержимое страницы не предоставлено или слишком короткое'}), 400
        
        if not page_title or not page_title.strip():
            page_title = 'Business Requirements Document'
        
        if not space_key or not space_key.strip():
            space_key = 'BA'
        
        # Сохраняем документ в локальный файл
        confluence_dir = 'confluence_docs'
        os.makedirs(confluence_dir, exist_ok=True)
        
        # Создаем уникальный ID для документа
        doc_id = f"{space_key}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Сохраняем документ
        doc_data = {
            'id': doc_id,
            'title': page_title,
            'space_key': space_key,
            'content': final_content,
            'created_at': datetime.now().isoformat(),
            'created_by': session.get('username', 'unknown'),
            'type': 'BRD'
        }
        
        # Сохраняем в JSON файл
        doc_file = os.path.join(confluence_dir, f'{doc_id}.json')
        with open(doc_file, 'w', encoding='utf-8') as f:
            json.dump(doc_data, f, ensure_ascii=False, indent=2)
        
        # Обновляем индекс всех документов
        index_file = os.path.join(confluence_dir, 'index.json')
        documents = []
        if os.path.exists(index_file):
            try:
                with open(index_file, 'r', encoding='utf-8') as f:
                    documents = json.load(f)
            except:
                documents = []
        
        # Добавляем новый документ в начало списка
        documents.insert(0, {
            'id': doc_id,
            'title': page_title.strip(),
            'space_key': space_key.strip(),
            'created_at': doc_data['created_at'],
            'created_by': doc_data['created_by'],
            'type': doc_data['type']
        })
        
        # Сохраняем индекс
        with open(index_file, 'w', encoding='utf-8') as f:
            json.dump(documents, f, ensure_ascii=False, indent=2)
        
        return jsonify({
            'success': True,
            'message': f'Страница "{page_title}" успешно опубликована в локальное хранилище Confluence (пространство: {space_key})',
            'doc_id': doc_id,
            'page_url': f'/confluence-docs?doc={doc_id}'
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# Получить список всех документов Confluence
@app.route('/api/confluence-docs/list', methods=['GET'])
def api_confluence_docs_list():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        import json
        index_file = os.path.join('confluence_docs', 'index.json')
        if os.path.exists(index_file):
            with open(index_file, 'r', encoding='utf-8') as f:
                documents = json.load(f)
            return jsonify({
                'success': True,
                'documents': documents
            })
        else:
            return jsonify({
                'success': True,
                'documents': []
            })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Получить конкретный документ
@app.route('/api/confluence-docs/<doc_id>', methods=['GET'])
def api_confluence_doc(doc_id):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        import json
        doc_file = os.path.join('confluence_docs', f'{doc_id}.json')
        if os.path.exists(doc_file):
            with open(doc_file, 'r', encoding='utf-8') as f:
                doc_data = json.load(f)
            return jsonify({
                'success': True,
                'document': doc_data
            })
        else:
            return jsonify({'error': 'Документ не найден'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Получить данные для графика Fraud Probability Timeline
@app.route('/api/smartantifraud/probability-timeline', methods=['GET'])
def api_smartantifraud_probability_timeline():
    """Получить данные вероятности мошенничества по часам для графика"""
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        import pandas as pd
        from collections import defaultdict
        
        csv_file = 'csv/translate.csv'
        
        if not os.path.exists(csv_file):
            return jsonify({
                'success': True,
                'timeline': [],
                'message': 'Нет данных для отображения'
            })
        
        # Читаем CSV файл
        transactions_df = None
        encodings = ['windows-1251', 'cp1251', 'latin-1', 'utf-8-sig', 'utf-8']
        
        for encoding in encodings:
            try:
                transactions_df = pd.read_csv(
                    csv_file, 
                    sep=';', 
                    encoding=encoding, 
                    low_memory=False,
                    skiprows=1,
                    header=0
                )
                transactions_df.columns = transactions_df.columns.str.strip()
                break
            except Exception as e:
                print(f"Ошибка чтения {csv_file} с кодировкой {encoding}: {e}")
                continue
        
        if transactions_df is None or transactions_df.empty:
            return jsonify({
                'success': True,
                'timeline': [],
                'message': 'Нет транзакций для анализа'
            })
        
        # Группируем по часам и вычисляем среднюю вероятность
        hour_probabilities = defaultdict(list)
        hour_counts = defaultdict(int)
        
        # Обрабатываем последние 1000 транзакций (или за последние 7 дней)
        # Сначала фильтруем по дате - берем только последние 7 дней
        try:
            transactions_df['transdatetime_parsed'] = pd.to_datetime(
                transactions_df['transdatetime'].astype(str).str.strip("'\""), 
                errors='coerce'
            )
            # Берем транзакции за последние 7 дней
            seven_days_ago = pd.Timestamp.now() - pd.Timedelta(days=7)
            recent_transactions = transactions_df[
                transactions_df['transdatetime_parsed'] >= seven_days_ago
            ].tail(1000)  # Максимум 1000 транзакций
        except:
            # Если не удалось отфильтровать по дате, берем последние 500
            recent_transactions = transactions_df.tail(500)
        
        # Получаем модель для вычисления вероятностей
        enhanced_model = get_enhanced_model()
        
        # Обрабатываем транзакции
        processed_count = 0
        max_process = 500  # Ограничиваем количество для производительности
        
        for idx, row in recent_transactions.iterrows():
            if processed_count >= max_process:
                break
                
            try:
                # Извлекаем время из transdatetime
                transdatetime_str = str(row.get('transdatetime', ''))
                if not transdatetime_str or transdatetime_str == 'nan':
                    continue
                
                # Парсим дату и время
                try:
                    # Убираем кавычки если есть
                    transdatetime_str = transdatetime_str.strip("'\"")
                    trans_datetime = pd.to_datetime(transdatetime_str, errors='coerce')
                    if pd.isna(trans_datetime):
                        continue
                    
                    hour = trans_datetime.hour
                except:
                    continue
                
                # Если есть target=1, используем его как 100% вероятность (это быстрее)
                target = row.get('target', 0)
                if target == 1:
                    hour_probabilities[hour].append(1.0)
                    hour_counts[hour] += 1
                    processed_count += 1
                    continue
                
                # Для target=0 вычисляем вероятность через модель (но не для всех, чтобы не было медленно)
                # Берем каждую 5-ю транзакцию для вычисления
                if processed_count % 5 == 0:
                    try:
                        # Формируем данные транзакции для модели
                        transaction_data = {
                            'cst_dim_id': int(row.get('cst_dim_id', 0)),
                            'amount': float(row.get('amount', 0)),
                            'direction': str(row.get('direction', '')),
                            'transdatetime': transdatetime_str
                        }
                        
                        # Вычисляем вероятность мошенничества
                        fraud_result = enhanced_model.predict_fraud_enhanced(transaction_data, return_shap=False)
                        fraud_probability = fraud_result.get('fraud_probability', 0.0)
                        hour_probabilities[hour].append(fraud_probability)
                    except Exception as e:
                        # Если не удалось вычислить, используем низкую вероятность
                        hour_probabilities[hour].append(0.1)
                else:
                    # Для остальных используем среднее значение из уже вычисленных
                    if hour in hour_probabilities and len(hour_probabilities[hour]) > 0:
                        avg_prob = sum(hour_probabilities[hour]) / len(hour_probabilities[hour])
                        hour_probabilities[hour].append(avg_prob)
                    else:
                        hour_probabilities[hour].append(0.1)
                
                hour_counts[hour] += 1
                processed_count += 1
                    
            except Exception as e:
                print(f"Ошибка обработки транзакции {idx}: {e}")
                continue
        
        # Вычисляем средние вероятности по часам
        timeline_data = []
        for hour in range(24):
            if hour in hour_probabilities and len(hour_probabilities[hour]) > 0:
                avg_prob = sum(hour_probabilities[hour]) / len(hour_probabilities[hour])
                timeline_data.append({
                    'hour': hour,
                    'hour_label': f"{hour:02d}:00",
                    'probability': round(avg_prob, 3),
                    'count': hour_counts.get(hour, len(hour_probabilities[hour]))
                })
            else:
                # Если нет данных для этого часа, используем 0
                timeline_data.append({
                    'hour': hour,
                    'hour_label': f"{hour:02d}:00",
                    'probability': 0.0,
                    'count': 0
                })
        
        # Сортируем по часам
        timeline_data.sort(key=lambda x: x['hour'])
        
        return jsonify({
            'success': True,
            'timeline': timeline_data,
            'total_transactions': processed_count,
            'date_range': 'Последние 7 дней'
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Ошибка получения данных: {str(e)}'}), 500

# Удалить документ
@app.route('/api/confluence-docs/<doc_id>', methods=['DELETE'])
def api_confluence_doc_delete(doc_id):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        import json
        doc_file = os.path.join('confluence_docs', f'{doc_id}.json')
        
        # Удаляем файл документа
        if os.path.exists(doc_file):
            os.remove(doc_file)
        
        # Удаляем из индекса
        index_file = os.path.join('confluence_docs', 'index.json')
        if os.path.exists(index_file):
            with open(index_file, 'r', encoding='utf-8') as f:
                documents = json.load(f)
            documents = [d for d in documents if d.get('id') != doc_id]
            with open(index_file, 'w', encoding='utf-8') as f:
                json.dump(documents, f, ensure_ascii=False, indent=2)
        
        return jsonify({
            'success': True,
            'message': 'Документ успешно удален'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Скачивание файлов
@app.route('/uploads/<filename>')
def download_file(filename):
    """Скачивание файлов из папки uploads"""
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        file_path = os.path.join('uploads', filename)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            return send_file(file_path, as_attachment=True)
        else:
            return jsonify({'error': 'Файл не найден'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Комплексный анализ документа (все функции сразу)
@app.route('/api/ai-business-analyst/analyze', methods=['POST'])
def api_ba_analyze():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        document_text = data.get('document_text', '')
        document_type = data.get('document_type')
        context = data.get('context', {})
        generate_documents = data.get('generate_documents', False)
        
        if not document_text:
            return jsonify({'error': 'Текст документа не предоставлен'}), 400
        
        # 1. Анализ документа
        analysis = document_analyzer.analyze_document(document_text, document_type)
        
        # 2. Извлечение требований
        requirements = requirement_extractor.extract_requirements(document_text, context)
        gaps = requirement_extractor.identify_gaps(requirements, analysis)
        requirements['gaps'] = gaps
        
        result = {
            'analysis': analysis,
            'requirements': requirements,
            'success': True
        }
        
        # 3. Генерация документов (если запрошено)
        if generate_documents:
            # BRD
            try:
                brd = document_generator.generate_brd(analysis, context)
                # Ensure BRD is properly formatted
                if isinstance(brd, dict):
                    if 'error' in brd:
                        result['brd_error'] = brd.get('error', 'Ошибка генерации BRD')
                    else:
                        result['brd'] = brd
                else:
                    result['brd'] = {'content': str(brd), 'type': 'BRD'}
            except Exception as e:
                import traceback
                traceback.print_exc()
                result['brd_error'] = str(e)
            
            # User Stories (если есть функциональные требования)
            functional_reqs = requirements.get('functional', [])
            if functional_reqs:
                user_stories = document_generator.generate_user_stories(
                    functional_reqs[:5],  # Первые 5 требований
                    context.get('roles', [])
                )
                result['user_stories'] = user_stories
        
        return jsonify(result)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# Загрузка и обработка файлов
@app.route('/api/ai-business-analyst/upload-file', methods=['POST'])
def api_ba_upload_file():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Файл не предоставлен'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'Файл не выбран'}), 400
        
        filename = secure_filename(file.filename)
        file_ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
        
        # Извлекаем текст из файла
        text = ''
        if file_ext == 'txt':
            text = file.read().decode('utf-8', errors='ignore')
        elif file_ext == 'pdf':
            try:
                try:
                    import PyPDF2  # type: ignore # noqa: F401
                except ImportError:
                    return jsonify({'error': 'Библиотека PyPDF2 не установлена. Установите: pip install PyPDF2'}), 500
                pdf_reader = PyPDF2.PdfReader(file)
                text = ''
                for page in pdf_reader.pages:
                    text += page.extract_text() + '\n'
            except Exception as e:
                return jsonify({'error': f'Ошибка чтения PDF: {str(e)}'}), 500
        elif file_ext in ['doc', 'docx']:
            try:
                try:
                    from docx import Document  # type: ignore
                except ImportError:
                    return jsonify({'error': 'Библиотека python-docx не установлена. Установите: pip install python-docx'}), 500
                doc = Document(file)
                text = '\n'.join([paragraph.text for paragraph in doc.paragraphs])
            except Exception as e:
                return jsonify({'error': f'Ошибка чтения DOCX: {str(e)}'}), 500
        else:
            return jsonify({'error': f'Неподдерживаемый формат файла: {file_ext}'}), 400
        
        if not text.strip():
            return jsonify({'error': 'Не удалось извлечь текст из файла'}), 400
        
        return jsonify({
            'text': text,
            'filename': filename,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Чат-бот для бизнес-аналитика
@app.route('/api/ai-business-analyst/chat', methods=['POST'])
def api_ba_chat():
    """Чат-бот для диалога с бизнес-аналитиком"""
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        message = data.get('message', '')
        chat_history = data.get('chat_history', [])
        context = data.get('context', {})
        
        if not message:
            return jsonify({'error': 'Сообщение не предоставлено'}), 400
        
        # Формируем промпт с учетом истории чата
        system_prompt = """Ты AI-Business Analyst, работающий в банке. Твоя роль - помогать сотрудникам:
- Разбирать входящие документы
- Извлекать требования
- Находить пробелы
- Формировать структурированную документацию
- Готовить материалы для Confluence

Отвечай дружелюбно, профессионально и структурированно. Если пользователь загружает документ или описывает задачу, проведи анализ и предложи следующие шаги."""
        
        # Формируем контекст из истории
        conversation_context = ""
        if chat_history:
            conversation_context = "\n\nКонтекст предыдущего разговора:\n"
            for msg in chat_history[-5:]:  # Последние 5 сообщений
                role = msg.get('role', 'user')
                content = msg.get('content', '')
                conversation_context += f"{'Пользователь' if role == 'user' else 'Ассистент'}: {content}\n"
        
        # Добавляем контекст пользователя
        user_context = ""
        if context:
            if context.get('customer'):
                user_context += f"\nЗаказчик: {context['customer']}\n"
            if context.get('purpose'):
                user_context += f"Цель: {context['purpose']}\n"
            if context.get('for_confluence'):
                user_context += "Результат должен быть готов для Confluence\n"
        
        # Определяем, что нужно сделать
        message_lower = message.lower()
        is_document = any(keyword in message_lower for keyword in ['документ', 'файл', 'загрузить', 'анализ', 'разобрать'])
        is_requirement = any(keyword in message_lower for keyword in ['требование', 'требования', 'извлечь'])
        is_generate = any(keyword in message_lower for keyword in ['создать', 'сгенерировать', 'brd', 'use case', 'user story'])
        
        prompt = f"""{system_prompt}{user_context}{conversation_context}

Текущий запрос пользователя: {message}

"""
        
        # Если это запрос на анализ документа
        if is_document:
            prompt += """Проведи анализ и предоставь:
1. Тип документа
2. Цель
3. Требования
4. Бизнес-правила
5. Метрики
6. Ограничения
7. Противоречия и пробелы
8. Вопросы для уточнения"""
        elif is_requirement:
            prompt += """Извлеки требования и структурируй их по категориям:
- Функциональные требования
- Нефункциональные требования
- Бизнес-требования
- Технические требования"""
        elif is_generate:
            prompt += """Сгенерируй запрошенный документ (BRD, Use Case, User Stories) в структурированном формате Markdown."""
        else:
            prompt += """Помоги пользователю с его запросом. Если нужно, задай уточняющие вопросы."""
        
        # Генерируем ответ
        response = model.generate_content(prompt)
        response_text = response.text if hasattr(response, 'text') else str(response)
        
        # Если в сообщении есть текст документа, проводим анализ
        if len(message) > 500 and is_document:
            try:
                analysis = document_analyzer.analyze_document(message)
                if analysis and not analysis.get('error'):
                    response_text += "\n\n---\n\n## Детальный анализ:\n\n"
                    response_text += analysis.get('raw_analysis', '')
            except:
                pass
        
        return jsonify({
            'response': response_text,
            'success': True
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

# Старый endpoint для обратной совместимости
@app.route('/api/ai-business-analyst', methods=['POST'])
def api_ai_business_analyst():
    """Старый endpoint, перенаправляет на комплексный анализ"""
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.json
    query = data.get('query', '')
    
    if not query:
        return jsonify({'error': 'Запрос не предоставлен'}), 400
    
    # Используем новый функционал анализа
    try:
        analysis = document_analyzer.analyze_document(query)
        return jsonify({
            'result': analysis.get('raw_analysis', 'Анализ выполнен'),
            'analysis': analysis,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ==================== AI-Code Review Assistant API Endpoints ====================

# Загрузка архитектуры проекта
@app.route('/api/ai-code-review/upload-architecture', methods=['POST'])
def api_code_review_upload_architecture():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Файл не предоставлен'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'Файл не выбран'}), 400
        
        # Сохраняем файл временно
        filename = secure_filename(file.filename)
        upload_dir = 'uploads/architecture'
        os.makedirs(upload_dir, exist_ok=True)
        file_path = os.path.join(upload_dir, filename)
        file.save(file_path)
        
        # Определяем тип файла
        file_type = request.form.get('file_type') or filename.rsplit('.', 1)[1].lower() if '.' in filename else 'txt'
        
        # Загружаем архитектуру
        architecture_data = architecture_loader.load_architecture(file_path, file_type)
        
        # Анализируем архитектуру
        result = {
            'file_path': architecture_data.get('file_path'),
            'file_type': architecture_data.get('file_type'),
            'success': architecture_data.get('success', False)
        }
        
        if architecture_data.get('error'):
            result['error'] = architecture_data.get('error')
        elif architecture_data.get('success'):
            try:
                analysis = architecture_loader.analyze_architecture(architecture_data)
                if analysis.get('error'):
                    result['analysis_error'] = analysis.get('error')
                elif analysis.get('analysis'):
                    result['analysis'] = analysis.get('analysis')
                else:
                    result['analysis_error'] = 'Анализ выполнен, но результат пуст'
            except Exception as e:
                result['analysis_error'] = f'Ошибка при анализе: {str(e)}'
        
        # Удаляем временный файл
        try:
            os.remove(file_path)
        except:
            pass
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Анализ кода (отдельный файл)
@app.route('/api/ai-code-review/analyze-code', methods=['POST'])
def api_code_review_analyze_code():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        code = data.get('code', '')
        language = data.get('language', '')
        file_path = data.get('file_path')
        
        if not code:
            return jsonify({'error': 'Код не предоставлен'}), 400
        
        # Автоматически определяем язык, если не указан или указан как "Auto"/"Unknown"
        if not language or language in ['Auto', 'Unknown', 'Другой']:
            detected_language = language_detector.detect_language(code, file_path)
            language = detected_language if detected_language != 'Unknown' else 'Python'  # Fallback на Python
        else:
            # Если язык указан, проверяем его корректность
            detected_language = language_detector.detect_language(code, file_path)
            # Если определенный язык отличается от указанного, используем определенный
            if detected_language != 'Unknown' and detected_language != language:
                language = detected_language  # Используем автоматически определенный
        
        analysis = code_analyzer.analyze_code(code, language, file_path)
        analysis['type'] = 'code'
        analysis['detected_language'] = language  # Добавляем определенный язык в ответ
        
        # Генерируем рекомендации
        if analysis.get('success'):
            recommendations = review_generator.generate_recommendations(analysis, 'file')
            analysis['recommendations'] = recommendations
        
        return jsonify(analysis)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Анализ diff
@app.route('/api/ai-code-review/analyze-diff', methods=['POST'])
def api_code_review_analyze_diff():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        diff_text = data.get('diff', '')
        base_code = data.get('base_code')
        new_code = data.get('new_code')
        
        if not diff_text:
            return jsonify({'error': 'Diff не предоставлен'}), 400
        
        analysis = code_analyzer.analyze_diff(diff_text, base_code, new_code)
        analysis['type'] = 'diff'
        
        return jsonify(analysis)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Анализ всего проекта
@app.route('/api/ai-code-review/analyze-project', methods=['POST'])
def api_code_review_analyze_project():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        files = data.get('files', [])  # [{'path': '...', 'code': '...', 'language': '...'}]
        architecture = data.get('architecture')
        
        if not files:
            return jsonify({'error': 'Файлы не предоставлены'}), 400
        
        # Автоматически определяем язык для каждого файла, если не указан
        for file_info in files:
            if not file_info.get('language') or file_info.get('language') in ['Auto', 'Unknown', 'Другой']:
                detected_language = language_detector.detect_language(
                    file_info.get('code', ''),
                    file_info.get('path')
                )
                file_info['language'] = detected_language if detected_language != 'Unknown' else 'Unknown'
        
        analysis = code_analyzer.analyze_project(files, architecture)
        analysis['type'] = 'project'
        analysis['files_with_languages'] = [
            {'path': f.get('path', 'unknown'), 'language': f.get('language', 'unknown')}
            for f in files
        ]
        
        # Генерируем рекомендации
        if analysis.get('success'):
            recommendations = review_generator.generate_recommendations(analysis, 'project')
            analysis['recommendations'] = recommendations
        
        return jsonify(analysis)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Генерация итогового отчёта
@app.route('/api/ai-code-review/generate-report', methods=['POST'])
def api_code_review_generate_report():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        analyses = data.get('analyses', [])
        merge_recommendation = data.get('merge_recommendation')
        mr_info = data.get('mr_info')
        
        if not analyses:
            return jsonify({'error': 'Анализы не предоставлены'}), 400
        
        report = code_review_report_generator.generate_report(
            analyses, merge_recommendation, mr_info
        )
        
        return jsonify(report)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Обновление статуса MR
@app.route('/api/ai-code-review/mr/update-status', methods=['POST'])
def api_code_review_update_mr_status():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        mr_id = data.get('mr_id')
        status = data.get('status')
        labels = data.get('labels', [])
        review_data = data.get('review_data')
        
        if not mr_id or not status:
            return jsonify({'error': 'mr_id и status обязательны'}), 400
        
        result = gitlab_integration.update_mr_status(mr_id, status, labels, review_data)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Получение статуса MR
@app.route('/api/ai-code-review/mr/<mr_id>', methods=['GET'])
def api_code_review_get_mr(mr_id):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        result = gitlab_integration.get_mr_status(mr_id)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Список MR
@app.route('/api/ai-code-review/mr/list', methods=['GET'])
def api_code_review_list_mrs():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        status_filter = request.args.get('status')
        mrs = gitlab_integration.list_mrs(status_filter)
        return jsonify({'mrs': mrs, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Обучающие подсказки
@app.route('/api/ai-code-review/educational/hints', methods=['POST'])
def api_code_review_educational_hints():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        issue = data.get('issue', '')
        developer_level = data.get('developer_level', 'junior')
        
        if not issue:
            return jsonify({'error': 'Проблема не указана'}), 400
        
        hints = review_generator.generate_educational_hints(issue, developer_level)
        return jsonify(hints)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Объяснение проблемы
@app.route('/api/ai-code-review/educational/explain', methods=['POST'])
def api_code_review_educational_explain():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        issue = data.get('issue', '')
        code_snippet = data.get('code_snippet', '')
        developer_level = data.get('developer_level', 'junior')
        
        if not issue:
            return jsonify({'error': 'Проблема не указана'}), 400
        
        explanation = educational_support.generate_explanation(issue, code_snippet, developer_level)
        return jsonify(explanation)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Статистика разработчика
@app.route('/api/ai-code-review/educational/stats/<developer_id>', methods=['GET'])
def api_code_review_educational_stats(developer_id):
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        stats = educational_support.get_developer_stats(developer_id)
        return jsonify(stats)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Отслеживание прогресса
@app.route('/api/ai-code-review/educational/track-progress', methods=['POST'])
def api_code_review_educational_track_progress():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        developer_id = data.get('developer_id')
        issue_type = data.get('issue_type', 'unknown')
        resolved = data.get('resolved', False)
        
        if not developer_id:
            return jsonify({'error': 'developer_id обязателен'}), 400
        
        result = educational_support.track_developer_progress(developer_id, issue_type, resolved)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Частые проблемы
@app.route('/api/ai-code-review/educational/common-issues', methods=['GET'])
def api_code_review_educational_common_issues():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        limit = request.args.get('limit', 10, type=int)
        issues = educational_support.get_common_issues(limit)
        return jsonify({'issues': issues, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Старый endpoint для обратной совместимости
@app.route('/api/ai-code-review', methods=['POST'])
def api_ai_code_review():
    """Старый endpoint, перенаправляет на анализ кода"""
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.json
    code = data.get('code', '')
    language = data.get('language', 'Python')
    
    if not code:
        return jsonify({'error': 'Код не предоставлен'}), 400
    
    try:
        analysis = code_analyzer.analyze_code(code, language)
        return jsonify({
            'result': analysis.get('analysis', ''),
            'analysis': analysis,
            'success': True
        })
    except Exception as e:
        error_message = str(e)
        if 'API key' in error_message or 'authentication' in error_message.lower():
            return jsonify({'error': 'Ошибка аутентификации с Gemini API. Проверьте ваш API ключ.'}), 500
        return jsonify({'error': f'Ошибка при обработке запроса: {error_message}'}), 500

# ==================== AI Assistant API Endpoints ====================

# Получить приветствие для страницы
@app.route('/api/ai-assistant/greeting', methods=['GET'])
def api_ai_assistant_greeting():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        page_name = request.args.get('page', 'index')
        assistant = get_assistant()
        greeting = assistant.get_greeting(page_name)
        return jsonify({'greeting': greeting, 'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Задать вопрос ассистенту
@app.route('/api/ai-assistant/ask', methods=['POST'])
def api_ai_assistant_ask():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.json
        page_name = data.get('page', 'index')
        question = data.get('question', '')
        conversation_history = data.get('conversation_history', [])
        user_id = session.get('username', 'default')
        
        if not question:
            return jsonify({'error': 'Вопрос не предоставлен'}), 400
        
        assistant = get_assistant()
        answer = assistant.ask(page_name, question, user_id, conversation_history)
        
        return jsonify({
            'answer': answer,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Получить путеводитель по функции
@app.route('/api/ai-assistant/guide', methods=['GET'])
def api_ai_assistant_guide():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        page_name = request.args.get('page', 'index')
        feature_name = request.args.get('feature')
        
        assistant = get_assistant()
        guide = assistant.get_feature_guide(page_name, feature_name)
        
        return jsonify({
            'guide': guide,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Получить контекст страницы
@app.route('/api/ai-assistant/context', methods=['GET'])
def api_ai_assistant_context():
    if 'username' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        page_name = request.args.get('page', 'index')
        assistant = get_assistant()
        context = assistant.get_page_context(page_name)
        
        return jsonify({
            'context': context,
            'success': True
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)

