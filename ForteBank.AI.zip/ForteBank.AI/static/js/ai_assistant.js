// AI Assistant JavaScript
let aiAssistantOpen = false;
let currentPage = 'index';
let conversationHistory = [];

// Определение текущей страницы
function detectCurrentPage() {
    const path = window.location.pathname;
    const pageMap = {
        '/': 'index',
        '/smartantifraud': 'smartantifraud',
        '/ai-procure': 'ai_procure',
        '/ai-scrum': 'ai_scrum',
        '/ai-business-analyst': 'ai_business_analyst',
        '/ai-code-review': 'ai_code_review'
    };
    
    return pageMap[path] || 'index';
}

// Переключение ассистента
function toggleAIAssistant() {
    const panel = document.getElementById('aiAssistantPanel');
    const badge = document.getElementById('aiAssistantBadge');
    
    aiAssistantOpen = !aiAssistantOpen;
    
    if (aiAssistantOpen) {
        panel.classList.add('active');
        badge.style.display = 'none';
        loadAIAssistantGreeting();
    } else {
        panel.classList.remove('active');
    }
}

// Загрузка приветствия
function loadAIAssistantGreeting() {
    currentPage = detectCurrentPage();
    const content = document.getElementById('aiAssistantContent');
    
    content.innerHTML = '<div class="ai-assistant-loading">Загрузка...</div>';
    
    fetch(`/api/ai-assistant/greeting?page=${currentPage}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayMessage('assistant', data.greeting);
                addQuickActions();
            } else {
                displayMessage('assistant', 'Привет! Я твой AI-ассистент. Чем могу помочь?');
            }
        })
        .catch(error => {
            displayMessage('assistant', 'Привет! Я твой AI-ассистент. Чем могу помочь?');
        });
}

// Добавление быстрых действий
function addQuickActions() {
    const content = document.getElementById('aiAssistantContent');
    const quickActions = document.createElement('div');
    quickActions.className = 'ai-assistant-quick-actions';
    
    const actions = getQuickActionsForPage(currentPage);
    
    actions.forEach(action => {
        const button = document.createElement('button');
        button.className = 'ai-assistant-quick-action';
        button.textContent = action.text;
        button.onclick = () => sendQuickQuestion(action.question);
        quickActions.appendChild(button);
    });
    
    content.appendChild(quickActions);
}

// Получение быстрых действий для страницы
function getQuickActionsForPage(page) {
    const actions = {
        'index': [
            { text: 'Что такое SmartAntiFraud?', question: 'Что такое SmartAntiFraud и для чего он нужен?' },
            { text: 'Как работает AI-Procure?', question: 'Как работает модуль AI-Procure?' },
            { text: 'Что может AI-Scrum Master?', question: 'Что может делать AI-Scrum Master?' }
        ],
        'smartantifraud': [
            { text: 'Как провести анализ?', question: 'Как провести анализ транзакции на мошенничество?' },
            { text: 'Что такое метрики модели?', question: 'Что означают метрики модели и как их интерпретировать?' },
            { text: 'Как настроить пороги?', question: 'Как настроить пороги риска для разных сегментов?' }
        ],
        'ai_procure': [
            { text: 'Как извлечь параметры?', question: 'Как извлечь параметры тендера?' },
            { text: 'Как подобрать поставщиков?', question: 'Как подобрать подходящих поставщиков?' }
        ],
        'ai_scrum': [
            { text: 'Как создать проект?', question: 'Как создать новый проект?' },
            { text: 'Как создать задачи?', question: 'Как создать задачи из текста?' }
        ],
        'ai_business_analyst': [
            { text: 'Как анализировать документы?', question: 'Как проанализировать документ?' },
            { text: 'Как извлечь требования?', question: 'Как извлечь требования из документа?' }
        ],
        'ai_code_review': [
            { text: 'Как провести ревью?', question: 'Как провести ревью кода?' },
            { text: 'Как загрузить архитектуру?', question: 'Как загрузить архитектуру проекта?' }
        ]
    };
    
    return actions[page] || [];
}

// Отправка быстрого вопроса
function sendQuickQuestion(question) {
    const input = document.getElementById('aiAssistantInput');
    input.value = question;
    sendAIAssistantMessage();
}

// Отправка сообщения
function sendAIAssistantMessage() {
    const input = document.getElementById('aiAssistantInput');
    const question = input.value.trim();
    
    if (!question) return;
    
    // Очистка input
    input.value = '';
    
    // Отображение сообщения пользователя
    displayMessage('user', question);
    
    // Добавление в историю
    conversationHistory.push({
        role: 'user',
        content: question
    });
    
    // Показ индикатора печати
    showTypingIndicator();
    
    // Отправка запроса
    fetch('/api/ai-assistant/ask', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            page: currentPage,
            question: question,
            conversation_history: conversationHistory
        })
    })
    .then(response => response.json())
    .then(data => {
        hideTypingIndicator();
        
        if (data.success) {
            displayMessage('assistant', data.answer);
            
            // Добавление в историю
            conversationHistory.push({
                role: 'assistant',
                content: data.answer
            });
            
            // Ограничение истории (последние 10 сообщений)
            if (conversationHistory.length > 10) {
                conversationHistory = conversationHistory.slice(-10);
            }
        } else {
            displayMessage('assistant', 'Извините, произошла ошибка. Попробуйте позже.');
        }
    })
    .catch(error => {
        hideTypingIndicator();
        displayMessage('assistant', 'Извините, произошла ошибка при отправке запроса.');
    });
}

// Отображение сообщения
function displayMessage(role, content) {
    const contentDiv = document.getElementById('aiAssistantContent');
    const messageDiv = document.createElement('div');
    messageDiv.className = `ai-assistant-message ${role}`;
    
    const bubble = document.createElement('div');
    bubble.className = 'ai-assistant-message-bubble';
    
    // Преобразование markdown в HTML (простая версия)
    bubble.innerHTML = formatMessage(content);
    
    messageDiv.appendChild(bubble);
    contentDiv.appendChild(messageDiv);
    
    // Прокрутка вниз
    contentDiv.scrollTop = contentDiv.scrollHeight;
}

// Форматирование сообщения (простой markdown)
function formatMessage(text) {
    // Замена **текст** на <strong>текст</strong>
    text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    // Замена *текст* на <em>текст</em>
    text = text.replace(/\*(.*?)\*/g, '<em>$1</em>');
    
    // Замена заголовков
    text = text.replace(/^### (.*$)/gm, '<h5>$1</h5>');
    text = text.replace(/^## (.*$)/gm, '<h4>$1</h4>');
    text = text.replace(/^# (.*$)/gm, '<h4>$1</h4>');
    
    // Замена списков
    text = text.replace(/^\- (.*$)/gm, '<li>$1</li>');
    text = text.replace(/^(\d+)\. (.*$)/gm, '<li>$2</li>');
    
    // Обёртка списков
    text = text.replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>');
    
    // Замена переносов строк на <br>
    text = text.replace(/\n/g, '<br>');
    
    // Замена кода
    text = text.replace(/`(.*?)`/g, '<code>$1</code>');
    
    return text;
}

// Показ индикатора печати
function showTypingIndicator() {
    const contentDiv = document.getElementById('aiAssistantContent');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'ai-assistant-message assistant';
    typingDiv.id = 'typingIndicator';
    
    const bubble = document.createElement('div');
    bubble.className = 'ai-assistant-message-bubble';
    bubble.innerHTML = '<div class="ai-assistant-typing"><span></span><span></span><span></span></div>';
    
    typingDiv.appendChild(bubble);
    contentDiv.appendChild(typingDiv);
    contentDiv.scrollTop = contentDiv.scrollHeight;
}

// Скрытие индикатора печати
function hideTypingIndicator() {
    const typingDiv = document.getElementById('typingIndicator');
    if (typingDiv) {
        typingDiv.remove();
    }
}

// Обработка нажатия Enter
function handleAIAssistantKeyPress(event) {
    if (event.key === 'Enter') {
        sendAIAssistantMessage();
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    currentPage = detectCurrentPage();
    
    // Автоматическое открытие при первом посещении (можно настроить)
    // const hasSeenAssistant = localStorage.getItem('aiAssistantSeen');
    // if (!hasSeenAssistant) {
    //     setTimeout(() => {
    //         toggleAIAssistant();
    //         localStorage.setItem('aiAssistantSeen', 'true');
    //     }, 2000);
    // }
});

