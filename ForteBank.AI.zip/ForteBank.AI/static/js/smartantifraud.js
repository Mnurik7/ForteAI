// SmartAntiFraud Chat Interface
let chatHistory = [];
let currentDialogId = null;

// Инициализация
document.addEventListener('DOMContentLoaded', function() {
    initializeChat();
    setupEventListeners();
});

function initializeChat() {
    const chatMessages = document.getElementById('chatMessages');
    const emptyState = document.getElementById('emptyState');
    
    if (chatHistory.length === 0 && emptyState) {
        emptyState.style.display = 'flex';
    }
}

function setupEventListeners() {
    const chatInput = document.getElementById('chatInput');
    const sendBtn = document.getElementById('sendBtn');
    
    if (chatInput) {
        chatInput.addEventListener('keydown', handleInputKeydown);
        chatInput.addEventListener('input', function() {
            autoResizeTextarea(this);
        });
    }
    
    if (sendBtn) {
        sendBtn.addEventListener('click', sendMessage);
    }
}

// Обработка клавиатуры
function handleInputKeydown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
}

// Автоматическое изменение размера textarea
function autoResizeTextarea(textarea) {
    if (!textarea || typeof textarea !== 'object' || !textarea.style) {
        return;
    }
    
    try {
        textarea.style.height = 'auto';
        const newHeight = Math.min(textarea.scrollHeight || 44, 120);
        textarea.style.height = newHeight + 'px';
    } catch (error) {
        console.warn('Ошибка изменения размера textarea:', error);
    }
}

// Отправка сообщения
async function sendMessage() {
    const chatInput = document.getElementById('chatInput');
    const message = chatInput.value.trim();
    
    if (!message) return;
    
    // Скрываем пустое состояние
    const emptyState = document.getElementById('emptyState');
    if (emptyState) {
        emptyState.style.display = 'none';
    }
    
    // Добавляем сообщение пользователя
    addMessage('user', message);
    
    // Очищаем поле ввода
    chatInput.value = '';
    chatInput.style.height = 'auto';
    
    // Отключаем кнопку отправки
    const sendBtn = document.getElementById('sendBtn');
    if (sendBtn) {
        sendBtn.disabled = true;
    }
    
    // Показываем индикатор загрузки
    const loadingId = addMessage('assistant', '', true);
    
    try {
        // Определяем тип запроса и отправляем на соответствующий API
        const response = await processUserMessage(message);
        
        // Удаляем индикатор загрузки
        removeMessage(loadingId);
        
        // Добавляем ответ ассистента
        addMessage('assistant', response, false, response.data);
        
    } catch (error) {
        removeMessage(loadingId);
        let errorMessage = 'Произошла неизвестная ошибка';
        if (error) {
            if (typeof error === 'string') {
                errorMessage = error;
            } else if (error.message) {
                errorMessage = String(error.message);
            } else if (typeof error === 'object') {
                errorMessage = JSON.stringify(error);
            } else {
                errorMessage = String(error);
            }
        }
        addMessage('assistant', `Ошибка: ${errorMessage}`, false);
    } finally {
        if (sendBtn) {
            sendBtn.disabled = false;
        }
    }
}

// Обработка сообщения пользователя
async function processUserMessage(message) {
    const lowerMessage = message.toLowerCase();
    
    // Определяем тип запроса
    if (lowerMessage.includes('первый перевод') || lowerMessage.includes('первая транзакция') ||
        lowerMessage.includes('самый первый перевод') || lowerMessage.includes('самая первая транзакция') ||
        lowerMessage.includes('самый ранний перевод') || lowerMessage.includes('самая ранняя транзакция')) {
        return await getFirstTransaction(message);
    } else if (lowerMessage.includes('последний перевод') || lowerMessage.includes('последние переводы') || 
        lowerMessage.includes('последняя транзакция') || lowerMessage.includes('последние транзакции') ||
        lowerMessage.includes('покажи перевод') || lowerMessage.includes('покажи переводы') ||
        lowerMessage.includes('покажи транзакции') || lowerMessage.includes('покажи транзакцию')) {
        return await getLastTransactions(message);
    } else if (lowerMessage.includes('проверить перевод') || lowerMessage.includes('анализ') || lowerMessage.match(/\d+/)) {
        return await analyzeTransaction(message);
    } else if (lowerMessage.includes('подозрительные') || lowerMessage.includes('suspicious')) {
        return await getSuspiciousTransactions();
    } else if (lowerMessage.includes('метрики') || lowerMessage.includes('metrics')) {
        return await getModelMetrics();
    } else if (lowerMessage.includes('объяснить') || lowerMessage.includes('explain')) {
        return await explainDecision(message);
    } else if (lowerMessage.includes('порог') || lowerMessage.includes('threshold')) {
        return await getThresholds();
    } else if (lowerMessage.includes('история') || lowerMessage.includes('history')) {
        return await getClientHistory(message);
    } else if (lowerMessage.includes('мониторинг') || lowerMessage.includes('monitoring')) {
        return await getMonitoring();
    } else {
        // Общий AI анализ через deep endpoint
        return await deepAnalysis(message);
    }
}

// Анализ транзакции
async function analyzeTransaction(message) {
    let transactionData = {};
    
    // Пробуем распарсить как JSON
    try {
        transactionData = JSON.parse(message);
    } catch {
        // Если не JSON, пробуем извлечь ID или создать объект из текста
        const numbers = message.match(/\d+/);
        if (numbers) {
            transactionData = { cst_dim_id: parseInt(numbers[0]) };
        } else {
            transactionData = { description: message };
        }
    }
    
    const response = await fetch('/api/smartantifraud/quick', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(transactionData)
    });
    
    const data = await response.json();
    
    if (data.error) {
        throw new Error(data.error);
    }
    
    return formatAnalysisResponse(data);
}

// Глубокий AI анализ
async function deepAnalysis(message) {
    const response = await fetch('/api/smartantifraud/deep', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transaction_data: message })
    });
    
    const data = await response.json();
    
    if (data.error) {
        throw new Error(data.error);
    }
    
    // Безопасное извлечение текста результата
    let resultText = 'Анализ выполнен';
    if (data.result) {
        if (typeof data.result === 'string') {
            resultText = data.result;
        } else if (typeof data.result === 'object') {
            // Если это объект, пытаемся извлечь текстовое представление
            resultText = JSON.stringify(data.result, null, 2);
        } else {
            resultText = String(data.result);
        }
    }
    
    return {
        text: resultText,
        data: null
    };
}

// Получить первый перевод
async function getFirstTransaction(message) {
    // Извлекаем ID клиента из сообщения
    const clientIdMatch = message.match(/клиент[а]?\s*(\d+)/i);
    const clientId = clientIdMatch ? parseInt(clientIdMatch[1]) : null;
    
    let url = `/api/smartantifraud/first-transaction`;
    if (clientId) {
        url += `?client_id=${clientId}`;
    }
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.error) {
        throw new Error(data.error);
    }
    
    return formatFirstTransactionResponse(data);
}

// Получить последние переводы
async function getLastTransactions(message) {
    // Извлекаем количество и ID клиента из сообщения
    const limitMatch = message.match(/(\d+)\s*(перевод|транзакц)/i);
    const limit = limitMatch ? parseInt(limitMatch[1]) : 10;
    
    const clientIdMatch = message.match(/клиент[а]?\s*(\d+)/i);
    const clientId = clientIdMatch ? parseInt(clientIdMatch[1]) : null;
    
    let url = `/api/smartantifraud/last-transactions?limit=${limit}`;
    if (clientId) {
        url += `&client_id=${clientId}`;
    }
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.error) {
        throw new Error(data.error);
    }
    
    return formatLastTransactionsResponse(data);
}

// Получить подозрительные транзакции
async function getSuspiciousTransactions() {
    const response = await fetch('/api/smartantifraud/suspicious?limit=10');
    const data = await response.json();
    
    if (data.error) {
        throw new Error(data.error);
    }
    
    return formatSuspiciousResponse(data);
}

// Получить метрики модели
async function getModelMetrics() {
    const response = await fetch('/api/smartantifraud/model/metrics');
    const data = await response.json();
    
    if (data.error) {
        throw new Error(data.error);
    }
    
    return formatMetricsResponse(data);
}

// Объяснить решение
async function explainDecision(message) {
    // Извлекаем данные транзакции из сообщения
    let transactionData = {};
    try {
        transactionData = JSON.parse(message);
    } catch {
        transactionData = { description: message };
    }
    
    const response = await fetch('/api/smartantifraud/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(transactionData)
    });
    
    const data = await response.json();
    
    if (data.error) {
        throw new Error(data.error);
    }
    
    return formatExplainResponse(data);
}

// Получить пороги
async function getThresholds() {
    const response = await fetch('/api/smartantifraud/thresholds');
    const data = await response.json();
    
    if (data.error) {
        throw new Error(data.error);
    }
    
    return formatThresholdsResponse(data);
}

// Получить историю клиента
async function getClientHistory(message) {
    const clientId = message.match(/\d+/)?.[0];
    if (!clientId) {
        return { text: 'Пожалуйста, укажите ID клиента', data: null };
    }
    
    const response = await fetch(`/api/smartantifraud/client-history/${clientId}`);
    const data = await response.json();
    
    if (data.error) {
        throw new Error(data.error);
    }
    
    return formatHistoryResponse(data);
}

// Получить мониторинг
async function getMonitoring() {
    const response = await fetch('/api/smartantifraud/monitoring/drift');
    const data = await response.json();
    
    if (data.error) {
        throw new Error(data.error);
    }
    
    return formatMonitoringResponse(data);
}

// Форматирование ответов
function formatAnalysisResponse(data) {
    const riskLevel = data.risk_level || 'unknown';
    const fraudProb = ((data.fraud_probability || data.risk_score / 100) * 100).toFixed(1);
    const riskScore = data.risk_score || 0;
    
    let recommendation = 'Проверить';
    let recommendationClass = 'review';
    if (data.is_fraud || riskScore >= 70) {
        recommendation = 'Блокировать';
        recommendationClass = 'block';
    } else if (riskScore < 40) {
        recommendation = 'Разрешить';
        recommendationClass = 'allow';
    }
    
    const reasons = data.reasons || ['Анализ выполнен'];
    
    const riskLevelStr = typeof riskLevel === 'string' ? riskLevel : 'unknown';
    const recommendationStr = typeof recommendation === 'string' ? recommendation : 'Проверить';
    
    return {
        text: `**Анализ транзакции**\n\nУровень риска: ${riskLevelStr.toUpperCase()}\nВероятность мошенничества: ${fraudProb}%\nОценка риска: ${riskScore}/100\n\n**Рекомендация:** ${recommendationStr}`,
        data: {
            type: 'analysis',
            riskLevel: riskLevelStr,
            fraudProb: parseFloat(fraudProb) || 0,
            riskScore: parseFloat(riskScore) || 0,
            recommendation: recommendationStr,
            recommendationClass,
            reasons: Array.isArray(reasons) ? reasons : [],
            featureContributions: data.feature_contributions || {}
        }
    };
}

function formatFirstTransactionResponse(data) {
    const transaction = data.transaction;
    
    if (!transaction) {
        return { 
            text: '**Первый перевод**\n\nПереводы не найдены в системе.', 
            data: null 
        };
    }
    
    const date = transaction.transdatetime ? new Date(transaction.transdatetime).toLocaleString('ru-RU') : (transaction.transdate || 'Дата неизвестна');
    const amount = parseFloat(transaction.amount || 0).toLocaleString('ru-RU');
    const isFraud = transaction.target === 1;
    
    let text = `**Самый первый перевод**\n\n`;
    text += `**Сумма:** ${amount} ₸\n`;
    text += `**Клиент:** ${transaction.cst_dim_id || 'N/A'}\n`;
    text += `**Дата:** ${date}\n`;
    if (transaction.docno) {
        text += `**Номер документа:** ${transaction.docno}\n`;
    }
    if (isFraud) {
        text += `\n⚠️ **МОШЕННИЧЕСТВО** - Эта транзакция была помечена как мошенническая\n`;
    } else {
        text += `\n✓ **БЕЗОПАСНО** - Транзакция прошла проверку антифрода\n`;
    }
    
    return {
        text: text,
        data: {
            type: 'first_transaction',
            transaction: transaction
        }
    };
}

function formatLastTransactionsResponse(data) {
    const transactions = Array.isArray(data.transactions) ? data.transactions : [];
    
    if (transactions.length === 0) {
        return { 
            text: '**Последние переводы**\n\nПереводы не найдены в системе.', 
            data: null 
        };
    }
    
    // Подсчитываем статистику
    const totalAmount = transactions.reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);
    const uniqueClients = new Set(transactions.map(t => t.cst_dim_id)).size;
    const fraudCount = transactions.filter(t => t.target === 1).length;
    
    let text = `**Последние переводы**\n\n`;
    text += `Найдено: **${transactions.length}** транзакций\n`;
    text += `Уникальных клиентов: **${uniqueClients}**\n`;
    text += `Общая сумма: **${totalAmount.toLocaleString('ru-RU')} ₸**\n`;
    if (fraudCount > 0) {
        text += `⚠️ Мошеннических: **${fraudCount}**\n`;
    }
    text += `\n---\n\n`;
    
    // Добавляем краткую информацию о каждой транзакции
    transactions.slice(0, 5).forEach((t, idx) => {
        const date = t.transdatetime ? new Date(t.transdatetime).toLocaleString('ru-RU') : 'Дата неизвестна';
        const amount = parseFloat(t.amount || 0).toLocaleString('ru-RU');
        const fraudBadge = t.target === 1 ? ' 🚫 МОШЕННИЧЕСТВО' : '';
        text += `${idx + 1}. **${amount} ₸** | Клиент: ${t.cst_dim_id} | ${date}${fraudBadge}\n`;
    });
    
    if (transactions.length > 5) {
        text += `\n... и еще ${transactions.length - 5} транзакций`;
    }
    
    return {
        text: text,
        data: {
            type: 'last_transactions',
            transactions: transactions,
            total: data.total || transactions.length,
            summary: {
                total_amount: totalAmount,
                unique_clients: uniqueClients,
                fraud_count: fraudCount
            }
        }
    };
}

function formatSuspiciousResponse(data) {
    const transactions = Array.isArray(data.transactions) ? data.transactions : [];
    
    if (transactions.length === 0) {
        return { text: 'Подозрительные транзакции не найдены', data: null };
    }
    
    // Подсчитываем уникальных клиентов
    const uniqueClients = new Set(transactions.map(t => t.cst_dim_id)).size;
    const totalAmount = transactions.reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);
    
    return {
        text: `**Подозрительные транзакции**\n\nНайдено: ${transactions.length} транзакций\nУникальных клиентов: ${uniqueClients}\nОбщая сумма: ${totalAmount.toLocaleString('ru-RU')} ₸`,
        data: {
            type: 'suspicious',
            transactions: transactions.slice(0, 20) // Увеличиваем лимит для лучшего отображения
        }
    };
}

function formatMetricsResponse(data) {
    const metrics = data.metrics || {};
    
    const rocAuc = parseFloat(metrics.roc_auc) || 0;
    const precision = parseFloat(metrics.precision) || 0;
    const recall = parseFloat(metrics.recall) || 0;
    const f1 = parseFloat(metrics.f1) || 0;
    
    return {
        text: `**Метрики модели**\n\nROC-AUC: ${rocAuc.toFixed(4)}\nPrecision: ${precision.toFixed(4)}\nRecall: ${recall.toFixed(4)}\nF1-Score: ${f1.toFixed(4)}`,
        data: {
            type: 'metrics',
            metrics: {
                roc_auc: rocAuc,
                precision: precision,
                recall: recall,
                f1: f1
            }
        }
    };
}

function formatExplainResponse(data) {
    const explanation = data.explanation || {};
    const riskFactors = Array.isArray(explanation.risk_factors) ? explanation.risk_factors : [];
    
    const factorsText = riskFactors.length > 0 
        ? riskFactors.join('\n') 
        : 'Объяснение недоступно';
    
    return {
        text: `**Объяснение решения модели**\n\n${factorsText}`,
        data: {
            type: 'explain',
            explanation
        }
    };
}

function formatThresholdsResponse(data) {
    const thresholds = data.thresholds || {};
    
    const thresholdsText = Object.entries(thresholds)
        .map(([key, value]) => {
            const keyStr = String(key).replace(/_/g, ' ');
            const valueStr = typeof value === 'number' ? value.toFixed(3) : String(value);
            return `${keyStr}: ${valueStr}`;
        })
        .join('\n');
    
    return {
        text: `**Пороги срабатывания**\n\n${thresholdsText || 'Пороги не настроены'}`,
        data: {
            type: 'thresholds',
            thresholds
        }
    };
}

function formatHistoryResponse(data) {
    const history = data.history || [];
    
    if (history.length === 0) {
        return { text: 'История не найдена', data: null };
    }
    
    return {
        text: `Найдено ${history.length} транзакций в истории клиента`,
        data: {
            type: 'history',
            history: history.slice(0, 20)
        }
    };
}

function formatMonitoringResponse(data) {
    const driftDetected = data.drift_detected ? 'Обнаружен' : 'Не обнаружен';
    const driftScore = parseFloat(data.drift_score) || 0;
    
    return {
        text: `**Мониторинг системы**\n\nData Drift: ${driftDetected}\nScore: ${driftScore.toFixed(4)}`,
        data: {
            type: 'monitoring',
            drift_detected: data.drift_detected || false,
            drift_score: driftScore
        }
    };
}

// Добавление сообщения в чат
function addMessage(role, text, isLoading = false, data = null) {
    const chatMessages = document.getElementById('chatMessages');
    if (!chatMessages) return null;
    
    // Безопасная конвертация text в строку
    let textStr = '';
    if (text !== null && text !== undefined) {
        if (typeof text === 'string') {
            textStr = text;
        } else if (typeof text === 'object') {
            // Если это объект, пытаемся красиво его отформатировать
            try {
                textStr = JSON.stringify(text, null, 2);
            } catch {
                textStr = String(text);
            }
        } else {
            textStr = String(text);
        }
    }
    
    const messageId = 'msg-' + Date.now();
    const message = document.createElement('div');
    message.className = `message ${role}`;
    message.id = messageId;
    
    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    
    if (isLoading) {
        bubble.innerHTML = '<div class="loading-dots"><span></span><span></span><span></span></div>';
    } else {
        // Простое форматирование markdown
        if (textStr) {
            bubble.innerHTML = formatMessageText(textStr);
        }
        
        // Если есть данные, добавляем структурированные карточки
        if (data && typeof data === 'object' && data !== null) {
            const cardsContainer = document.createElement('div');
            cardsContainer.className = 'message-cards';
            const cardsHtml = formatDataCards(data);
            if (cardsHtml) {
                cardsContainer.innerHTML = cardsHtml;
                bubble.appendChild(cardsContainer);
            }
        }
    }
    
    message.appendChild(bubble);
    
    const time = document.createElement('div');
    time.className = 'message-time';
    time.textContent = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    message.appendChild(time);
    
    chatMessages.appendChild(message);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    return messageId;
}

// Удаление сообщения
function removeMessage(messageId) {
    const message = document.getElementById(messageId);
    if (message) {
        message.remove();
    }
}

// Форматирование текста сообщения (простой markdown)
function formatMessageText(text) {
    // Проверяем тип и конвертируем в строку
    if (text === null || text === undefined) {
        return '';
    }
    
    // Если это не строка, конвертируем
    if (typeof text !== 'string') {
        text = String(text);
    }
    
    // Заменяем **текст** на <strong>текст</strong>
    text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    // Заменяем переносы строк на <br>
    text = text.replace(/\n/g, '<br>');
    
    return text;
}

// Форматирование карточек данных
function formatDataCards(data) {
    if (!data || typeof data !== 'object' || data === null) {
        return '';
    }
    
    if (!data.type || typeof data.type !== 'string') {
        return '';
    }
    
    try {
        switch (data.type) {
            case 'analysis':
                return formatAnalysisCards(data);
            case 'suspicious':
                return formatSuspiciousCards(data);
            case 'metrics':
                return formatMetricsCards(data);
            case 'last_transactions':
                return formatLastTransactionsCards(data);
            case 'first_transaction':
                return formatFirstTransactionCard(data);
            case 'blocked_transfer':
                return formatBlockedTransferCard(data);
            case 'successful_transfer':
                return formatSuccessfulTransferCard(data);
            default:
                return '';
        }
    } catch (error) {
        console.error('Ошибка форматирования карточек:', error);
        return '';
    }
}

function formatBlockedTransferCard(data) {
    const transaction = data.transaction || {};
    const fraudCheck = data.fraud_check || {};
    
    return `
        <div class="message-card" style="border-left: 4px solid #DC2626; background: #FEF2F2;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                <div style="font-size: 32px;">🚫</div>
                <div>
                    <div style="font-size: 18px; font-weight: 700; color: #DC2626; margin-bottom: 4px;">Перевод заблокирован</div>
                    <div style="font-size: 13px; color: #6B6B6B;">Обнаружены признаки мошенничества</div>
                </div>
            </div>
            
            <div style="background: #FFFFFF; padding: 16px; border-radius: 8px; margin-bottom: 12px;">
                <div style="font-size: 14px; font-weight: 600; color: #4A4A4A; margin-bottom: 12px;">Детали транзакции:</div>
                <div style="display: grid; gap: 8px; font-size: 13px;">
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Отправитель:</span>
                        <span style="font-weight: 600; color: #2D2D2D;">${transaction.sender_id || 'N/A'}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Получатель:</span>
                        <span style="font-weight: 600; color: #2D2D2D;">${transaction.receiver_id || 'N/A'}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Сумма:</span>
                        <span style="font-weight: 700; color: #DC2626; font-size: 16px;">${(transaction.amount || 0).toLocaleString('ru-RU')} ${transaction.currency || 'KZT'}</span>
                    </div>
                </div>
            </div>
            
            <div style="background: #FFF7ED; padding: 12px; border-radius: 8px; border-left: 3px solid #F59E0B;">
                <div style="font-size: 13px; font-weight: 600; color: #D97706; margin-bottom: 8px;">⚠️ Причины блокировки:</div>
                <ul style="margin: 0; padding-left: 20px; font-size: 13px; color: #92400E;">
                    ${(fraudCheck.reasons || []).map(reason => `<li style="margin-bottom: 4px;">${reason}</li>`).join('')}
                </ul>
            </div>
        </div>
    `;
}

function formatSuccessfulTransferCard(data) {
    const transaction = data.transaction || {};
    const fraudCheck = data.fraud_check || {};
    
    return `
        <div class="message-card" style="border-left: 4px solid #059669; background: #F0FDF4;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                <div style="font-size: 32px;">✅</div>
                <div>
                    <div style="font-size: 18px; font-weight: 700; color: #059669; margin-bottom: 4px;">Перевод выполнен</div>
                    <div style="font-size: 13px; color: #6B6B6B;">Транзакция сохранена в системе</div>
                </div>
            </div>
            
            <div style="background: #FFFFFF; padding: 16px; border-radius: 8px; margin-bottom: 12px;">
                <div style="font-size: 14px; font-weight: 600; color: #4A4A4A; margin-bottom: 12px;">Детали транзакции:</div>
                <div style="display: grid; gap: 8px; font-size: 13px;">
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Номер документа:</span>
                        <span style="font-weight: 600; color: #2D2D2D;">${transaction.docno || 'N/A'}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Отправитель:</span>
                        <span style="font-weight: 600; color: #2D2D2D;">${transaction.sender_id || 'N/A'}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Получатель:</span>
                        <span style="font-weight: 600; color: #2D2D2D;">${transaction.receiver_id || 'N/A'}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Сумма:</span>
                        <span style="font-weight: 700; color: #059669; font-size: 16px;">${(transaction.amount || 0).toLocaleString('ru-RU')} ${transaction.currency || 'KZT'}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Дата:</span>
                        <span style="font-weight: 600; color: #2D2D2D;">${transaction.date ? new Date(transaction.date).toLocaleString('ru-RU') : 'N/A'}</span>
                    </div>
                </div>
            </div>
            
            <div style="background: #F0F9FF; padding: 12px; border-radius: 8px; border-left: 3px solid #0EA5E9;">
                <div style="font-size: 13px; font-weight: 600; color: #0369A1; margin-bottom: 8px;">✓ Проверка антифрода:</div>
                <div style="font-size: 12px; color: #0C4A6E;">
                    Уровень риска: <span style="font-weight: 600;">${fraudCheck.risk_level?.toUpperCase() || 'LOW'}</span> | 
                    Оценка: <span style="font-weight: 600;">${fraudCheck.risk_score || 0}/100</span>
                </div>
            </div>
        </div>
    `;
}

function formatAnalysisCards(data) {
    if (!data) return '';
    
    const riskLevel = data.riskLevel || 'unknown';
    const recommendation = data.recommendation || 'Проверить';
    const recommendationClass = data.recommendationClass || 'review';
    const reasons = Array.isArray(data.reasons) ? data.reasons : [];
    const featureContributions = data.featureContributions || {};
    
    return `
        <div class="message-card">
            <div style="display: flex; gap: 8px; margin-bottom: 12px; flex-wrap: wrap;">
                <span class="risk-badge ${riskLevel}">${String(riskLevel).toUpperCase()}</span>
                <span class="recommendation-badge ${recommendationClass}">${String(recommendation)}</span>
            </div>
            ${reasons.length > 0 ? `
            <div style="margin-top: 12px;">
                <div style="font-size: 13px; font-weight: 600; color: #4A4A4A; margin-bottom: 8px;">Факторы риска:</div>
                <div class="factor-list">
                    ${reasons.map(reason => `<div class="factor-item"><span class="factor-name">${String(reason)}</span></div>`).join('')}
                </div>
            </div>
            ` : ''}
            ${Object.keys(featureContributions).length > 0 ? `
                <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #F0F0F0;">
                    <div style="font-size: 13px; font-weight: 600; color: #4A4A4A; margin-bottom: 8px;">Топ факторов:</div>
                    <div class="factor-list">
                        ${Object.entries(featureContributions)
                            .sort((a, b) => Math.abs(parseFloat(b[1]) || 0) - Math.abs(parseFloat(a[1]) || 0))
                            .slice(0, 5)
                            .map(([name, value]) => {
                                const numValue = parseFloat(value) || 0;
                                const nameStr = String(name).replace(/_/g, ' ');
                                return `
                                    <div class="factor-item">
                                        <span class="factor-name">${nameStr}</span>
                                        <span class="factor-value" style="color: ${numValue > 0 ? '#DC2626' : '#059669'};">
                                            ${numValue > 0 ? '+' : ''}${numValue.toFixed(3)}
                                        </span>
                                    </div>
                                `;
                            }).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;
}

function formatFirstTransactionCard(data) {
    const transaction = data.transaction;
    if (!transaction) {
        return '<div class="message-card"><p style="text-align: center; color: #6B7280; padding: 20px;">Перевод не найден</p></div>';
    }
    
    const formatAmount = (amount) => {
        return (amount || 0).toLocaleString('ru-RU', { 
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }) + ' ₸';
    };
    
    const date = transaction.transdatetime ? new Date(transaction.transdatetime).toLocaleString('ru-RU') : (transaction.transdate || 'Дата неизвестна');
    const amount = parseFloat(transaction.amount || 0);
    const isFraud = transaction.target === 1;
    
    return `
        <div class="message-card" style="border-left: 4px solid ${isFraud ? '#DC2626' : '#059669'}; background: ${isFraud ? '#FEF2F2' : '#F0FDF4'};">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                <div style="font-size: 32px;">${isFraud ? '🚫' : '📅'}</div>
                <div>
                    <div style="font-size: 18px; font-weight: 700; color: ${isFraud ? '#DC2626' : '#059669'}; margin-bottom: 4px;">
                        Самый первый перевод
                    </div>
                    <div style="font-size: 13px; color: #6B6B6B;">
                        ${isFraud ? 'Мошенническая транзакция' : 'Первая транзакция в системе'}
                    </div>
                </div>
            </div>
            
            <div style="background: #FFFFFF; padding: 16px; border-radius: 8px; margin-bottom: 12px;">
                <div style="font-size: 14px; font-weight: 600; color: #4A4A4A; margin-bottom: 12px;">Детали транзакции:</div>
                <div style="display: grid; gap: 8px; font-size: 13px;">
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Сумма:</span>
                        <span style="font-weight: 700; color: #2D2D2D; font-size: 16px;">${formatAmount(amount)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Клиент:</span>
                        <span style="font-weight: 600; color: #2D2D2D;">${transaction.cst_dim_id || 'N/A'}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Дата:</span>
                        <span style="font-weight: 600; color: #2D2D2D;">${date}</span>
                    </div>
                    ${transaction.docno ? `
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #6B6B6B;">Номер документа:</span>
                        <span style="font-weight: 600; color: #2D2D2D;">${transaction.docno}</span>
                    </div>
                    ` : ''}
                </div>
            </div>
            
            ${isFraud ? `
            <div style="background: #FEF2F2; padding: 12px; border-radius: 8px; border-left: 3px solid #DC2626;">
                <div style="font-size: 13px; font-weight: 600; color: #DC2626; margin-bottom: 8px;">⚠️ Мошенническая транзакция</div>
                <div style="font-size: 12px; color: #991B1B;">
                    Эта транзакция была помечена как мошенническая в системе.
                </div>
            </div>
            ` : `
            <div style="background: #F0F9FF; padding: 12px; border-radius: 8px; border-left: 3px solid #0EA5E9;">
                <div style="font-size: 13px; font-weight: 600; color: #0369A1; margin-bottom: 8px;">✓ Безопасная транзакция</div>
                <div style="font-size: 12px; color: #0C4A6E;">
                    Транзакция прошла проверку антифрода и была успешно обработана.
                </div>
            </div>
            `}
        </div>
    `;
}

function formatLastTransactionsCards(data) {
    const transactions = Array.isArray(data.transactions) ? data.transactions : [];
    if (transactions.length === 0) {
        return '<div class="message-card"><p style="text-align: center; color: #6B7280; padding: 20px;">Переводы не найдены</p></div>';
    }
    
    const formatAmount = (amount) => {
        return (amount || 0).toLocaleString('ru-RU', { 
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }) + ' ₸';
    };
    
    const summary = data.summary || {};
    const totalAmount = summary.total_amount || 0;
    const uniqueClients = summary.unique_clients || 0;
    const fraudCount = summary.fraud_count || 0;
    
    return `
        <div class="last-transactions-container">
            <div style="font-size: 14px; font-weight: 600; color: #2D2D2D; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 2px solid #E8E8E8;">
                Найдено транзакций: <span style="color: #8B1E2D;">${transactions.length}</span>
                ${uniqueClients > 0 ? `<br>Уникальных клиентов: <span style="color: #8B1E2D;">${uniqueClients}</span>` : ''}
                ${totalAmount > 0 ? `<br>Общая сумма: <span style="color: #8B1E2D;">${formatAmount(totalAmount)}</span>` : ''}
                ${fraudCount > 0 ? `<br>⚠️ Мошеннических: <span style="color: #DC2626;">${fraudCount}</span>` : ''}
            </div>
            <div style="display: flex; flex-direction: column; gap: 10px;">
                ${transactions.map((t, idx) => {
                    const date = t.transdatetime ? new Date(t.transdatetime).toLocaleString('ru-RU') : (t.transdate || 'Дата неизвестна');
                    const amount = parseFloat(t.amount || 0);
                    const isFraud = t.target === 1;
                    
                    return `
                        <div class="transaction-item" style="padding: 14px; background: ${isFraud ? '#FEF2F2' : '#FFFFFF'}; border-radius: 8px; border-left: 3px solid ${isFraud ? '#DC2626' : '#059669'};">
                            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
                                <div style="flex: 1;">
                                    <div style="font-size: 16px; font-weight: 700; color: #2D2D2D; margin-bottom: 4px;">
                                        ${formatAmount(amount)}
                                    </div>
                                    <div style="font-size: 12px; color: #6B6B6B; margin-bottom: 4px;">
                                        ${date}
                                    </div>
                                    <div style="font-size: 12px; color: #6B6B6B;">
                                        Клиент: <span style="font-weight: 600; color: #4A4A4A;">${t.cst_dim_id || 'N/A'}</span>
                                    </div>
                                </div>
                                ${isFraud ? '<span class="risk-badge high" style="font-size: 11px; padding: 4px 10px;">🚫 МОШЕННИЧЕСТВО</span>' : '<span class="risk-badge low" style="font-size: 11px; padding: 4px 10px;">✓ БЕЗОПАСНО</span>'}
                            </div>
                            ${t.docno ? `
                                <div style="display: flex; gap: 16px; margin-top: 8px; padding-top: 8px; border-top: 1px solid #F0F0F0;">
                                    <div style="font-size: 12px; color: #6B6B6B;">
                                        <span style="font-weight: 600; color: #4A4A4A;">Документ:</span> ${t.docno}
                                    </div>
                                </div>
                            ` : ''}
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
}

function formatSuspiciousCards(data) {
    if (!data.transactions || data.transactions.length === 0) {
        return '<div class="message-card"><div style="text-align: center; color: #9B9B9B; padding: 20px;">Подозрительные транзакции не найдены</div></div>';
    }
    
    // Группируем транзакции по клиентам
    const groupedByClient = {};
    data.transactions.forEach(t => {
        const clientId = t.cst_dim_id || 'unknown';
        if (!groupedByClient[clientId]) {
            groupedByClient[clientId] = [];
        }
        groupedByClient[clientId].push(t);
    });
    
    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('ru-RU', { 
                day: '2-digit', 
                month: '2-digit', 
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        } catch {
            return dateString;
        }
    };
    
    const formatAmount = (amount) => {
        return (amount || 0).toLocaleString('ru-RU', { 
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }) + ' ₸';
    };
    
    return `
        <div class="suspicious-transactions-container">
            <div style="font-size: 14px; font-weight: 600; color: #2D2D2D; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 2px solid #E8E8E8;">
                Найдено подозрительных транзакций: <span style="color: #8B1E2D;">${data.transactions.length}</span>
            </div>
            ${Object.entries(groupedByClient).map(([clientId, transactions]) => `
                <div class="client-group" style="margin-bottom: 20px; padding: 16px; background: #FAFAFA; border-radius: 12px; border: 1px solid #E8E8E8;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <div style="font-size: 15px; font-weight: 600; color: #2D2D2D;">
                            Клиент: <span style="color: #8B1E2D;">${clientId}</span>
                        </div>
                        <div style="font-size: 12px; color: #6B6B6B;">
                            ${transactions.length} ${transactions.length === 1 ? 'транзакция' : transactions.length < 5 ? 'транзакции' : 'транзакций'}
                        </div>
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        ${transactions.map(t => `
                            <div class="transaction-item" style="padding: 14px; background: #FFFFFF; border-radius: 8px; border-left: 3px solid #DC2626;">
                                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
                                    <div style="flex: 1;">
                                        <div style="font-size: 18px; font-weight: 700; color: #2D2D2D; margin-bottom: 4px;">
                                            ${formatAmount(t.amount)}
                                        </div>
                                        <div style="font-size: 12px; color: #6B6B6B;">
                                            ${formatDate(t.transdatetime || t.transdate)}
                                        </div>
                                    </div>
                                    <span class="risk-badge high" style="font-size: 11px; padding: 4px 10px;">ВЫСОКИЙ РИСК</span>
                                </div>
                                ${t.docno ? `
                                    <div style="display: flex; gap: 16px; margin-top: 8px; padding-top: 8px; border-top: 1px solid #F0F0F0;">
                                        <div style="font-size: 12px; color: #6B6B6B;">
                                            <span style="font-weight: 600; color: #4A4A4A;">Документ:</span> ${t.docno}
                                        </div>
                                    </div>
                                ` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

function formatMetricsCards(data) {
    if (!data || !data.metrics) {
        return '';
    }
    
    const m = data.metrics || {};
    const rocAuc = parseFloat(m.roc_auc) || 0;
    const precision = parseFloat(m.precision) || 0;
    const recall = parseFloat(m.recall) || 0;
    const f1 = parseFloat(m.f1) || 0;
    
    return `
        <div class="message-card">
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px;">
                <div><strong>ROC-AUC:</strong> ${rocAuc.toFixed(4)}</div>
                <div><strong>Precision:</strong> ${precision.toFixed(4)}</div>
                <div><strong>Recall:</strong> ${recall.toFixed(4)}</div>
                <div><strong>F1-Score:</strong> ${f1.toFixed(4)}</div>
            </div>
        </div>
    `;
}

// Быстрые действия
function sendQuickAction(action) {
    const chatInput = document.getElementById('chatInput');
    if (chatInput) {
        chatInput.value = action;
        // Небольшая задержка для визуального эффекта
        setTimeout(() => {
            sendMessage();
        }, 100);
    }
}

// Меню функций
function toggleFunctionsMenu() {
    const overlay = document.getElementById('functionsOverlay');
    if (overlay) {
        overlay.classList.toggle('active');
    }
}

function closeFunctionsMenu(event) {
    if (event && event.target.id === 'functionsOverlay') {
        toggleFunctionsMenu();
    } else if (!event) {
        toggleFunctionsMenu();
    }
}

function selectFunction(functionName) {
    closeFunctionsMenu();
    sendQuickAction(functionName);
}

// Загрузка диалога (оставлено для обратной совместимости, но больше не используется)
function loadDialog(dialogId, event) {
    // Функция оставлена для обратной совместимости
    // Левая панель удалена, функция больше не нужна
    return;
}

// No-Code формы
function openTransferForm() {
    openNoCodeForm('transfer');
}

function openNoCodeForm(type) {
    closeFunctionsMenu();
    
    const overlay = document.getElementById('noCodeOverlay');
    const panel = document.getElementById('noCodePanel');
    
    if (!overlay || !panel) return;
    
    let formHtml = '';
    
    if (type === 'transfer') {
        formHtml = `
            <div class="no-code-header">
                <div class="no-code-title">💸 Банковский перевод</div>
                <button class="no-code-close" onclick="closeNoCodeForm()">×</button>
            </div>
            <div class="no-code-content">
                <div class="no-code-info" style="background: #E0F2FE; border-left-color: #059669;">
                    Система автоматически проверит перевод на мошенничество. При обнаружении подозрительной активности перевод будет заблокирован.
                </div>
                
                <div class="no-code-form-group">
                    <label class="no-code-label">Отправитель (ID клиента) <span class="required">*</span></label>
                    <input type="number" id="transferSenderId" class="no-code-input" placeholder="Введите ID отправителя" required>
                </div>
                
                <div class="no-code-form-group">
                    <label class="no-code-label">Получатель (ID или номер счета) <span class="required">*</span></label>
                    <input type="text" id="transferReceiverId" class="no-code-input" placeholder="Введите ID получателя или номер счета" required>
                </div>
                
                <div class="no-code-grid">
                    <div class="no-code-form-group">
                        <label class="no-code-label">Сумма перевода <span class="required">*</span></label>
                        <input type="number" id="transferAmount" class="no-code-input" placeholder="0.00" step="0.01" min="0.01" required>
                    </div>
                    
                    <div class="no-code-form-group">
                        <label class="no-code-label">Валюта</label>
                        <select id="transferCurrency" class="no-code-select">
                            <option value="KZT" selected>KZT (Тенге)</option>
                            <option value="USD">USD (Доллар)</option>
                            <option value="EUR">EUR (Евро)</option>
                            <option value="RUB">RUB (Рубль)</option>
                        </select>
                    </div>
                </div>
                
                <div class="no-code-form-group">
                    <label class="no-code-label">Назначение платежа</label>
                    <textarea id="transferComment" class="no-code-textarea" placeholder="Укажите назначение перевода (опционально)" rows="3"></textarea>
                </div>
                
                <div class="no-code-actions">
                    <button class="no-code-btn no-code-btn-secondary" onclick="closeNoCodeForm()">Отмена</button>
                    <button class="no-code-btn no-code-btn-primary" onclick="processTransfer()" id="transferSubmitBtn">
                        Отправить перевод
                    </button>
                </div>
            </div>
        `;
    } else if (type === 'transaction') {
        formHtml = `
            <div class="no-code-header">
                <div class="no-code-title">Анализ транзакции</div>
                <button class="no-code-close" onclick="closeNoCodeForm()">×</button>
            </div>
            <div class="no-code-content">
                <div class="no-code-info">
                    Заполните форму для анализа транзакции. Все поля опциональны, но чем больше данных, тем точнее анализ.
                </div>
                
                <div class="no-code-form-group">
                    <label class="no-code-label">ID клиента</label>
                    <input type="number" id="ncClientId" class="no-code-input" placeholder="Введите ID клиента">
                </div>
                
                <div class="no-code-grid">
                    <div class="no-code-form-group">
                        <label class="no-code-label">Сумма транзакции</label>
                        <input type="number" id="ncAmount" class="no-code-input" placeholder="0" step="0.01">
                    </div>
                    
                    <div class="no-code-form-group">
                        <label class="no-code-label">Валюта</label>
                        <select id="ncCurrency" class="no-code-select">
                            <option value="KZT">KZT (Тенге)</option>
                            <option value="USD">USD (Доллар)</option>
                            <option value="EUR">EUR (Евро)</option>
                            <option value="RUB">RUB (Рубль)</option>
                        </select>
                    </div>
                </div>
                
                <div class="no-code-form-group">
                    <label class="no-code-label">Направление транзакции</label>
                    <input type="text" id="ncDirection" class="no-code-input" placeholder="Направление или получатель">
                </div>
                
                <div class="no-code-form-group">
                    <label class="no-code-label">Комментарий к транзакции</label>
                    <textarea id="ncComment" class="no-code-textarea" placeholder="Описание транзакции или комментарий"></textarea>
                </div>
                
                <div class="no-code-form-group">
                    <label class="no-code-label">Дата и время</label>
                    <input type="datetime-local" id="ncDateTime" class="no-code-input">
                </div>
                
                <div class="no-code-actions">
                    <button class="no-code-btn no-code-btn-secondary" onclick="closeNoCodeForm()">Отмена</button>
                    <button class="no-code-btn no-code-btn-primary" onclick="submitNoCodeTransaction()">Анализировать</button>
                </div>
            </div>
        `;
    } else if (type === 'rules') {
        formHtml = `
            <div class="no-code-header">
                <div class="no-code-title">Создание правила антифрода</div>
                <button class="no-code-close" onclick="closeNoCodeForm()">×</button>
            </div>
            <div class="no-code-content">
                <div class="no-code-info">
                    Создайте правило для автоматического обнаружения подозрительных транзакций без программирования.
                </div>
                
                <div class="no-code-form-group">
                    <label class="no-code-label">Название правила</label>
                    <input type="text" id="ncRuleName" class="no-code-input" placeholder="Например: Большие суммы">
                </div>
                
                <div class="no-code-form-group">
                    <label class="no-code-label">Условие</label>
                    <select id="ncRuleCondition" class="no-code-select" onchange="updateRuleCondition()">
                        <option value="amount">Сумма транзакции</option>
                        <option value="client">ID клиента</option>
                        <option value="frequency">Частота транзакций</option>
                        <option value="time">Время транзакции</option>
                        <option value="direction">Направление</option>
                    </select>
                </div>
                
                <div class="no-code-grid" id="ncRuleParams">
                    <div class="no-code-form-group">
                        <label class="no-code-label">Оператор</label>
                        <select id="ncOperator" class="no-code-select">
                            <option value="greater">Больше чем</option>
                            <option value="less">Меньше чем</option>
                            <option value="equal">Равно</option>
                            <option value="contains">Содержит</option>
                        </select>
                    </div>
                    
                    <div class="no-code-form-group">
                        <label class="no-code-label">Значение</label>
                        <input type="text" id="ncRuleValue" class="no-code-input" placeholder="Введите значение">
                    </div>
                </div>
                
                <div class="no-code-form-group">
                    <label class="no-code-label">Действие при срабатывании</label>
                    <select id="ncRuleAction" class="no-code-select">
                        <option value="block">Заблокировать</option>
                        <option value="review">Отправить на проверку</option>
                        <option value="alert">Отправить уведомление</option>
                        <option value="flag">Пометить как подозрительную</option>
                    </select>
                </div>
                
                <div class="no-code-form-group">
                    <label class="no-code-label">Приоритет</label>
                    <select id="ncRulePriority" class="no-code-select">
                        <option value="high">Высокий</option>
                        <option value="medium" selected>Средний</option>
                        <option value="low">Низкий</option>
                    </select>
                </div>
                
                <div class="no-code-actions">
                    <button class="no-code-btn no-code-btn-secondary" onclick="closeNoCodeForm()">Отмена</button>
                    <button class="no-code-btn no-code-btn-primary" onclick="submitNoCodeRule()">Создать правило</button>
                </div>
            </div>
        `;
    }
    
    panel.innerHTML = formHtml;
    overlay.classList.add('active');
    
    // Устанавливаем текущую дату по умолчанию
    if (type === 'transaction') {
        const dateInput = document.getElementById('ncDateTime');
        if (dateInput) {
            const now = new Date();
            now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
            dateInput.value = now.toISOString().slice(0, 16);
        }
    }
}

function closeNoCodeForm(event) {
    const overlay = document.getElementById('noCodeOverlay');
    if (overlay) {
        if (!event || event.target.id === 'noCodeOverlay') {
            overlay.classList.remove('active');
        }
    }
}

function submitNoCodeTransaction() {
    const clientId = document.getElementById('ncClientId')?.value;
    const amount = document.getElementById('ncAmount')?.value;
    const currency = document.getElementById('ncCurrency')?.value || 'KZT';
    const direction = document.getElementById('ncDirection')?.value;
    const comment = document.getElementById('ncComment')?.value;
    const dateTime = document.getElementById('ncDateTime')?.value;
    
    // Формируем объект транзакции
    const transactionData = {};
    
    if (clientId) transactionData.cst_dim_id = parseInt(clientId);
    if (amount) transactionData.amount = parseFloat(amount);
    if (currency) transactionData.currency = currency;
    if (direction) transactionData.direction = direction;
    if (comment) transactionData.comment = comment;
    if (dateTime) transactionData.transdatetime = new Date(dateTime).toISOString();
    
    if (Object.keys(transactionData).length === 0) {
        alert('Заполните хотя бы одно поле');
        return;
    }
    
    closeNoCodeForm();
    
    // Отправляем в чат
    const chatInput = document.getElementById('chatInput');
    if (chatInput) {
        chatInput.value = JSON.stringify(transactionData, null, 2);
        sendMessage();
    }
}

function submitNoCodeRule() {
    const ruleName = document.getElementById('ncRuleName')?.value;
    const condition = document.getElementById('ncRuleCondition')?.value;
    const operator = document.getElementById('ncOperator')?.value;
    const value = document.getElementById('ncRuleValue')?.value;
    const action = document.getElementById('ncRuleAction')?.value;
    const priority = document.getElementById('ncRulePriority')?.value;
    
    if (!ruleName || !value) {
        alert('Заполните обязательные поля');
        return;
    }
    
    const rule = {
        name: ruleName,
        condition: condition,
        operator: operator,
        value: value,
        action: action,
        priority: priority
    };
    
    closeNoCodeForm();
    
    // Отправляем в чат
    addMessage('user', `Создать правило: ${ruleName}`);
    
    const loadingId = addMessage('assistant', '', true);
    
    setTimeout(() => {
        removeMessage(loadingId);
        addMessage('assistant', `**Правило создано**\n\nНазвание: ${ruleName}\nУсловие: ${condition}\nОператор: ${operator}\nЗначение: ${value}\nДействие: ${action}\nПриоритет: ${priority}\n\nПравило успешно добавлено в систему!`, false);
    }, 1000);
}

function updateRuleCondition() {
    const condition = document.getElementById('ncRuleCondition')?.value;
    const operatorSelect = document.getElementById('ncOperator');
    const valueInput = document.getElementById('ncRuleValue');
    
    if (!operatorSelect || !valueInput) return;
    
    // Обновляем операторы в зависимости от условия
    operatorSelect.innerHTML = '';
    
    if (condition === 'amount' || condition === 'frequency') {
        operatorSelect.innerHTML = `
            <option value="greater">Больше чем</option>
            <option value="less">Меньше чем</option>
            <option value="equal">Равно</option>
            <option value="between">Между</option>
        `;
        valueInput.type = 'number';
        valueInput.placeholder = 'Введите число';
    } else if (condition === 'client' || condition === 'direction') {
        operatorSelect.innerHTML = `
            <option value="equal">Равно</option>
            <option value="contains">Содержит</option>
            <option value="starts">Начинается с</option>
            <option value="ends">Заканчивается на</option>
        `;
        valueInput.type = 'text';
        valueInput.placeholder = 'Введите текст';
    } else if (condition === 'time') {
        operatorSelect.innerHTML = `
            <option value="before">До</option>
            <option value="after">После</option>
            <option value="between">Между</option>
        `;
        valueInput.type = 'time';
        valueInput.placeholder = 'Введите время';
    }
}

// Обработка банковского перевода
async function processTransfer() {
    const senderId = document.getElementById('transferSenderId')?.value;
    const receiverId = document.getElementById('transferReceiverId')?.value;
    const amount = document.getElementById('transferAmount')?.value;
    const currency = document.getElementById('transferCurrency')?.value || 'KZT';
    const comment = document.getElementById('transferComment')?.value || '';
    const submitBtn = document.getElementById('transferSubmitBtn');
    
    // Валидация
    if (!senderId || !receiverId || !amount || parseFloat(amount) <= 0) {
        alert('Заполните все обязательные поля корректно');
        return;
    }
    
    // Блокируем кнопку
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Проверка...';
    }
    
    try {
        const response = await fetch('/api/smartantifraud/process-transfer', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                sender_id: senderId,
                receiver_id: receiverId,
                amount: parseFloat(amount),
                currency: currency,
                comment: comment
            })
        });
        
        const data = await response.json();
        
        // Закрываем форму
        closeNoCodeForm();
        
        // Проверяем статус ответа
        if (!response.ok) {
            if (data.blocked) {
                // Перевод заблокирован (403)
                addMessage('user', `Перевод ${amount} ${currency} получателю ${receiverId}`);
                
                const blockedMessage = `🚫 **Перевод заблокирован!**\n\n**Причина:** ${data.reason || 'Обнаружены признаки мошенничества'}\n\n**Детали проверки:**\n- Уровень риска: ${(data.fraud_check?.risk_level || 'high').toUpperCase()}\n- Оценка риска: ${data.fraud_check?.risk_score || 0}/100\n- Признаки мошенничества: ${(data.fraud_check?.reasons || []).join(', ') || 'Высокий риск'}\n\n⚠️ **Это мошенническая транзакция!** Перевод не был выполнен.`;
                
                addMessage('assistant', blockedMessage, false, {
                    type: 'blocked_transfer',
                    transaction: {
                        sender_id: senderId,
                        receiver_id: receiverId,
                        amount: amount,
                        currency: currency
                    },
                    fraud_check: data.fraud_check || {}
                });
                return;
            } else {
                throw new Error(data.error || 'Ошибка при обработке перевода');
            }
        }
        
        if (data.blocked) {
            // Перевод заблокирован
            addMessage('user', `Перевод ${amount} ${currency} получателю ${receiverId}`);
            
            const blockedMessage = `🚫 **Перевод заблокирован!**\n\n**Причина:** ${data.reason}\n\n**Детали проверки:**\n- Уровень риска: ${data.fraud_check.risk_level.toUpperCase()}\n- Оценка риска: ${data.fraud_check.risk_score}/100\n- Признаки мошенничества: ${data.fraud_check.reasons.join(', ')}\n\n⚠️ **Это мошенническая транзакция!** Перевод не был выполнен.`;
            
            addMessage('assistant', blockedMessage, false, {
                type: 'blocked_transfer',
                transaction: {
                    sender_id: senderId,
                    receiver_id: receiverId,
                    amount: amount,
                    currency: currency
                },
                fraud_check: data.fraud_check
            });
        } else {
            // Перевод успешен
            addMessage('user', `Перевод ${amount} ${currency} получателю ${receiverId}`);
            
            const successMessage = `✅ **Перевод успешно выполнен!**\n\n**Детали транзакции:**\n- Номер документа: ${data.transaction.docno}\n- Сумма: ${data.transaction.amount} ${data.transaction.currency}\n- Получатель: ${data.transaction.receiver_id}\n- Дата: ${new Date(data.transaction.date).toLocaleString('ru-RU')}\n\n**Проверка антифрода:**\n- Уровень риска: ${data.fraud_check.risk_level.toUpperCase()}\n- Оценка: ${data.fraud_check.risk_score}/100\n\nТранзакция сохранена в системе.`;
            
            addMessage('assistant', successMessage, false, {
                type: 'successful_transfer',
                transaction: data.transaction,
                fraud_check: data.fraud_check
            });
        }
        
    } catch (error) {
        closeNoCodeForm();
        addMessage('assistant', `Ошибка при обработке перевода: ${error.message}`, false);
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Отправить перевод';
        }
    }
}

// Экспорт функций для глобального использования
window.sendMessage = sendMessage;
window.sendQuickAction = sendQuickAction;
window.toggleFunctionsMenu = toggleFunctionsMenu;
window.closeFunctionsMenu = closeFunctionsMenu;
window.selectFunction = selectFunction;
window.loadDialog = loadDialog;
window.handleInputKeydown = handleInputKeydown;
window.autoResizeTextarea = autoResizeTextarea;
window.openNoCodeForm = openNoCodeForm;
window.closeNoCodeForm = closeNoCodeForm;
window.submitNoCodeTransaction = submitNoCodeTransaction;
window.submitNoCodeRule = submitNoCodeRule;
window.updateRuleCondition = updateRuleCondition;
window.openTransferForm = openTransferForm;
window.processTransfer = processTransfer;
window.addMessage = addMessage;

